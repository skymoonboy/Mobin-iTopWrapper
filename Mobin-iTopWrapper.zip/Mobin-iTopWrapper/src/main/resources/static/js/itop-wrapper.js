/**
 * اسکریپت اصلی سامانه مدیریت خدمات فناوری اطلاعات
 * iTop Wrapper - JavaScript Utilities
 */

'use strict';

// ===== ابزارهای عمومی =====
const ITopWrapper = {

    /** نمایش پیام Toast */
    showToast(message, type = 'info') {
        const colors = {
            success: '#198754', danger: '#dc3545',
            warning: '#ffc107', info: '#0dcaf0'
        };
        const container = document.getElementById('toastContainer') || (() => {
            const el = document.createElement('div');
            el.id = 'toastContainer';
            el.style.cssText = 'position:fixed;top:20px;left:20px;z-index:9999;';
            document.body.appendChild(el);
            return el;
        })();

        const toast = document.createElement('div');
        toast.className = 'toast show align-items-center text-white border-0 mb-2';
        toast.style.cssText = `background-color:${colors[type]};min-width:280px;`;
        toast.innerHTML = `
            <div class="d-flex">
                <div class="toast-body">${message}</div>
                <button type="button" class="btn-close btn-close-white me-2 m-auto"
                        onclick="this.closest('.toast').remove()"></button>
            </div>`;
        container.appendChild(toast);
        setTimeout(() => toast.remove(), 5000);
    },

    /** درخواست API با مدیریت خطا */
    async apiRequest(url, method = 'GET', body = null) {
        const token = document.querySelector('meta[name="_csrf"]')?.content;
        const header = document.querySelector('meta[name="_csrf_header"]')?.content;

        const opts = {
            method,
            headers: {
                'Content-Type': 'application/json',
                'X-Requested-With': 'XMLHttpRequest'
            }
        };
        if (token && header) opts.headers[header] = token;
        if (body) opts.body = JSON.stringify(body);

        const res = await fetch(url, opts);
        if (!res.ok) throw new Error(`HTTP ${res.status}: ${await res.text()}`);
        return res.json().catch(() => null);
    },

    /** تبدیل تاریخ میلادی به فارسی */
    toFarsiDate(dateStr) {
        if (!dateStr) return '-';
        return new Date(dateStr).toLocaleDateString('fa-IR', {
            year: 'numeric', month: 'long', day: 'numeric'
        });
    },

    /** فرمت عدد فارسی */
    formatNumber(n) {
        return Number(n).toLocaleString('fa-IR');
    },

    /** تأیید عملیات حذف */
    confirmDelete(name, callback) {
        if (confirm(`آیا از حذف "${name}" مطمئن هستید؟\nاین عملیات قابل بازگشت نیست.`)) {
            callback();
        }
    }
};

// ===== مدیریت کاربران (پنل ادمین) =====
const UserManager = {
    async loadUsers() {
        try {
            const users = await ITopWrapper.apiRequest('/api/admin/users');
            this.renderTable(users);
        } catch (e) {
            ITopWrapper.showToast('خطا در بارگذاری کاربران', 'danger');
        }
    },

    renderTable(users) {
        const tbody = document.getElementById('usersTableBody');
        if (!tbody) return;
        tbody.innerHTML = users.map(u => `
            <tr>
                <td><code>${u.username}</code></td>
                <td>${u.firstName || ''} ${u.lastName || ''}</td>
                <td>${u.email}</td>
                <td>
                    <span class="badge bg-${u.authType === 'LDAP' ? 'info' : 'secondary'}">
                        ${u.authType || 'LOCAL'}
                    </span>
                </td>
                <td>
                    ${(u.roles || []).map(r =>
                        `<span class="badge bg-primary me-1">${r.name || r}</span>`
                    ).join('')}
                </td>
                <td>
                    <span class="badge bg-${u.isActive ? 'success' : 'secondary'}">
                        ${u.isActive ? 'فعال' : 'غیرفعال'}
                    </span>
                </td>
                <td>${ITopWrapper.toFarsiDate(u.lastLogin)}</td>
                <td>
                    <div class="btn-group btn-group-sm">
                        <button class="btn btn-outline-primary" onclick="UserManager.editUser(${u.id})" title="ویرایش">
                            <i class="bi bi-pencil"></i>
                        </button>
                        <button class="btn btn-outline-${u.isActive ? 'warning' : 'success'}"
                                onclick="UserManager.toggleUser(${u.id}, ${!u.isActive})"
                                title="${u.isActive ? 'غیرفعال‌سازی' : 'فعال‌سازی'}">
                            <i class="bi bi-${u.isActive ? 'pause' : 'play'}-fill"></i>
                        </button>
                        <button class="btn btn-outline-danger"
                                onclick="ITopWrapper.confirmDelete('${u.username}', () => UserManager.deleteUser(${u.id}))"
                                title="حذف">
                            <i class="bi bi-trash"></i>
                        </button>
                    </div>
                </td>
            </tr>`).join('') || '<tr><td colspan="8" class="text-center text-muted py-4">کاربری یافت نشد</td></tr>';
    },

    async toggleUser(id, active) {
        try {
            await ITopWrapper.apiRequest(`/api/admin/users/${id}/toggle-active`, 'POST', { active });
            ITopWrapper.showToast(active ? 'کاربر فعال شد' : 'کاربر غیرفعال شد', 'success');
            this.loadUsers();
        } catch (e) {
            ITopWrapper.showToast('خطا در تغییر وضعیت کاربر', 'danger');
        }
    },

    async deleteUser(id) {
        try {
            await ITopWrapper.apiRequest(`/api/admin/users/${id}`, 'DELETE');
            ITopWrapper.showToast('کاربر حذف شد', 'success');
            this.loadUsers();
        } catch (e) {
            ITopWrapper.showToast('خطا در حذف کاربر', 'danger');
        }
    },

    editUser(id) {
        window.location.href = `/admin/users/${id}/edit`;
    }
};

// ===== مدیریت کاتالوگ خدمات =====
const ServiceCatalog = {
    async loadCategories() {
        try {
            const cats = await ITopWrapper.apiRequest('/api/admin/service-categories');
            this.renderCategoryTree(cats);
        } catch (e) {
            ITopWrapper.showToast('خطا در بارگذاری دسته‌بندی‌ها', 'danger');
        }
    },

    renderCategoryTree(categories) {
        const container = document.getElementById('categoryTree');
        if (!container) return;
        container.innerHTML = this.buildTree(categories, null);
    },

    buildTree(cats, parentId) {
        const children = cats.filter(c => c.parentId == parentId);
        if (!children.length) return '';
        return `<ul class="list-unstyled ps-3">
            ${children.map(c => `
                <li class="py-1">
                    <div class="d-flex align-items-center">
                        <i class="bi bi-folder text-warning me-2"></i>
                        <span class="fw-semibold">${c.name}</span>
                        <div class="ms-auto btn-group btn-group-sm">
                            <button class="btn btn-outline-primary btn-sm" onclick="ServiceCatalog.addSub(${c.id})">
                                <i class="bi bi-plus"></i>
                            </button>
                            <button class="btn btn-outline-secondary btn-sm" onclick="ServiceCatalog.editCat(${c.id})">
                                <i class="bi bi-pencil"></i>
                            </button>
                        </div>
                    </div>
                    ${this.buildTree(cats, c.id)}
                </li>`).join('')}
        </ul>`;
    },

    addSub(parentId) {
        const name = prompt('نام زیردسته:');
        if (!name) return;
        ITopWrapper.apiRequest('/api/admin/service-categories', 'POST', { name, parentId })
            .then(() => { ITopWrapper.showToast('زیردسته افزوده شد', 'success'); this.loadCategories(); })
            .catch(() => ITopWrapper.showToast('خطا در افزودن زیردسته', 'danger'));
    },

    editCat(id) { window.location.href = `/admin/services/category/${id}/edit`; }
};

// ===== محاسبه قیمت پویا در پرتال =====
const PricingCalculator = {
    serviceId: null,
    debounceTimer: null,

    init(serviceId) {
        this.serviceId = serviceId;
        document.querySelectorAll('[data-pricing-input]').forEach(el => {
            el.addEventListener('change', () => this.calculate());
            el.addEventListener('input', () => {
                clearTimeout(this.debounceTimer);
                this.debounceTimer = setTimeout(() => this.calculate(), 600);
            });
        });
    },

    async calculate() {
        if (!this.serviceId) return;
        const tier = document.getElementById('customerTier')?.value || 'BRONZE';
        const params = new URLSearchParams({ tier });
        document.querySelectorAll('[data-pricing-input]').forEach(el => {
            params.append(el.name, el.value);
        });

        try {
            const res = await fetch(`/portal/service/${this.serviceId}/calculate-price`, {
                method: 'POST',
                headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
                body: params
            });
            const data = await res.json();
            this.updateDisplay(data);
        } catch (e) { /* نادیده گرفتن خطاهای شبکه */ }
    },

    updateDisplay(data) {
        const set = (id, val) => { const el = document.getElementById(id); if (el) el.textContent = val; };
        set('finalPriceDisplay', ITopWrapper.formatNumber(data.finalPrice) + ' ریال');
        set('discountDisplay', data.discountPercent + '٪');
        set('breakdownDisplay', data.breakdown);
        set('basePriceDisplay', ITopWrapper.formatNumber(data.basePrice) + ' ریال');
    }
};

// ===== لاگ‌های سامانه =====
const LogViewer = {
    currentPage: 0,
    pageSize: 50,
    filters: {},

    async loadLogs(page = 0) {
        const params = new URLSearchParams({
            page, size: this.pageSize, ...this.filters
        });
        try {
            const data = await ITopWrapper.apiRequest(`/api/admin/logs?${params}`);
            this.renderLogs(data.content || data);
        } catch (e) {
            ITopWrapper.showToast('خطا در بارگذاری لاگ‌ها', 'danger');
        }
    },

    renderLogs(logs) {
        const tbody = document.getElementById('logsTableBody');
        if (!tbody) return;
        tbody.innerHTML = logs.map(log => `
            <tr class="log-row-${log.level?.toLowerCase()}">
                <td class="small text-muted">${ITopWrapper.toFarsiDate(log.createdAt)}</td>
                <td><span class="badge bg-${this.levelColor(log.level)}">${log.level}</span></td>
                <td>${log.username || '-'}</td>
                <td>${log.action}</td>
                <td><span class="badge bg-secondary">${log.module || '-'}</span></td>
                <td class="small">${log.description || ''}</td>
                <td>${log.ipAddress || '-'}</td>
                <td>
                    <span class="badge bg-${log.success ? 'success' : 'danger'}">
                        ${log.success ? 'موفق' : 'ناموفق'}
                    </span>
                </td>
            </tr>`).join('') || '<tr><td colspan="8" class="text-center py-4 text-muted">لاگی یافت نشد</td></tr>';
    },

    levelColor(level) {
        return { INFO:'primary', WARN:'warning', ERROR:'danger', SECURITY:'dark', DEBUG:'secondary' }[level] || 'secondary';
    },

    applyFilter() {
        this.filters.level  = document.getElementById('logLevelFilter')?.value || '';
        this.filters.module = document.getElementById('logModuleFilter')?.value || '';
        this.filters.search = document.getElementById('logSearch')?.value || '';
        this.loadLogs(0);
    }
};

// ===== راه‌اندازی خودکار بر اساس صفحه جاری =====
document.addEventListener('DOMContentLoaded', () => {
    const path = window.location.pathname;

    if (path.includes('/admin/users'))        UserManager.loadUsers();
    if (path.includes('/admin/services'))     ServiceCatalog.loadCategories();
    if (path.includes('/admin/logs'))         LogViewer.loadLogs();

    // فعال‌سازی tooltip‌های Bootstrap
    document.querySelectorAll('[data-bs-toggle="tooltip"]').forEach(el =>
        new bootstrap.Tooltip(el));

    // نمایش پیام‌های flash
    const flash = document.querySelector('[data-flash-message]');
    if (flash) {
        ITopWrapper.showToast(flash.dataset.flashMessage, flash.dataset.flashType || 'info');
    }
});
