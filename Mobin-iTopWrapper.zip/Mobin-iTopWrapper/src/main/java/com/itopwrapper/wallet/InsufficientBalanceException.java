package com.itopwrapper.wallet;

import java.math.BigDecimal;

/** زمانی‌که موجودی کیف‌پول (با احتساب سقف اعتباری) برای پوشش مبلغ خرید کافی نباشد */
public class InsufficientBalanceException extends WalletException {
    private final BigDecimal available;
    private final BigDecimal requested;

    public InsufficientBalanceException(BigDecimal available, BigDecimal requested) {
        super(String.format("موجودی کیف‌پول کافی نیست — موجودی قابل برداشت: %s ریال، مبلغ مورد نیاز: %s ریال",
            available, requested));
        this.available = available;
        this.requested = requested;
    }

    public BigDecimal getAvailable() { return available; }
    public BigDecimal getRequested() { return requested; }
    public BigDecimal getShortfall() { return requested.subtract(available); }
}
