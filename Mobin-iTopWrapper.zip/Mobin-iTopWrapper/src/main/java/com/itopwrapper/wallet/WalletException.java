package com.itopwrapper.wallet;

/** خطای عمومی عملیات کیف‌پول */
public class WalletException extends RuntimeException {
    public WalletException(String message) { super(message); }
}
