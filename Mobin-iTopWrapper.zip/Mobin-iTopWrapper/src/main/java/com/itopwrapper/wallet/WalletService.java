package com.itopwrapper.wallet;

import com.itopwrapper.audit.AuditService;
import com.itopwrapper.model.entity.*;
import com.itopwrapper.repository.UserRepository;
import com.itopwrapper.repository.WalletRepository;
import com.itopwrapper.repository.WalletTransactionRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

/**
 * سرویس مرکزی مدیریت کیف‌پول مشتریان.
 *
 * منطق کسر اعتبار:
 *  - IMMEDIATE  → purchase(): بلافاصله از موجودی کسر می‌شود (PURCHASE).
 *  - ON_APPROVAL→ hold() هنگام ثبت درخواست، سپس capture() پس از تأیید/رفع
 *                 یا release() در صورت رد/لغو توسط اپراتور.
 *
 * تمام عملیات تغییر موجودی از طریق قفل بدبینانه ردیف ({@link WalletRepository#findByUserIdForUpdate})
 * انجام می‌شود تا در صورت درخواست‌های همزمان، Race Condition رخ ندهد.
 */
@Service
@Slf4j
@RequiredArgsConstructor
public class WalletService {

    private final WalletRepository walletRepository;
    private final WalletTransactionRepository transactionRepository;
    private final UserRepository userRepository;
    private final AuditService auditService;

    // ===================================================================
    //  ایجاد / دریافت کیف‌پول
    // ===================================================================

    /** دریافت کیف‌پول کاربر؛ در صورت نبود، یک کیف‌پول صفر با ارز پیش‌فرض ایجاد می‌شود */
    @Transactional
    public Wallet getOrCreateWallet(Long userId) {
        return walletRepository.findByUserId(userId).orElseGet(() -> {
            User user = userRepository.findById(userId)
                .orElseThrow(() -> new WalletException("کاربر یافت نشد: " + userId));
            Wallet wallet = Wallet.builder()
                .user(user)
                .balance(BigDecimal.ZERO)
                .heldAmount(BigDecimal.ZERO)
                .creditLimit(BigDecimal.ZERO)
                .currency("IRR")
                .isActive(true)
                .build();
            wallet = walletRepository.save(wallet);
            log.info("کیف‌پول جدید برای کاربر {} ایجاد شد", user.getUsername());
            return wallet;
        });
    }

    public Optional<Wallet> findByUserId(Long userId) {
        return walletRepository.findByUserId(userId);
    }

    // ===================================================================
    //  عملیات ادمین: شارژ / کسر دستی / تنظیم سقف اعتباری
    // ===================================================================

    /** شارژ کیف‌پول توسط سوپرادمین یا ادمین محلی */
    @Transactional
    public WalletTransaction topUp(Long userId, BigDecimal amount, String description,
                                    String performedBy, String ip) {
        if (amount == null || amount.compareTo(BigDecimal.ZERO) <= 0) {
            throw new WalletException("مبلغ شارژ باید مثبت باشد");
        }
        Wallet wallet = lockWallet(userId);
        BigDecimal before = wallet.getBalance();
        wallet.setBalance(before.add(amount));
        walletRepository.save(wallet);

        WalletTransaction tx = recordTransaction(wallet, WalletTransaction.TransactionType.TOP_UP,
            amount, before, wallet.getBalance(), description, null, null, performedBy, ip);

        auditService.log("WALLET_TOP_UP", "WALLET", wallet.getId(), performedBy,
            String.format("شارژ %s ریال برای کاربر %s — موجودی جدید: %s",
                amount, wallet.getUser().getUsername(), wallet.getBalance()), ip, true);
        return tx;
    }

    /** کسر دستی توسط ادمین (مثلاً اصلاح خطا یا جریمه) */
    @Transactional
    public WalletTransaction adminDeduct(Long userId, BigDecimal amount, String description,
                                          String performedBy, String ip) {
        if (amount == null || amount.compareTo(BigDecimal.ZERO) <= 0) {
            throw new WalletException("مبلغ کسر باید مثبت باشد");
        }
        Wallet wallet = lockWallet(userId);
        if (!wallet.canAfford(amount)) {
            throw new WalletException("موجودی کافی نیست — حداکثر قابل کسر: " + wallet.getMaxWithdrawable());
        }
        BigDecimal before = wallet.getBalance();
        wallet.setBalance(before.subtract(amount));
        walletRepository.save(wallet);

        WalletTransaction tx = recordTransaction(wallet, WalletTransaction.TransactionType.ADMIN_DEDUCT,
            amount, before, wallet.getBalance(), description, null, null, performedBy, ip);

        auditService.log("WALLET_ADMIN_DEDUCT", "WALLET", wallet.getId(), performedBy,
            String.format("کسر دستی %s ریال از کاربر %s", amount, wallet.getUser().getUsername()), ip, true);
        return tx;
    }

    /** تنظیم سقف اعتباری مجاز (می‌تواند کیف‌پول را تا این مقدار منفی کند) */
    @Transactional
    public Wallet setCreditLimit(Long userId, BigDecimal creditLimit, String performedBy, String ip) {
        if (creditLimit == null || creditLimit.compareTo(BigDecimal.ZERO) < 0) {
            throw new WalletException("سقف اعتباری نمی‌تواند منفی باشد");
        }
        Wallet wallet = lockWallet(userId);
        BigDecimal old = wallet.getCreditLimit();
        wallet.setCreditLimit(creditLimit);
        wallet = walletRepository.save(wallet);

        auditService.log("WALLET_CREDIT_LIMIT_CHANGE", "WALLET", wallet.getId(), performedBy,
            String.format("تغییر سقف اعتباری کاربر %s از %s به %s",
                wallet.getUser().getUsername(), old, creditLimit), ip, true);
        return wallet;
    }

    /** فعال/غیرفعال‌سازی کیف‌پول (غیرفعال = امکان خرید جدید مسدود است) */
    @Transactional
    public Wallet setActive(Long userId, boolean active, String performedBy, String ip) {
        Wallet wallet = lockWallet(userId);
        wallet.setIsActive(active);
        wallet = walletRepository.save(wallet);
        auditService.log(active ? "WALLET_ACTIVATE" : "WALLET_DEACTIVATE", "WALLET", wallet.getId(),
            performedBy, "کیف‌پول کاربر " + wallet.getUser().getUsername(), ip, true);
        return wallet;
    }

    // ===================================================================
    //  عملیات خرید خدمت (مصرف‌کننده اصلی: ServiceRequestService)
    // ===================================================================

    /** کسر فوری بابت خرید خدمت (مدل IMMEDIATE) */
    @Transactional
    public WalletTransaction purchase(Long userId, BigDecimal amount, ServiceRequest request,
                                       String description, String performedBy, String ip) {
        if (amount == null || amount.compareTo(BigDecimal.ZERO) <= 0) {
            // خدمت رایگان — هیچ تراکنشی لازم نیست
            return null;
        }
        Wallet wallet = lockWallet(userId);
        if (!wallet.getIsActive()) throw new WalletException("کیف‌پول غیرفعال است");
        if (!wallet.canAfford(amount)) {
            throw new InsufficientBalanceException(wallet.getMaxWithdrawable(), amount);
        }
        BigDecimal before = wallet.getBalance();
        wallet.setBalance(before.subtract(amount));
        walletRepository.save(wallet);

        return recordTransaction(wallet, WalletTransaction.TransactionType.PURCHASE,
            amount, before, wallet.getBalance(), description, request, null, performedBy, ip);
    }

    /** مسدودسازی (Hold) اعتبار برای خدماتی که کسر آن‌ها پس از تأیید است (مدل ON_APPROVAL) */
    @Transactional
    public WalletTransaction hold(Long userId, BigDecimal amount, ServiceRequest request,
                                   String description, String performedBy, String ip) {
        if (amount == null || amount.compareTo(BigDecimal.ZERO) <= 0) return null;

        Wallet wallet = lockWallet(userId);
        if (!wallet.getIsActive()) throw new WalletException("کیف‌پول غیرفعال است");
        if (!wallet.canAfford(amount)) {
            throw new InsufficientBalanceException(wallet.getMaxWithdrawable(), amount);
        }
        BigDecimal before = wallet.getBalance();
        wallet.setHeldAmount(wallet.getHeldAmount().add(amount));
        walletRepository.save(wallet);

        // در حالت Hold، balance تغییر نمی‌کند ولی availableBalance کاهش می‌یابد —
        // برای شفافیت گزارش، before/after را برابر balance فعلی ثبت می‌کنیم
        return recordTransaction(wallet, WalletTransaction.TransactionType.HOLD,
            amount, before, wallet.getBalance(), description, request, null, performedBy, ip);
    }

    /** نهایی‌سازی مبلغ Hold شده — هنگام تأیید/رفع درخواست توسط اپراتور */
    @Transactional
    public WalletTransaction capture(ServiceRequest request, String performedBy, String ip) {
        WalletTransaction holdTx = findOpenHoldForRequest(request);
        if (holdTx == null) {
            log.warn("هیچ تراکنش HOLD باز برای درخواست {} یافت نشد", request.getTicketNumber());
            return null;
        }
        Wallet wallet = lockWallet(holdTx.getWallet().getUser().getId());
        BigDecimal amount = holdTx.getAmount();

        wallet.setHeldAmount(wallet.getHeldAmount().subtract(amount));
        BigDecimal before = wallet.getBalance();
        wallet.setBalance(before.subtract(amount));
        walletRepository.save(wallet);

        WalletTransaction captureTx = recordTransaction(wallet, WalletTransaction.TransactionType.CAPTURE,
            amount, before, wallet.getBalance(),
            "نهایی‌سازی مبلغ مسدودشده — درخواست " + request.getTicketNumber(),
            request, holdTx, performedBy, ip);

        auditService.log("WALLET_CAPTURE", "WALLET", wallet.getId(), performedBy,
            String.format("کسر نهایی %s ریال بابت درخواست %s", amount, request.getTicketNumber()), ip, true);
        return captureTx;
    }

    /** آزادسازی مبلغ Hold شده — هنگام رد/لغو درخواست */
    @Transactional
    public WalletTransaction release(ServiceRequest request, String performedBy, String ip) {
        WalletTransaction holdTx = findOpenHoldForRequest(request);
        if (holdTx == null) {
            log.warn("هیچ تراکنش HOLD باز برای درخواست {} یافت نشد", request.getTicketNumber());
            return null;
        }
        Wallet wallet = lockWallet(holdTx.getWallet().getUser().getId());
        BigDecimal amount = holdTx.getAmount();

        wallet.setHeldAmount(wallet.getHeldAmount().subtract(amount));
        walletRepository.save(wallet);

        WalletTransaction releaseTx = recordTransaction(wallet, WalletTransaction.TransactionType.RELEASE,
            amount, wallet.getBalance(), wallet.getBalance(),
            "آزادسازی مبلغ مسدودشده — درخواست " + request.getTicketNumber(),
            request, holdTx, performedBy, ip);

        auditService.log("WALLET_RELEASE", "WALLET", wallet.getId(), performedBy,
            String.format("آزادسازی %s ریال بابت لغو/رد درخواست %s", amount, request.getTicketNumber()), ip, true);
        return releaseTx;
    }

    /** بازگشت وجه برای درخواستی که قبلاً مبلغش نهایی کسر شده (PURCHASE یا CAPTURE) */
    @Transactional
    public WalletTransaction refund(ServiceRequest request, BigDecimal amount, String reason,
                                     String performedBy, String ip) {
        Wallet wallet = lockWallet(request.getRequester().getId());
        BigDecimal before = wallet.getBalance();
        wallet.setBalance(before.add(amount));
        walletRepository.save(wallet);

        WalletTransaction tx = recordTransaction(wallet, WalletTransaction.TransactionType.REFUND,
            amount, before, wallet.getBalance(), reason, request, null, performedBy, ip);

        auditService.log("WALLET_REFUND", "WALLET", wallet.getId(), performedBy,
            String.format("بازگشت %s ریال بابت درخواست %s — دلیل: %s",
                amount, request.getTicketNumber(), reason), ip, true);
        return tx;
    }

    // ===================================================================
    //  گزارش‌گیری
    // ===================================================================

    public Page<WalletTransaction> getHistory(Long userId, Pageable pageable) {
        Wallet wallet = getOrCreateWallet(userId);
        return transactionRepository.findByWalletOrderByCreatedAtDesc(wallet, pageable);
    }

    public Page<WalletTransaction> getAllTransactions(Pageable pageable) {
        return transactionRepository.findAllByOrderByCreatedAtDesc(pageable);
    }

    public List<Wallet> getLowBalanceWallets() {
        return walletRepository.findLowBalanceWallets();
    }

    // ===================================================================
    //  داخلی
    // ===================================================================

    private Wallet lockWallet(Long userId) {
        // اطمینان از وجود کیف‌پول قبل از قفل
        getOrCreateWallet(userId);
        return walletRepository.findByUserIdForUpdate(userId)
            .orElseThrow(() -> new WalletException("کیف‌پول یافت نشد برای کاربر: " + userId));
    }

    private WalletTransaction findOpenHoldForRequest(ServiceRequest request) {
        if (request.getWalletTransactionId() == null) return null;
        return transactionRepository.findById(request.getWalletTransactionId()).orElse(null);
    }

    private WalletTransaction recordTransaction(Wallet wallet, WalletTransaction.TransactionType type,
                                                 BigDecimal amount, BigDecimal before, BigDecimal after,
                                                 String description, ServiceRequest request,
                                                 WalletTransaction relatedTx, String performedBy, String ip) {
        WalletTransaction tx = WalletTransaction.builder()
            .wallet(wallet)
            .type(type)
            .amount(amount)
            .balanceBefore(before)
            .balanceAfter(after)
            .description(description)
            .serviceRequest(request)
            .relatedTransaction(relatedTx)
            .performedBy(performedBy)
            .ipAddress(ip)
            .build();
        return transactionRepository.save(tx);
    }
}
