package com.itopwrapper.pricing;

import lombok.*;
import java.math.BigDecimal;

@Getter @Setter
@Builder
@NoArgsConstructor @AllArgsConstructor
public class PricingResult {
    private BigDecimal basePrice;
    private BigDecimal calculatedPrice;
    private BigDecimal discountPercent;
    private BigDecimal discountAmount;
    private BigDecimal finalPrice;
    private String currency;
    private String breakdown;
    private PricingEngine.CustomerTier customerTier;
}
