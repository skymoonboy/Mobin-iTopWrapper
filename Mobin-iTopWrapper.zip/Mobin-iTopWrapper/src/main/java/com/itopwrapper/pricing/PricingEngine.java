package com.itopwrapper.pricing;

import com.itopwrapper.model.entity.ServiceItem;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import javax.script.ScriptEngine;
import javax.script.ScriptEngineManager;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.Map;

/**
 * موتور قیمت‌گذاری خدمات
 * محاسبه قیمت نهایی خدمات بر اساس مدل‌های مختلف قیمت‌گذاری
 */
@Service
@Slf4j
public class PricingEngine {

    private final ScriptEngineManager scriptEngineManager = new ScriptEngineManager();

    /**
     * محاسبه قیمت خدمت بر اساس مدل قیمت‌گذاری
     *
     * @param serviceItem  آیتم خدمت
     * @param params       پارامترهای محاسبه (تعداد کاربر، ساعت، ماه و ...)
     * @param customerTier سطح مشتری (BRONZE, SILVER, GOLD, PLATINUM)
     */
    public PricingResult calculatePrice(ServiceItem serviceItem,
                                        Map<String, Object> params,
                                        CustomerTier customerTier) {
        BigDecimal basePrice = serviceItem.getBasePrice();
        BigDecimal finalPrice;
        String breakdown;

        switch (serviceItem.getPricingModel()) {
            case FIXED -> {
                finalPrice = basePrice;
                breakdown = "قیمت ثابت: " + formatPrice(basePrice);
            }
            case HOURLY -> {
                int hours = getIntParam(params, "hours", 1);
                finalPrice = basePrice.multiply(BigDecimal.valueOf(hours));
                breakdown = "ساعتی: " + formatPrice(basePrice) + " × " + hours + " ساعت";
            }
            case MONTHLY -> {
                int months = getIntParam(params, "months", 1);
                finalPrice = basePrice.multiply(BigDecimal.valueOf(months));
                breakdown = "ماهانه: " + formatPrice(basePrice) + " × " + months + " ماه";
            }
            case PER_USER -> {
                int users = getIntParam(params, "users", 1);
                finalPrice = basePrice.multiply(BigDecimal.valueOf(users));
                breakdown = "به ازای کاربر: " + formatPrice(basePrice) + " × " + users + " کاربر";
            }
            case TIERED -> {
                int quantity = getIntParam(params, "quantity", 1);
                finalPrice = calculateTieredPrice(basePrice, quantity);
                breakdown = "قیمت‌گذاری پله‌ای برای " + quantity + " واحد";
            }
            case FORMULA -> {
                finalPrice = calculateFormulaPrice(serviceItem.getPricingFormula(), params, basePrice);
                breakdown = "محاسبه فرمول: " + serviceItem.getPricingFormula();
            }
            default -> {
                finalPrice = basePrice;
                breakdown = "قیمت پیش‌فرض";
            }
        }

        // اعمال تخفیف بر اساس سطح مشتری
        BigDecimal discount = getCustomerDiscount(customerTier);
        BigDecimal discountAmount = finalPrice.multiply(discount);
        BigDecimal discountedPrice = finalPrice.subtract(discountAmount);

        return PricingResult.builder()
            .basePrice(basePrice)
            .calculatedPrice(finalPrice)
            .discountPercent(discount.multiply(BigDecimal.valueOf(100)))
            .discountAmount(discountAmount)
            .finalPrice(discountedPrice.setScale(0, RoundingMode.HALF_UP))
            .currency(serviceItem.getCurrency())
            .breakdown(breakdown)
            .customerTier(customerTier)
            .build();
    }

    private BigDecimal calculateTieredPrice(BigDecimal basePrice, int quantity) {
        // تخفیف پله‌ای
        BigDecimal multiplier;
        if (quantity >= 100)      multiplier = BigDecimal.valueOf(0.7);
        else if (quantity >= 50)  multiplier = BigDecimal.valueOf(0.8);
        else if (quantity >= 20)  multiplier = BigDecimal.valueOf(0.9);
        else if (quantity >= 10)  multiplier = BigDecimal.valueOf(0.95);
        else                      multiplier = BigDecimal.ONE;

        return basePrice.multiply(BigDecimal.valueOf(quantity)).multiply(multiplier);
    }

    private BigDecimal calculateFormulaPrice(String formula, Map<String, Object> params, BigDecimal basePrice) {
        if (formula == null || formula.isBlank()) return basePrice;
        try {
            ScriptEngine engine = scriptEngineManager.getEngineByName("rhino");
            if (engine == null) {
                log.warn("موتور اسکریپت Rhino در دسترس نیست، از قیمت پایه استفاده می‌شود");
                return basePrice;
            }
            engine.put("basePrice", basePrice.doubleValue());
            params.forEach((k, v) -> {
                if (v instanceof Number n) engine.put(k, n.doubleValue());
            });
            Object result = engine.eval(formula);
            return BigDecimal.valueOf(((Number) result).doubleValue());
        } catch (Exception e) {
            log.error("خطا در محاسبه فرمول قیمت: {}", e.getMessage());
            return basePrice;
        }
    }

    private BigDecimal getCustomerDiscount(CustomerTier tier) {
        if (tier == null) return BigDecimal.ZERO;
        return switch (tier) {
            case BRONZE   -> BigDecimal.ZERO;
            case SILVER   -> new BigDecimal("0.05");
            case GOLD     -> new BigDecimal("0.10");
            case PLATINUM -> new BigDecimal("0.15");
        };
    }

    private int getIntParam(Map<String, Object> params, String key, int defaultVal) {
        Object val = params.get(key);
        if (val instanceof Number n) return n.intValue();
        if (val instanceof String s) {
            try { return Integer.parseInt(s); } catch (NumberFormatException ignore) {}
        }
        return defaultVal;
    }

    private String formatPrice(BigDecimal price) {
        return String.format("%,.0f", price) + " ریال";
    }

    public enum CustomerTier {
        BRONZE, SILVER, GOLD, PLATINUM
    }
}
