package com.itopwrapper;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.cache.annotation.EnableCaching;
import org.springframework.scheduling.annotation.EnableAsync;
import org.springframework.scheduling.annotation.EnableScheduling;
import org.springframework.transaction.annotation.EnableTransactionManagement;

/**
 * نقطه ورودی اصلی سامانه مدیریت خدمات فناوری اطلاعات (iTop Wrapper)
 * این سامانه یک پوشش‌دهنده حرفه‌ای برای موتور iTop با معماری MVC می‌باشد
 */
@SpringBootApplication
@EnableCaching
@EnableAsync
@EnableScheduling
@EnableTransactionManagement
public class ITopWrapperApplication {

    public static void main(String[] args) {
        SpringApplication.run(ITopWrapperApplication.class, args);
    }
}
