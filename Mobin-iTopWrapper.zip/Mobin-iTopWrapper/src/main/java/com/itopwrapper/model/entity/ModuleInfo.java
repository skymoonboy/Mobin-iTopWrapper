package com.itopwrapper.model.entity;

import jakarta.persistence.*;
import lombok.*;
import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.UpdateTimestamp;

import java.time.LocalDateTime;

/**
 * موجودیت ماژول‌های قابل نصب در سامانه
 */
@Entity
@Table(name = "modules")
@Getter @Setter
@NoArgsConstructor @AllArgsConstructor
@Builder
public class ModuleInfo {

    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "module_seq")
    @SequenceGenerator(name = "module_seq", sequenceName = "seq_modules", allocationSize = 1)
    private Long id;

    @Column(nullable = false, unique = true, length = 100)
    private String moduleId;

    @Column(nullable = false, length = 200)
    private String name;

    @Column(length = 1000)
    private String description;

    @Column(length = 50)
    private String version;

    @Column(length = 200)
    private String author;

    @Column(name = "jar_path", length = 500)
    private String jarPath;

    @Column(name = "config_schema", columnDefinition = "TEXT")
    private String configSchema;

    @Column(name = "config_values", columnDefinition = "TEXT")
    private String configValues;

    @Enumerated(EnumType.STRING)
    @Column(name = "status", length = 20)
    @Builder.Default
    private ModuleStatus status = ModuleStatus.INSTALLED;

    @Column(name = "entry_point_class", length = 300)
    private String entryPointClass;

    @Column(name = "requires_restart")
    @Builder.Default
    private Boolean requiresRestart = false;

    @Column(name = "installed_by", length = 100)
    private String installedBy;

    @CreationTimestamp
    @Column(name = "created_at", updatable = false)
    private LocalDateTime createdAt;

    @UpdateTimestamp
    @Column(name = "updated_at")
    private LocalDateTime updatedAt;

    public enum ModuleStatus {
        INSTALLED, ACTIVE, INACTIVE, ERROR, UPDATING
    }
}
