package com.itopwrapper.model.entity;

import jakarta.persistence.*;
import lombok.*;
import org.hibernate.annotations.CreationTimestamp;

import java.time.LocalDateTime;

/**
 * نظرات و پیگیری درخواست خدمت
 */
@Entity
@Table(name = "request_comments")
@Getter @Setter
@NoArgsConstructor @AllArgsConstructor
@Builder
public class RequestComment {

    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "rc_seq")
    @SequenceGenerator(name = "rc_seq", sequenceName = "seq_request_comments", allocationSize = 1)
    private Long id;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "request_id", nullable = false)
    private ServiceRequest request;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "author_id", nullable = false)
    private User author;

    @Column(columnDefinition = "TEXT", nullable = false)
    private String content;

    @Enumerated(EnumType.STRING)
    @Column(name = "comment_type", length = 30)
    @Builder.Default
    private CommentType commentType = CommentType.PUBLIC;

    @Column(name = "itop_log_id")
    private Long itopLogId;

    @CreationTimestamp
    @Column(name = "created_at", updatable = false)
    private LocalDateTime createdAt;

    public enum CommentType {
        PUBLIC,   // قابل مشاهده توسط مشتری
        PRIVATE,  // داخلی (فقط اپراتورها)
        SYSTEM    // خودکار توسط سامانه
    }
}
