package com.itopwrapper.model.dto;

import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Positive;
import lombok.*;

import java.math.BigDecimal;

@Getter @Setter @Builder @NoArgsConstructor @AllArgsConstructor
public class WalletTopUpRequest {
    @NotNull private Long userId;
    @NotNull @Positive private BigDecimal amount;
    private String description;
}
