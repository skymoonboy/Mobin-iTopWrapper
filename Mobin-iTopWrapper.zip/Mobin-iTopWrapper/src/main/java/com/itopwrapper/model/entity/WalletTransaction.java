package com.itopwrapper.model.entity;

import jakarta.persistence.*;
import lombok.*;
import org.hibernate.annotations.CreationTimestamp;

import java.math.BigDecimal;
import java.time.LocalDateTime;

/**
 * یک رکورد گردش‌حساب کیف‌پول (واریز/برداشت/مسدودسازی/آزادسازی/بازگشت وجه).
 * هر رکورد، موجودی پیش و پس از تراکنش را هم ذخیره می‌کند تا
 * صورت‌حساب قابل حسابرسی و غیرقابل‌دستکاری باشد (Immutable Ledger).
 */
@Entity
@Table(name = "wallet_transactions", indexes = {
    @Index(name = "idx_wt_wallet",   columnList = "wallet_id"),
    @Index(name = "idx_wt_type",     columnList = "type"),
    @Index(name = "idx_wt_created",  columnList = "created_at"),
    @Index(name = "idx_wt_request",  columnList = "service_request_id")
})
@Getter @Setter
@NoArgsConstructor @AllArgsConstructor
@Builder
public class WalletTransaction {

    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "wtx_seq")
    @SequenceGenerator(name = "wtx_seq", sequenceName = "seq_wallet_transactions", allocationSize = 1)
    private Long id;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "wallet_id", nullable = false)
    private Wallet wallet;

    @Enumerated(EnumType.STRING)
    @Column(name = "type", nullable = false, length = 30)
    private TransactionType type;

    /** مبلغ تراکنش — همیشه مثبت ذخیره می‌شود؛ جهت با {@link #type} مشخص می‌شود */
    @Column(name = "amount", precision = 18, scale = 2, nullable = false)
    private BigDecimal amount;

    @Column(name = "balance_before", precision = 18, scale = 2, nullable = false)
    private BigDecimal balanceBefore;

    @Column(name = "balance_after", precision = 18, scale = 2, nullable = false)
    private BigDecimal balanceAfter;

    @Column(name = "description", length = 1000)
    private String description;

    /** ارجاع به درخواست خدمتی که باعث این تراکنش شده (در صورت وجود) */
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "service_request_id")
    private ServiceRequest serviceRequest;

    /** برای تراکنش‌های HOLD/RELEASE، اشاره به رکورد HOLD اولیه */
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "related_transaction_id")
    private WalletTransaction relatedTransaction;

    /** کاربری که این تراکنش را انجام داده (ادمین شارژکننده یا "system" برای خودکار) */
    @Column(name = "performed_by", length = 100, nullable = false)
    private String performedBy;

    @Column(name = "ip_address", length = 50)
    private String ipAddress;

    @CreationTimestamp
    @Column(name = "created_at", updatable = false)
    private LocalDateTime createdAt;

    public enum TransactionType {
        TOP_UP,        // شارژ دستی توسط ادمین (افزایش اعتبار)
        ADMIN_DEDUCT,  // کسر دستی توسط ادمین
        PURCHASE,      // خرید خدمت — کسر فوری
        HOLD,          // مسدودسازی اعتبار برای خدمتی که کسر آن پس از تأیید است
        CAPTURE,       // نهایی‌سازی مبلغ Hold شده پس از تأیید درخواست
        RELEASE,       // آزادسازی مبلغ Hold شده (در صورت رد/لغو درخواست)
        REFUND,        // بازگشت وجه (مثلاً پس از لغو درخواست تکمیل‌شده)
        ADJUSTMENT     // اصلاح دستی موجودی (با ثبت دلیل)
    }
}
