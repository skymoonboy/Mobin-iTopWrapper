package com.itopwrapper.model.dto;

import jakarta.validation.constraints.NotBlank;
import lombok.*;

@Getter @Setter @Builder @NoArgsConstructor @AllArgsConstructor
public class AuthRequest {
    @NotBlank(message = "نام کاربری الزامی است")
    private String username;
    @NotBlank(message = "رمز عبور الزامی است")
    private String password;
    private String authType; // LOCAL یا LDAP
    private String ldapProviderId;
}
