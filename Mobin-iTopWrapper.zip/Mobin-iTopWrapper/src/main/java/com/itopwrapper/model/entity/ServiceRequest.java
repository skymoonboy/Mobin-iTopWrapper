package com.itopwrapper.model.entity;

import jakarta.persistence.*;
import lombok.*;
import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.UpdateTimestamp;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

/**
 * موجودیت درخواست خدمت (UserRequest در iTop)
 */
@Entity
@Table(name = "service_requests", indexes = {
    @Index(name = "idx_sr_requester", columnList = "requester_id"),
    @Index(name = "idx_sr_status",    columnList = "status"),
    @Index(name = "idx_sr_created",   columnList = "created_at")
})
@Getter @Setter
@NoArgsConstructor @AllArgsConstructor
@Builder
public class ServiceRequest {

    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "sr_seq")
    @SequenceGenerator(name = "sr_seq", sequenceName = "seq_service_requests", allocationSize = 1)
    private Long id;

    /** شماره درخواست خوانا برای نمایش */
    @Column(name = "ticket_number", unique = true, length = 30)
    private String ticketNumber;

    @Column(nullable = false, length = 500)
    private String title;

    @Column(columnDefinition = "TEXT")
    private String description;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "requester_id", nullable = false)
    private User requester;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "assignee_id")
    private User assignee;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "service_item_id")
    private ServiceItem serviceItem;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "sla_id")
    private SlaDefinition sla;

    @Enumerated(EnumType.STRING)
    @Column(name = "status", length = 30)
    @Builder.Default
    private RequestStatus status = RequestStatus.NEW;

    @Enumerated(EnumType.STRING)
    @Column(name = "priority", length = 20)
    @Builder.Default
    private Priority priority = Priority.MEDIUM;

    @Column(name = "agreed_price", precision = 15, scale = 2)
    private BigDecimal agreedPrice;

    @Column(name = "currency", length = 10)
    @Builder.Default
    private String currency = "IRR";

    /** وضعیت پرداخت از کیف‌پول برای این درخواست */
    @Enumerated(EnumType.STRING)
    @Column(name = "wallet_payment_status", length = 20)
    @Builder.Default
    private WalletPaymentStatus walletPaymentStatus = WalletPaymentStatus.NOT_APPLICABLE;

    /** شناسه تراکنش PURCHASE یا HOLD مربوط به این درخواست (برای رهگیری) */
    @Column(name = "wallet_transaction_id")
    private Long walletTransactionId;

    /** موعد پاسخ‌دهی بر اساس SLA */
    @Column(name = "response_deadline")
    private LocalDateTime responseDeadline;

    /** موعد رفع اشکال بر اساس SLA */
    @Column(name = "resolution_deadline")
    private LocalDateTime resolutionDeadline;

    @Column(name = "responded_at")
    private LocalDateTime respondedAt;

    @Column(name = "resolved_at")
    private LocalDateTime resolvedAt;

    @Column(name = "closed_at")
    private LocalDateTime closedAt;

    /** شناسه در موتور iTop */
    @Column(name = "itop_request_id")
    private Long itopRequestId;

    @Column(name = "itop_ref", length = 50)
    private String itopRef;

    @OneToMany(mappedBy = "request", cascade = CascadeType.ALL, orphanRemoval = true)
    @Builder.Default
    private List<RequestComment> comments = new ArrayList<>();

    @Column(name = "satisfaction_score")
    private Integer satisfactionScore;

    @Column(name = "satisfaction_comment", length = 1000)
    private String satisfactionComment;

    @CreationTimestamp
    @Column(name = "created_at", updatable = false)
    private LocalDateTime createdAt;

    @UpdateTimestamp
    @Column(name = "updated_at")
    private LocalDateTime updatedAt;

    public boolean isSlaBreached() {
        if (resolutionDeadline == null) return false;
        LocalDateTime compareTime = (resolvedAt != null) ? resolvedAt : LocalDateTime.now();
        return compareTime.isAfter(resolutionDeadline);
    }

    public enum RequestStatus {
        NEW,          // جدید
        ASSIGNED,     // تخصیص‌یافته
        IN_PROGRESS,  // در حال انجام
        PENDING,      // در انتظار
        RESOLVED,     // رفع‌شده
        CLOSED,       // بسته‌شده
        CANCELLED     // لغو‌شده
    }

    public enum Priority {
        LOW, MEDIUM, HIGH, CRITICAL
    }

    public enum WalletPaymentStatus {
        NOT_APPLICABLE,  // این درخواست هزینه‌ای از کیف‌پول ندارد
        HELD,            // مبلغ Hold شده — منتظر تأیید/رفع نهایی
        CAPTURED,        // مبلغ نهایی کسر شده (Capture یا Purchase فوری انجام شد)
        RELEASED,        // مبلغ Hold شده آزاد شد (به‌دلیل رد/لغو)
        REFUNDED         // مبلغ قبلاً کسرشده، بازگشت داده شد
    }
}
