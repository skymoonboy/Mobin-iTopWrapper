package com.itopwrapper.model.entity;

import jakarta.persistence.*;
import lombok.*;

import java.util.HashSet;
import java.util.Set;

/**
 * موجودیت نقش - مدیریت سطح دسترسی
 */
@Entity
@Table(name = "roles")
@Getter @Setter
@NoArgsConstructor @AllArgsConstructor
@Builder
public class Role {

    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "role_seq")
    @SequenceGenerator(name = "role_seq", sequenceName = "seq_roles", allocationSize = 1)
    private Long id;

    @Column(nullable = false, unique = true, length = 100)
    private String name;

    @Column(length = 500)
    private String description;

    @Column(name = "is_system_role")
    @Builder.Default
    private Boolean isSystemRole = false;

    @Column(name = "itop_profile_id")
    private Long itopProfileId;

    @ManyToMany(fetch = FetchType.EAGER)
    @JoinTable(name = "role_permissions",
        joinColumns = @JoinColumn(name = "role_id"),
        inverseJoinColumns = @JoinColumn(name = "permission_id"))
    @Builder.Default
    private Set<Permission> permissions = new HashSet<>();

    // نقش‌های پیش‌فرض سامانه
    public static final String ROLE_SUPER_ADMIN  = "ROLE_SUPER_ADMIN";
    public static final String ROLE_ADMIN        = "ROLE_ADMIN";
    public static final String ROLE_OPERATOR     = "ROLE_OPERATOR";
    public static final String ROLE_CUSTOMER     = "ROLE_CUSTOMER";
    public static final String ROLE_MANAGER      = "ROLE_MANAGER";
}
