package com.itopwrapper.model.entity;

import jakarta.persistence.*;
import lombok.*;
import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.UpdateTimestamp;

import java.math.BigDecimal;
import java.time.LocalDateTime;

/**
 * موجودیت خدمت در کاتالوگ
 */
@Entity
@Table(name = "service_items")
@Getter @Setter
@NoArgsConstructor @AllArgsConstructor
@Builder
public class ServiceItem {

    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "si_seq")
    @SequenceGenerator(name = "si_seq", sequenceName = "seq_service_items", allocationSize = 1)
    private Long id;

    @Column(nullable = false, length = 200)
    private String name;

    @Column(length = 2000)
    private String description;

    @Column(name = "short_description", length = 500)
    private String shortDescription;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "category_id", nullable = false)
    private ServiceCategory category;

    @Enumerated(EnumType.STRING)
    @Column(name = "service_type", length = 50)
    @Builder.Default
    private ServiceType serviceType = ServiceType.STANDARD;

    @Enumerated(EnumType.STRING)
    @Column(name = "pricing_model", length = 50)
    @Builder.Default
    private PricingModel pricingModel = PricingModel.FIXED;

    @Column(name = "base_price", precision = 15, scale = 2)
    @Builder.Default
    private BigDecimal basePrice = BigDecimal.ZERO;

    @Column(name = "currency", length = 10)
    @Builder.Default
    private String currency = "IRR";

    @Column(name = "sla_hours")
    private Integer slaHours;

    @Column(name = "ola_hours")
    private Integer olaHours;

    @Column(name = "delivery_time_days")
    private Integer deliveryTimeDays;

    @Column(name = "is_active")
    @Builder.Default
    private Boolean isActive = true;

    @Column(name = "is_featured")
    @Builder.Default
    private Boolean isFeatured = false;

    @Column(name = "icon_class", length = 100)
    private String iconClass;

    @Column(name = "itop_service_subcategory_id")
    private Long itopServiceSubcategoryId;

    @Column(name = "itop_service_id")
    private Long itopServiceId;

    @Column(name = "pricing_formula", length = 500)
    private String pricingFormula;

    @Column(name = "display_order")
    @Builder.Default
    private Integer displayOrder = 0;

    /**
     * آیا انتخاب این خدمت از کیف‌پول مشتری کسر اعتبار می‌کند؟
     * در صورت false، خدمت رایگان/خارج از کیف‌پول محسوب می‌شود.
     */
    @Column(name = "wallet_enabled")
    @Builder.Default
    private Boolean walletEnabled = true;

    /**
     * لحظه کسر اعتبار از کیف‌پول — قابل تنظیم در سطح هر خدمت:
     *  IMMEDIATE: همزمان با ثبت درخواست، مبلغ فوراً از کیف‌پول کسر می‌شود.
     *  ON_APPROVAL: مبلغ ابتدا Hold می‌شود و فقط با تأیید/رفع درخواست توسط اپراتور، نهایی (Capture) می‌شود؛
     *               در صورت رد/لغو درخواست، مبلغ Hold شده آزاد (Release) می‌شود.
     */
    @Enumerated(EnumType.STRING)
    @Column(name = "wallet_deduct_timing", length = 20)
    @Builder.Default
    private WalletDeductTiming walletDeductTiming = WalletDeductTiming.IMMEDIATE;

    @CreationTimestamp
    @Column(name = "created_at", updatable = false)
    private LocalDateTime createdAt;

    @UpdateTimestamp
    @Column(name = "updated_at")
    private LocalDateTime updatedAt;

    public enum ServiceType {
        STANDARD, PREMIUM, ENTERPRISE, CUSTOM
    }

    public enum PricingModel {
        FIXED,       // قیمت ثابت
        HOURLY,      // ساعتی
        MONTHLY,     // ماهانه
        PER_USER,    // به ازای هر کاربر
        TIERED,      // پله‌ای
        FORMULA      // فرمول محاسباتی
    }

    public enum WalletDeductTiming {
        IMMEDIATE,    // کسر فوری هنگام ثبت درخواست
        ON_APPROVAL   // Hold هنگام ثبت، Capture پس از تأیید/رفع توسط اپراتور
    }
}
