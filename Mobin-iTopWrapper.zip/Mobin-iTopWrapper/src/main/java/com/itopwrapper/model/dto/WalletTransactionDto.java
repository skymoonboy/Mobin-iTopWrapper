package com.itopwrapper.model.dto;

import com.itopwrapper.model.entity.WalletTransaction;
import lombok.*;

import java.math.BigDecimal;
import java.time.LocalDateTime;

/** نمایه ساده تراکنش کیف‌پول برای پاسخ API (بدون فیلدهای Lazy که می‌توانند خطا ایجاد کنند) */
@Getter @Setter @Builder @NoArgsConstructor @AllArgsConstructor
public class WalletTransactionDto {
    private Long id;
    private String type;
    private BigDecimal amount;
    private BigDecimal balanceBefore;
    private BigDecimal balanceAfter;
    private String description;
    private String ticketNumber;
    private String performedBy;
    private LocalDateTime createdAt;

    public static WalletTransactionDto from(WalletTransaction tx) {
        return WalletTransactionDto.builder()
            .id(tx.getId())
            .type(tx.getType().name())
            .amount(tx.getAmount())
            .balanceBefore(tx.getBalanceBefore())
            .balanceAfter(tx.getBalanceAfter())
            .description(tx.getDescription())
            .ticketNumber(tx.getServiceRequest() != null ? tx.getServiceRequest().getTicketNumber() : null)
            .performedBy(tx.getPerformedBy())
            .createdAt(tx.getCreatedAt())
            .build();
    }
}
