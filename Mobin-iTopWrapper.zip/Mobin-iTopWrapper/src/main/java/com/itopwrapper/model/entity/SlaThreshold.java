package com.itopwrapper.model.entity;

import jakarta.persistence.*;
import lombok.*;

/**
 * آستانه‌های هشدار SLA
 */
@Entity
@Table(name = "sla_thresholds")
@Getter @Setter
@NoArgsConstructor @AllArgsConstructor
@Builder
public class SlaThreshold {

    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "slath_seq")
    @SequenceGenerator(name = "slath_seq", sequenceName = "seq_sla_thresholds", allocationSize = 1)
    private Long id;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "sla_id", nullable = false)
    private SlaDefinition sla;

    @Column(name = "threshold_percent", nullable = false)
    private Integer thresholdPercent;

    @Enumerated(EnumType.STRING)
    @Column(name = "action_type", length = 30)
    private ActionType actionType;

    @Column(name = "notify_group", length = 200)
    private String notifyGroup;

    public enum ActionType {
        NOTIFY_AGENT,     // اطلاع‌رسانی به اپراتور
        NOTIFY_MANAGER,   // اطلاع‌رسانی به مدیر
        ESCALATE,         // ارتقاء سطح
        NOTIFY_CUSTOMER   // اطلاع‌رسانی به مشتری
    }
}
