package com.itopwrapper.model.entity;

import jakarta.persistence.*;
import lombok.*;
import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.UpdateTimestamp;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

/**
 * موجودیت تعریف SLA (توافقنامه سطح خدمت)
 * مبتنی بر مدل داده iTop
 */
@Entity
@Table(name = "sla_definitions")
@Getter @Setter
@NoArgsConstructor @AllArgsConstructor
@Builder
public class SlaDefinition {

    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "sla_seq")
    @SequenceGenerator(name = "sla_seq", sequenceName = "seq_sla_definitions", allocationSize = 1)
    private Long id;

    @Column(nullable = false, length = 200)
    private String name;

    @Column(length = 1000)
    private String description;

    @Enumerated(EnumType.STRING)
    @Column(name = "sla_type", length = 10)
    @Builder.Default
    private SlaType slaType = SlaType.SLA;

    /** زمان پاسخ‌دهی به درخواست (دقیقه) */
    @Column(name = "response_time_minutes")
    private Integer responseTimeMinutes;

    /** زمان رفع اشکال (دقیقه) */
    @Column(name = "resolution_time_minutes")
    private Integer resolutionTimeMinutes;

    /** ساعات کاری */
    @Enumerated(EnumType.STRING)
    @Column(name = "coverage_type", length = 20)
    @Builder.Default
    private CoverageType coverageType = CoverageType.BUSINESS_HOURS;

    @Column(name = "is_active")
    @Builder.Default
    private Boolean isActive = true;

    /** شناسه در موتور iTop */
    @Column(name = "itop_sla_id")
    private Long itopSlaId;

    @OneToMany(mappedBy = "sla", cascade = CascadeType.ALL, orphanRemoval = true)
    @Builder.Default
    private List<SlaThreshold> thresholds = new ArrayList<>();

    @CreationTimestamp
    @Column(name = "created_at", updatable = false)
    private LocalDateTime createdAt;

    @UpdateTimestamp
    @Column(name = "updated_at")
    private LocalDateTime updatedAt;

    public enum SlaType {
        SLA,  // توافقنامه سطح خدمت (با مشتری)
        OLA   // توافقنامه سطح عملیات (داخلی)
    }

    public enum CoverageType {
        BUSINESS_HOURS,  // ساعات اداری
        EXTENDED,        // ساعات گسترده
        H24_7,           // ۲۴ ساعت / ۷ روز
        CUSTOM           // سفارشی
    }
}
