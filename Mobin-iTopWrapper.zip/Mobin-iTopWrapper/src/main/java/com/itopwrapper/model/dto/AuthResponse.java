package com.itopwrapper.model.dto;

import lombok.*;
import java.util.List;

@Getter @Setter @Builder @NoArgsConstructor @AllArgsConstructor
public class AuthResponse {
    private String token;
    private String refreshToken;
    private String username;
    private List<String> roles;
    private Long expiresIn;
    private String message;
}
