package com.itopwrapper.model.dto;

import lombok.*;

import java.math.BigDecimal;

/** نمایه خلاصه کیف‌پول برای پاسخ‌های API (بدون افشای فیلدهای داخلی Entity) */
@Getter @Setter @Builder @NoArgsConstructor @AllArgsConstructor
public class WalletSummaryDto {
    private Long walletId;
    private Long userId;
    private String username;
    private String fullName;
    private BigDecimal balance;
    private BigDecimal heldAmount;
    private BigDecimal availableBalance;
    private BigDecimal creditLimit;
    private BigDecimal maxWithdrawable;
    private String currency;
    private Boolean isActive;
    private Boolean isLowBalance;
}
