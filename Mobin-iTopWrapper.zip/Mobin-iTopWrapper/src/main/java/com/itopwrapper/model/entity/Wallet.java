package com.itopwrapper.model.entity;

import jakarta.persistence.*;
import lombok.*;
import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.UpdateTimestamp;

import java.math.BigDecimal;
import java.time.LocalDateTime;

/**
 * کیف‌پول اعتباری مشتری — هر کاربر دقیقاً یک کیف‌پول دارد.
 * موجودی با هر خرید خدمت از کاتالوگ کاهش می‌یابد و توسط
 * سوپر‌ادمین/ادمین محلی قابل شارژ (افزایش/کاهش دستی) است.
 */
@Entity
@Table(name = "wallets")
@Getter @Setter
@NoArgsConstructor @AllArgsConstructor
@Builder
public class Wallet {

    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "wallet_seq")
    @SequenceGenerator(name = "wallet_seq", sequenceName = "seq_wallets", allocationSize = 1)
    private Long id;

    @OneToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "user_id", nullable = false, unique = true)
    private User user;

    /** موجودی فعلی قابل مصرف (می‌تواند منفی شود اگر سقف اعتباری تعریف شده باشد) */
    @Column(name = "balance", precision = 18, scale = 2, nullable = false)
    @Builder.Default
    private BigDecimal balance = BigDecimal.ZERO;

    /** مبلغ Hold شده برای خدماتی که کسر آن‌ها «پس از تأیید» تنظیم شده (هنوز نهایی نشده) */
    @Column(name = "held_amount", precision = 18, scale = 2, nullable = false)
    @Builder.Default
    private BigDecimal heldAmount = BigDecimal.ZERO;

    /**
     * سقف اعتباری مجاز (می‌تواند صفر یا مثبت باشد).
     * موجودی کیف‌پول مجاز است تا منفیِ این مقدار برسد، یعنی:
     *   balance >= -creditLimit
     * مقدار صفر یعنی اعتبار منفی مجاز نیست.
     */
    @Column(name = "credit_limit", precision = 18, scale = 2, nullable = false)
    @Builder.Default
    private BigDecimal creditLimit = BigDecimal.ZERO;

    @Column(name = "currency", length = 10, nullable = false)
    @Builder.Default
    private String currency = "IRR";

    @Column(name = "is_active", nullable = false)
    @Builder.Default
    private Boolean isActive = true;

    /** آستانه هشدار موجودی کم (برای اطلاع‌رسانی به مشتری) */
    @Column(name = "low_balance_threshold", precision = 18, scale = 2)
    private BigDecimal lowBalanceThreshold;

    @CreationTimestamp
    @Column(name = "created_at", updatable = false)
    private LocalDateTime createdAt;

    @UpdateTimestamp
    @Column(name = "updated_at")
    private LocalDateTime updatedAt;

    @Version
    @Column(name = "version")
    private Long version;

    /** موجودی واقعاً قابل برداشت (موجودی منهای مبلغ Hold شده) */
    public BigDecimal getAvailableBalance() {
        return balance.subtract(heldAmount);
    }

    /** حداکثر مبلغی که می‌توان از کیف‌پول کسر کرد بدون عبور از سقف اعتباری */
    public BigDecimal getMaxWithdrawable() {
        return getAvailableBalance().add(creditLimit);
    }

    /** آیا کیف‌پول می‌تواند مبلغ مشخصی را پوشش دهد (با احتساب سقف اعتباری)؟ */
    public boolean canAfford(BigDecimal amount) {
        return getMaxWithdrawable().compareTo(amount) >= 0;
    }

    public boolean isLowBalance() {
        return lowBalanceThreshold != null && getAvailableBalance().compareTo(lowBalanceThreshold) <= 0;
    }
}
