package com.itopwrapper.model.entity;

import jakarta.persistence.*;
import lombok.*;
import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.UpdateTimestamp;

import java.time.LocalDateTime;

/**
 * موجودیت پیکربندی سرورهای LDAP
 * قابل مدیریت از پنل ادمین
 */
@Entity
@Table(name = "ldap_providers")
@Getter @Setter
@NoArgsConstructor @AllArgsConstructor
@Builder
public class LdapProviderEntity {

    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "ldap_seq")
    @SequenceGenerator(name = "ldap_seq", sequenceName = "seq_ldap_providers", allocationSize = 1)
    private Long id;

    @Column(nullable = false, unique = true, length = 50)
    private String providerId;

    @Column(nullable = false, length = 200)
    private String name;

    @Column(nullable = false, length = 500)
    private String url;

    @Column(nullable = false, length = 300)
    private String baseDn;

    @Column(name = "bind_dn", length = 500)
    private String bindDn;

    @Column(name = "bind_password", length = 255)
    private String bindPassword;

    @Column(name = "user_search_filter", length = 200)
    @Builder.Default
    private String userSearchFilter = "(uid={0})";

    @Column(name = "user_search_base", length = 300)
    private String userSearchBase;

    @Column(name = "group_search_base", length = 300)
    private String groupSearchBase;

    @Column(name = "group_search_filter", length = 200)
    @Builder.Default
    private String groupSearchFilter = "(member={0})";

    @Column(name = "email_attribute", length = 100)
    @Builder.Default
    private String emailAttribute = "mail";

    @Column(name = "first_name_attribute", length = 100)
    @Builder.Default
    private String firstNameAttribute = "givenName";

    @Column(name = "last_name_attribute", length = 100)
    @Builder.Default
    private String lastNameAttribute = "sn";

    @Column(name = "display_name_attribute", length = 100)
    @Builder.Default
    private String displayNameAttribute = "cn";

    @Column(name = "use_ssl")
    @Builder.Default
    private Boolean useSsl = false;

    @Column(name = "use_tls")
    @Builder.Default
    private Boolean useTls = false;

    @Column(name = "connect_timeout_ms")
    @Builder.Default
    private Integer connectTimeoutMs = 5000;

    @Column(name = "is_enabled")
    @Builder.Default
    private Boolean isEnabled = true;

    /** نقش پیش‌فرض اختصاص به کاربران LDAP */
    @Column(name = "default_role", length = 100)
    @Builder.Default
    private String defaultRole = "ROLE_CUSTOMER";

    @Column(name = "display_order")
    @Builder.Default
    private Integer displayOrder = 0;

    @CreationTimestamp
    @Column(name = "created_at", updatable = false)
    private LocalDateTime createdAt;

    @UpdateTimestamp
    @Column(name = "updated_at")
    private LocalDateTime updatedAt;
}
