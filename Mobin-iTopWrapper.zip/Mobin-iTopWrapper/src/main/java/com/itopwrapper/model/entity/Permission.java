package com.itopwrapper.model.entity;

import jakarta.persistence.*;
import lombok.*;

/**
 * موجودیت مجوز دسترسی
 */
@Entity
@Table(name = "permissions")
@Getter @Setter
@NoArgsConstructor @AllArgsConstructor
@Builder
public class Permission {

    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "perm_seq")
    @SequenceGenerator(name = "perm_seq", sequenceName = "seq_permissions", allocationSize = 1)
    private Long id;

    @Column(nullable = false, unique = true, length = 100)
    private String name;

    @Column(length = 200)
    private String description;

    @Column(length = 50)
    private String module;

    @Column(length = 50)
    private String action;

    // مجوزهای ماژول کاتالوگ خدمات
    public static final String SERVICE_READ    = "SERVICE_READ";
    public static final String SERVICE_WRITE   = "SERVICE_WRITE";
    public static final String SERVICE_DELETE  = "SERVICE_DELETE";
    public static final String SERVICE_PRICE   = "SERVICE_PRICE";

    // مجوزهای مدیریت کاربران
    public static final String USER_READ       = "USER_READ";
    public static final String USER_WRITE      = "USER_WRITE";
    public static final String USER_DELETE     = "USER_DELETE";

    // مجوزهای SLA/OLA
    public static final String SLA_READ        = "SLA_READ";
    public static final String SLA_WRITE       = "SLA_WRITE";

    // مجوزهای مدیریت پروژه
    public static final String PROJECT_READ    = "PROJECT_READ";
    public static final String PROJECT_WRITE   = "PROJECT_WRITE";

    // مجوزهای مرکز هزینه
    public static final String COST_READ       = "COST_READ";
    public static final String COST_WRITE      = "COST_WRITE";

    // مجوزهای ماژول
    public static final String MODULE_UPLOAD   = "MODULE_UPLOAD";
    public static final String MODULE_MANAGE   = "MODULE_MANAGE";

    // مجوزهای لاگ
    public static final String LOG_READ        = "LOG_READ";
}
