package com.itopwrapper.security.ldap;

import lombok.*;

import java.util.Map;

/**
 * پیکربندی ارائه‌دهنده LDAP
 */
@Getter @Setter
@NoArgsConstructor @AllArgsConstructor
@Builder
public class LdapProviderConfig {
    private String id;
    private String name;
    private String url;
    private String base;
    private String userDn;
    private String password;
    @Builder.Default
    private String userSearchAttribute = "uid";
    @Builder.Default
    private boolean enabled = true;
}
