package com.itopwrapper.security.ldap;

import lombok.extern.slf4j.Slf4j;
import org.springframework.ldap.core.LdapTemplate;
import org.springframework.ldap.core.support.LdapContextSource;
import org.springframework.ldap.filter.AndFilter;
import org.springframework.ldap.filter.EqualsFilter;
import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

/**
 * سرویس احراز هویت چند-LDAP
 * قابلیت اتصال به چندین سرور LDAP همزمان
 */
@Service
@Slf4j
public class MultiLdapAuthService {

    private final Map<String, LdapTemplate> ldapTemplates = new ConcurrentHashMap<>();
    private final Map<String, LdapProviderConfig> providers = new ConcurrentHashMap<>();

    /**
     * ثبت یک ارائه‌دهنده LDAP جدید
     */
    public void registerProvider(LdapProviderConfig config) {
        try {
            LdapContextSource contextSource = new LdapContextSource();
            contextSource.setUrl(config.getUrl());
            contextSource.setBase(config.getBase());
            if (config.getUserDn() != null && !config.getUserDn().isBlank()) {
                contextSource.setUserDn(config.getUserDn());
                contextSource.setPassword(config.getPassword());
            } else {
                contextSource.setAnonymousReadOnly(true);
            }
            contextSource.afterPropertiesSet();

            LdapTemplate template = new LdapTemplate(contextSource);
            ldapTemplates.put(config.getId(), template);
            providers.put(config.getId(), config);

            log.info("ارائه‌دهنده LDAP ثبت شد: {} - {}", config.getId(), config.getName());
        } catch (Exception e) {
            log.error("خطا در ثبت ارائه‌دهنده LDAP: {}", config.getId(), e);
        }
    }

    /**
     * احراز هویت کاربر در تمام ارائه‌دهندگان LDAP فعال
     */
    public LdapAuthResult authenticate(String username, String password) {
        for (Map.Entry<String, LdapTemplate> entry : ldapTemplates.entrySet()) {
            String providerId = entry.getKey();
            LdapProviderConfig config = providers.get(providerId);

            if (!config.isEnabled()) continue;

            try {
                LdapTemplate template = entry.getValue();
                AndFilter filter = new AndFilter();
                filter.and(new EqualsFilter("objectClass", "person"));
                filter.and(new EqualsFilter(config.getUserSearchAttribute(), username));

                boolean authenticated = template.authenticate("", filter.encode(), password);
                if (authenticated) {
                    log.info("کاربر {} از طریق LDAP {} احراز هویت شد", username, providerId);
                    // دریافت اطلاعات کاربر از LDAP
                    var ldapUser = fetchUserDetails(template, filter.encode(), config);
                    return LdapAuthResult.success(username, providerId, ldapUser);
                }
            } catch (Exception e) {
                log.warn("خطا در احراز هویت LDAP [{}]: {}", providerId, e.getMessage());
            }
        }
        return LdapAuthResult.failure("نام کاربری یا رمز عبور اشتباه است");
    }

    private Map<String, String> fetchUserDetails(LdapTemplate template, String filter, LdapProviderConfig config) {
        try {
            return template.search("", filter,
                (attributes, name) -> {
                    Map<String, String> attrs = new java.util.HashMap<>();
                    safeGet(attributes, "cn").ifPresent(v -> attrs.put("displayName", v));
                    safeGet(attributes, "mail").ifPresent(v -> attrs.put("email", v));
                    safeGet(attributes, "givenName").ifPresent(v -> attrs.put("firstName", v));
                    safeGet(attributes, "sn").ifPresent(v -> attrs.put("lastName", v));
                    safeGet(attributes, "telephoneNumber").ifPresent(v -> attrs.put("phone", v));
                    attrs.put("dn", name.toString());
                    return attrs;
                }).stream().findFirst().orElse(Map.of());
        } catch (Exception e) {
            log.warn("خطا در دریافت اطلاعات کاربر LDAP: {}", e.getMessage());
            return Map.of();
        }
    }

    private java.util.Optional<String> safeGet(javax.naming.directory.Attributes attrs, String key) {
        try {
            var attr = attrs.get(key);
            return attr != null ? java.util.Optional.of(attr.get().toString()) : java.util.Optional.empty();
        } catch (Exception e) {
            return java.util.Optional.empty();
        }
    }

    public List<LdapProviderConfig> getProviders() {
        return List.copyOf(providers.values());
    }

    public void updateProvider(LdapProviderConfig config) {
        ldapTemplates.remove(config.getId());
        providers.remove(config.getId());
        if (config.isEnabled()) {
            registerProvider(config);
        }
    }
}
