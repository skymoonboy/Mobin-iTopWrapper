package com.itopwrapper.security.ldap;

import lombok.Getter;
import java.util.Map;

@Getter
public class LdapAuthResult {
    private final boolean success;
    private final String username;
    private final String providerId;
    private final Map<String, String> userAttributes;
    private final String errorMessage;

    private LdapAuthResult(boolean success, String username, String providerId,
                           Map<String, String> userAttributes, String errorMessage) {
        this.success = success;
        this.username = username;
        this.providerId = providerId;
        this.userAttributes = userAttributes;
        this.errorMessage = errorMessage;
    }

    public static LdapAuthResult success(String username, String providerId, Map<String, String> attrs) {
        return new LdapAuthResult(true, username, providerId, attrs, null);
    }

    public static LdapAuthResult failure(String errorMessage) {
        return new LdapAuthResult(false, null, null, Map.of(), errorMessage);
    }
}
