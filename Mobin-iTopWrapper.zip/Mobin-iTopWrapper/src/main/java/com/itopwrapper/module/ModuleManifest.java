package com.itopwrapper.module;

import lombok.*;

@Getter @Setter @Builder @NoArgsConstructor @AllArgsConstructor
public class ModuleManifest {
    private String moduleId;
    private String name;
    private String version;
    private String description;
    private String author;
    private String entryPointClass;
    private boolean requiresRestart;
}
