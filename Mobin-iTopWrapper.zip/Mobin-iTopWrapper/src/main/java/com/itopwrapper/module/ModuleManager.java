package com.itopwrapper.module;

import com.itopwrapper.model.entity.ModuleInfo;
import com.itopwrapper.repository.ModuleRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.net.URL;
import java.net.URLClassLoader;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import java.util.List;
import java.util.ServiceLoader;
import java.util.jar.JarFile;
import java.util.jar.Manifest;

/**
 * مدیریت ماژول‌های قابل نصب
 * امکان آپلود و فعال‌سازی ماژول‌های توسعه‌یافته توسط توسعه‌دهندگان
 */
@Service
@Slf4j
@RequiredArgsConstructor
public class ModuleManager {

    @Value("${itop.module.upload-dir:/app/modules}")
    private String uploadDir;

    private final ModuleRepository moduleRepository;

    /**
     * آپلود و نصب ماژول جدید
     */
    public ModuleInfo installModule(MultipartFile file, String installedBy) throws ModuleException {
        // اعتبارسنجی فایل
        if (file.isEmpty()) throw new ModuleException("فایل ماژول خالی است");
        String filename = file.getOriginalFilename();
        if (filename == null || !filename.endsWith(".jar"))
            throw new ModuleException("فایل باید با پسوند .jar باشد");

        try {
            // ایجاد دایرکتوری آپلود
            Path uploadPath = Paths.get(uploadDir);
            Files.createDirectories(uploadPath);

            // ذخیره فایل
            Path jarPath = uploadPath.resolve(filename);
            Files.copy(file.getInputStream(), jarPath, StandardCopyOption.REPLACE_EXISTING);

            // خواندن مانیفست ماژول
            ModuleManifest manifest = readModuleManifest(jarPath);

            // بررسی تکراری نبودن ماژول
            if (moduleRepository.existsByModuleId(manifest.getModuleId())) {
                return updateExistingModule(manifest, jarPath.toString(), installedBy);
            }

            // ذخیره اطلاعات ماژول در پایگاه داده
            ModuleInfo moduleInfo = ModuleInfo.builder()
                .moduleId(manifest.getModuleId())
                .name(manifest.getName())
                .description(manifest.getDescription())
                .version(manifest.getVersion())
                .author(manifest.getAuthor())
                .jarPath(jarPath.toString())
                .entryPointClass(manifest.getEntryPointClass())
                .status(ModuleInfo.ModuleStatus.INSTALLED)
                .requiresRestart(manifest.isRequiresRestart())
                .installedBy(installedBy)
                .build();

            moduleInfo = moduleRepository.save(moduleInfo);
            log.info("ماژول نصب شد: {} v{} توسط {}", manifest.getName(), manifest.getVersion(), installedBy);

            // تلاش برای بارگذاری خودکار (اگر نیاز به ریستارت ندارد)
            if (!manifest.isRequiresRestart()) {
                loadModuleClass(moduleInfo);
            }

            return moduleInfo;

        } catch (IOException e) {
            throw new ModuleException("خطا در نصب ماژول: " + e.getMessage(), e);
        }
    }

    /**
     * فعال‌سازی ماژول
     */
    public void activateModule(String moduleId) throws ModuleException {
        ModuleInfo module = moduleRepository.findByModuleId(moduleId)
            .orElseThrow(() -> new ModuleException("ماژول یافت نشد: " + moduleId));

        try {
            loadModuleClass(module);
            module.setStatus(ModuleInfo.ModuleStatus.ACTIVE);
            moduleRepository.save(module);
            log.info("ماژول فعال شد: {}", moduleId);
        } catch (Exception e) {
            module.setStatus(ModuleInfo.ModuleStatus.ERROR);
            moduleRepository.save(module);
            throw new ModuleException("خطا در فعال‌سازی ماژول: " + e.getMessage(), e);
        }
    }

    /**
     * غیرفعال‌سازی ماژول
     */
    public void deactivateModule(String moduleId) throws ModuleException {
        ModuleInfo module = moduleRepository.findByModuleId(moduleId)
            .orElseThrow(() -> new ModuleException("ماژول یافت نشد: " + moduleId));
        module.setStatus(ModuleInfo.ModuleStatus.INACTIVE);
        moduleRepository.save(module);
        log.info("ماژول غیرفعال شد: {}", moduleId);
    }

    /**
     * حذف ماژول
     */
    public void removeModule(String moduleId) throws ModuleException {
        ModuleInfo module = moduleRepository.findByModuleId(moduleId)
            .orElseThrow(() -> new ModuleException("ماژول یافت نشد: " + moduleId));

        try {
            // حذف فایل JAR
            Path jarPath = Paths.get(module.getJarPath());
            Files.deleteIfExists(jarPath);

            moduleRepository.delete(module);
            log.info("ماژول حذف شد: {}", moduleId);
        } catch (IOException e) {
            throw new ModuleException("خطا در حذف ماژول: " + e.getMessage(), e);
        }
    }

    /**
     * دریافت لیست ماژول‌های نصب‌شده
     */
    public List<ModuleInfo> getInstalledModules() {
        return moduleRepository.findAll();
    }

    private ModuleManifest readModuleManifest(Path jarPath) throws ModuleException {
        try (JarFile jar = new JarFile(jarPath.toFile())) {
            Manifest manifest = jar.getManifest();
            if (manifest == null) throw new ModuleException("فایل JAR فاقد مانیفست است");

            var attrs = manifest.getMainAttributes();
            return ModuleManifest.builder()
                .moduleId(getRequiredAttr(attrs, "iTop-Module-Id"))
                .name(getRequiredAttr(attrs, "iTop-Module-Name"))
                .version(attrs.getValue("Implementation-Version") != null
                    ? attrs.getValue("Implementation-Version") : "1.0.0")
                .description(attrs.getValue("iTop-Module-Description") != null
                    ? attrs.getValue("iTop-Module-Description") : "")
                .author(attrs.getValue("iTop-Module-Author") != null
                    ? attrs.getValue("iTop-Module-Author") : "ناشناخته")
                .entryPointClass(attrs.getValue("iTop-Entry-Point"))
                .requiresRestart("true".equalsIgnoreCase(attrs.getValue("iTop-Requires-Restart")))
                .build();
        } catch (IOException e) {
            throw new ModuleException("خطا در خواندن مانیفست ماژول: " + e.getMessage(), e);
        }
    }

    private String getRequiredAttr(java.util.jar.Attributes attrs, String key) throws ModuleException {
        String value = attrs.getValue(key);
        if (value == null || value.isBlank())
            throw new ModuleException("مانیفست ماژول فاقد فیلد اجباری است: " + key);
        return value;
    }

    private void loadModuleClass(ModuleInfo module) throws ModuleException {
        if (module.getEntryPointClass() == null) return;
        try {
            URLClassLoader classLoader = new URLClassLoader(
                new URL[]{Paths.get(module.getJarPath()).toUri().toURL()},
                getClass().getClassLoader()
            );
            Class<?> entryClass = classLoader.loadClass(module.getEntryPointClass());
            if (ITopModule.class.isAssignableFrom(entryClass)) {
                ITopModule moduleInstance = (ITopModule) entryClass.getDeclaredConstructor().newInstance();
                moduleInstance.onActivate();
                log.info("کلاس ماژول بارگذاری شد: {}", module.getEntryPointClass());
            }
        } catch (Exception e) {
            throw new ModuleException("خطا در بارگذاری کلاس ماژول: " + e.getMessage(), e);
        }
    }

    private ModuleInfo updateExistingModule(ModuleManifest manifest, String jarPath, String installedBy) {
        ModuleInfo existing = moduleRepository.findByModuleId(manifest.getModuleId()).get();
        existing.setName(manifest.getName());
        existing.setVersion(manifest.getVersion());
        existing.setDescription(manifest.getDescription());
        existing.setJarPath(jarPath);
        existing.setStatus(ModuleInfo.ModuleStatus.INSTALLED);
        existing.setInstalledBy(installedBy);
        return moduleRepository.save(existing);
    }
}
