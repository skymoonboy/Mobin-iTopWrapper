package com.itopwrapper.module;

/**
 * رابط اصلی برای ماژول‌های قابل نصب
 * توسعه‌دهندگان باید این رابط را پیاده‌سازی کنند
 */
public interface ITopModule {
    String getModuleId();
    String getModuleName();
    String getVersion();
    void onActivate();
    void onDeactivate();
}
