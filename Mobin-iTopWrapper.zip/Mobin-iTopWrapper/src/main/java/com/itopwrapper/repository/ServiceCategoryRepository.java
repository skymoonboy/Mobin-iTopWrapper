package com.itopwrapper.repository;

import com.itopwrapper.model.entity.ServiceCategory;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import java.util.List;

@Repository
public interface ServiceCategoryRepository extends JpaRepository<ServiceCategory, Long> {
    List<ServiceCategory> findByParentIsNull();
    List<ServiceCategory> findByParentIsNullAndIsActiveTrue();
    List<ServiceCategory> findByParentAndIsActiveTrue(ServiceCategory parent);
}
