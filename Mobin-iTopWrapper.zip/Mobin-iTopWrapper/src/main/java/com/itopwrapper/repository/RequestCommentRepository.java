package com.itopwrapper.repository;

import com.itopwrapper.model.entity.RequestComment;
import com.itopwrapper.model.entity.ServiceRequest;
import com.itopwrapper.model.entity.User;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface RequestCommentRepository extends JpaRepository<RequestComment, Long> {

    List<RequestComment> findByRequestOrderByCreatedAtAsc(ServiceRequest request);

    List<RequestComment> findByRequestAndCommentTypeOrderByCreatedAtAsc(
        ServiceRequest request, RequestComment.CommentType commentType);

    List<RequestComment> findByAuthor(User author);

    long countByRequest(ServiceRequest request);
}
