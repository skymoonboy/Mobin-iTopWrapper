package com.itopwrapper.repository;

import com.itopwrapper.model.entity.ServiceRequest;
import com.itopwrapper.model.entity.User;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

@Repository
public interface ServiceRequestRepository extends JpaRepository<ServiceRequest, Long> {
    Optional<ServiceRequest> findByTicketNumber(String ticketNumber);
    Page<ServiceRequest> findByRequester(User requester, Pageable pageable);
    Page<ServiceRequest> findByAssignee(User assignee, Pageable pageable);
    List<ServiceRequest> findByStatus(ServiceRequest.RequestStatus status);
    long countByStatus(ServiceRequest.RequestStatus status);
    long countByRequester(User requester);

    org.springframework.data.domain.Page<ServiceRequest> findByStatus(
        ServiceRequest.RequestStatus status,
        org.springframework.data.domain.Pageable pageable);

    @Query("SELECT r FROM ServiceRequest r WHERE r.resolutionDeadline < :now AND r.status NOT IN ('RESOLVED','CLOSED','CANCELLED')")
    List<ServiceRequest> findBreachedSla(LocalDateTime now);

    @Query("SELECT r FROM ServiceRequest r WHERE r.requester = :user ORDER BY r.createdAt DESC")
    Page<ServiceRequest> findByRequesterOrderByCreatedAtDesc(User user, Pageable pageable);
}
