package com.itopwrapper.repository;

import com.itopwrapper.model.entity.SlaDefinition;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import java.util.List;

@Repository
public interface SlaRepository extends JpaRepository<SlaDefinition, Long> {
    List<SlaDefinition> findByIsActiveTrue();
    List<SlaDefinition> findBySlaType(SlaDefinition.SlaType type);
    List<SlaDefinition> findBySlaTypeAndIsActiveTrue(SlaDefinition.SlaType type);
}
