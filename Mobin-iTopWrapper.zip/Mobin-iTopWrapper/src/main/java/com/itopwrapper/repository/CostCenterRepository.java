package com.itopwrapper.repository;

import com.itopwrapper.model.entity.CostCenter;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import java.util.List;
import java.util.Optional;

@Repository
public interface CostCenterRepository extends JpaRepository<CostCenter, Long> {
    Optional<CostCenter> findByCode(String code);
    List<CostCenter> findByParentIsNull();
    List<CostCenter> findByParentIsNullAndIsActiveTrue();
    List<CostCenter> findByIsActiveTrue();
}
