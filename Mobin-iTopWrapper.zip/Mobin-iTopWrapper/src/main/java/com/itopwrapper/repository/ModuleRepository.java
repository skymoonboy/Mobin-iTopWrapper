package com.itopwrapper.repository;

import com.itopwrapper.model.entity.ModuleInfo;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import java.util.Optional;

@Repository
public interface ModuleRepository extends JpaRepository<ModuleInfo, Long> {
    Optional<ModuleInfo> findByModuleId(String moduleId);
    boolean existsByModuleId(String moduleId);
}
