package com.itopwrapper.repository;

import com.itopwrapper.model.entity.User;
import com.itopwrapper.model.entity.Wallet;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Lock;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import jakarta.persistence.LockModeType;
import java.util.List;
import java.util.Optional;

@Repository
public interface WalletRepository extends JpaRepository<Wallet, Long> {

    Optional<Wallet> findByUser(User user);

    @Query("SELECT w FROM Wallet w JOIN FETCH w.user WHERE w.user.id = :userId")
    Optional<Wallet> findByUserId(Long userId);

    /** قفل بدبینانه (Pessimistic Lock) برای جلوگیری از Race Condition هنگام کسر همزمان موجودی */
    @Lock(LockModeType.PESSIMISTIC_WRITE)
    @Query("SELECT w FROM Wallet w WHERE w.user.id = :userId")
    Optional<Wallet> findByUserIdForUpdate(Long userId);

    List<Wallet> findByIsActiveTrue();

    @Query("SELECT w FROM Wallet w JOIN FETCH w.user")
    List<Wallet> findAllWithUser();

    @Query("SELECT w FROM Wallet w JOIN FETCH w.user WHERE (w.balance - w.heldAmount) <= w.lowBalanceThreshold AND w.lowBalanceThreshold IS NOT NULL")
    List<Wallet> findLowBalanceWallets();

    boolean existsByUser(User user);
}
