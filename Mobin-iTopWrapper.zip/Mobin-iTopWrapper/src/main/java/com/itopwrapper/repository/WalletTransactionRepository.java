package com.itopwrapper.repository;

import com.itopwrapper.model.entity.Wallet;
import com.itopwrapper.model.entity.WalletTransaction;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.List;

@Repository
public interface WalletTransactionRepository extends JpaRepository<WalletTransaction, Long> {

    Page<WalletTransaction> findByWalletOrderByCreatedAtDesc(Wallet wallet, Pageable pageable);

    List<WalletTransaction> findByWalletAndTypeOrderByCreatedAtDesc(Wallet wallet, WalletTransaction.TransactionType type);

    Page<WalletTransaction> findAllByOrderByCreatedAtDesc(Pageable pageable);

    @Query("SELECT COALESCE(SUM(t.amount),0) FROM WalletTransaction t WHERE t.type = :type AND t.createdAt >= :since")
    BigDecimal sumAmountByTypeSince(WalletTransaction.TransactionType type, LocalDateTime since);

    @Query("SELECT t FROM WalletTransaction t WHERE t.wallet = :wallet AND t.type = 'HOLD' " +
           "AND NOT EXISTS (SELECT 1 FROM WalletTransaction r WHERE r.relatedTransaction = t)")
    List<WalletTransaction> findOpenHolds(Wallet wallet);

    long countByType(WalletTransaction.TransactionType type);
}
