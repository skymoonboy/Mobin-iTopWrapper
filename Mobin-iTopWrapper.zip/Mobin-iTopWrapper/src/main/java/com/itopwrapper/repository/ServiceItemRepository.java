package com.itopwrapper.repository;

import com.itopwrapper.model.entity.ServiceCategory;
import com.itopwrapper.model.entity.ServiceItem;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import java.util.List;

@Repository
public interface ServiceItemRepository extends JpaRepository<ServiceItem, Long> {
    List<ServiceItem> findByCategoryAndIsActiveTrue(ServiceCategory category);
    List<ServiceItem> findByIsFeaturedTrueAndIsActiveTrue();
    List<ServiceItem> findByIsActiveTrue();
}
