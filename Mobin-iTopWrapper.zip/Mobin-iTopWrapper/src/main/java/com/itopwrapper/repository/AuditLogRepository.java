package com.itopwrapper.repository;

import com.itopwrapper.model.entity.AuditLog;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import java.time.LocalDateTime;
import java.util.List;

@Repository
public interface AuditLogRepository extends JpaRepository<AuditLog, Long> {
    List<AuditLog> findTop10ByOrderByCreatedAtDesc();
    long countByLevelAndCreatedAtAfter(AuditLog.LogLevel level, LocalDateTime after);
    long countByActionAndCreatedAtAfter(String action, LocalDateTime after);
}
