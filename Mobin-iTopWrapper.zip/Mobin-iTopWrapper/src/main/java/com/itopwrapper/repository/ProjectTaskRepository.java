package com.itopwrapper.repository;

import com.itopwrapper.model.entity.Project;
import com.itopwrapper.model.entity.ProjectTask;
import com.itopwrapper.model.entity.User;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.time.LocalDate;
import java.util.List;

@Repository
public interface ProjectTaskRepository extends JpaRepository<ProjectTask, Long> {

    List<ProjectTask> findByProjectOrderByDisplayOrderAsc(Project project);

    List<ProjectTask> findByAssignee(User assignee);

    List<ProjectTask> findByStatus(ProjectTask.TaskStatus status);

    List<ProjectTask> findByProjectAndStatus(Project project, ProjectTask.TaskStatus status);

    List<ProjectTask> findByParentTaskIsNullAndProject(Project project);

    @Query("SELECT t FROM ProjectTask t WHERE t.endDate < :today AND t.status != 'COMPLETED' AND t.status != 'BLOCKED'")
    List<ProjectTask> findOverdueTasks(LocalDate today);

    @Query("SELECT t FROM ProjectTask t WHERE t.project = :project ORDER BY t.startDate ASC")
    List<ProjectTask> findByProjectOrderByStartDate(Project project);

    long countByProject(Project project);

    long countByProjectAndStatus(Project project, ProjectTask.TaskStatus status);
}
