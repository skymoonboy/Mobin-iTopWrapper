package com.itopwrapper.repository;

import com.itopwrapper.model.entity.Project;
import com.itopwrapper.model.entity.User;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;
import java.util.List;

@Repository
public interface ProjectRepository extends JpaRepository<Project, Long> {
    List<Project> findByManager(User manager);
    List<Project> findByStatus(Project.ProjectStatus status);

    @Query("SELECT p FROM Project p LEFT JOIN FETCH p.tasks WHERE p.id = :id")
    java.util.Optional<Project> findByIdWithTasks(Long id);
}
