package com.itopwrapper.repository;

import com.itopwrapper.model.entity.LdapProviderEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import java.util.List;
import java.util.Optional;

@Repository
public interface LdapProviderRepository extends JpaRepository<LdapProviderEntity, Long> {
    Optional<LdapProviderEntity> findByProviderId(String providerId);
    List<LdapProviderEntity> findByIsEnabledTrue();
    List<LdapProviderEntity> findAllByOrderByDisplayOrderAsc();
    boolean existsByProviderId(String providerId);
}
