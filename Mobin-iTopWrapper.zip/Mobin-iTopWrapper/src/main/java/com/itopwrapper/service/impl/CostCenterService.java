package com.itopwrapper.service.impl;

import com.itopwrapper.audit.AuditService;
import com.itopwrapper.model.entity.CostCenter;
import com.itopwrapper.repository.CostCenterRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.util.*;

/**
 * سرویس مدیریت مراکز هزینه
 */
@Service
@Slf4j
@RequiredArgsConstructor
public class CostCenterService {

    private final CostCenterRepository costCenterRepository;
    private final AuditService auditService;

    public List<CostCenter> getRootCostCenters() {
        return costCenterRepository.findByParentIsNullAndIsActiveTrue();
    }

    public List<CostCenter> getAllActive() {
        return costCenterRepository.findByIsActiveTrue();
    }

    public Optional<CostCenter> getById(Long id) {
        return costCenterRepository.findById(id);
    }

    @Transactional
    public CostCenter save(CostCenter costCenter, String savedBy) {
        boolean isNew = costCenter.getId() == null;
        CostCenter saved = costCenterRepository.save(costCenter);
        auditService.log(
            isNew ? "COST_CENTER_CREATE" : "COST_CENTER_UPDATE",
            "COST_CENTER", saved.getId(), savedBy,
            (isNew ? "ایجاد" : "بروزرسانی") + " مرکز هزینه: " + costCenter.getName(),
            "system", true
        );
        return saved;
    }

    /**
     * ثبت هزینه برای مرکز هزینه
     */
    @Transactional
    public CostCenter recordExpense(Long costCenterId, BigDecimal amount, String description, String recordedBy) {
        CostCenter cc = costCenterRepository.findById(costCenterId)
            .orElseThrow(() -> new RuntimeException("مرکز هزینه یافت نشد"));

        cc.setSpentAmount(cc.getSpentAmount().add(amount));
        CostCenter saved = costCenterRepository.save(cc);

        auditService.log("COST_EXPENSE", "COST_CENTER", costCenterId, recordedBy,
            "ثبت هزینه " + amount + " برای " + cc.getName() + ": " + description,
            "system", true);

        return saved;
    }

    /**
     * گزارش خلاصه بودجه
     */
    public Map<String, Object> getBudgetSummary() {
        List<CostCenter> all = costCenterRepository.findByIsActiveTrue();
        BigDecimal totalBudget  = all.stream().map(CostCenter::getAnnualBudget).reduce(BigDecimal.ZERO, BigDecimal::add);
        BigDecimal totalSpent   = all.stream().map(CostCenter::getSpentAmount).reduce(BigDecimal.ZERO, BigDecimal::add);
        BigDecimal totalRemain  = totalBudget.subtract(totalSpent);

        Map<String, Object> summary = new LinkedHashMap<>();
        summary.put("totalBudget",    totalBudget);
        summary.put("totalSpent",     totalSpent);
        summary.put("totalRemaining", totalRemain);
        summary.put("usagePercent",   totalBudget.compareTo(BigDecimal.ZERO) == 0 ? 0
            : totalSpent.divide(totalBudget, 4, java.math.RoundingMode.HALF_UP)
                .multiply(BigDecimal.valueOf(100)).doubleValue());
        summary.put("overBudgetCount", all.stream()
            .filter(cc -> cc.getSpentAmount().compareTo(cc.getAnnualBudget()) > 0).count());
        summary.put("centers", all);
        return summary;
    }

    @Transactional
    public void delete(Long id, String deletedBy) {
        costCenterRepository.findById(id).ifPresent(cc -> {
            cc.setIsActive(false);
            costCenterRepository.save(cc);
            auditService.log("COST_CENTER_DELETE", "COST_CENTER", id,
                deletedBy, "غیرفعال‌سازی مرکز هزینه: " + cc.getName(), "system", true);
        });
    }
}
