package com.itopwrapper.service;

import com.itopwrapper.model.entity.Role;
import com.itopwrapper.model.entity.User;
import com.itopwrapper.repository.UserRepository;
import com.itopwrapper.security.ldap.LdapAuthResult;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
@Slf4j
public class UserService implements UserDetailsService {

    private final UserRepository userRepository;
    private final PasswordEncoder passwordEncoder;

    @Override
    public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
        User user = userRepository.findByUsername(username)
            .orElseThrow(() -> new UsernameNotFoundException("کاربر یافت نشد: " + username));

        if (!user.getIsActive()) throw new UsernameNotFoundException("کاربر غیرفعال است");

        return org.springframework.security.core.userdetails.User.builder()
            .username(user.getUsername())
            .password(user.getPasswordHash() != null ? user.getPasswordHash() : "{noop}")
            .authorities(user.getRoles().stream()
                .map(r -> new SimpleGrantedAuthority(r.getName()))
                .collect(Collectors.toSet()))
            .accountLocked(user.getIsLocked())
            .build();
    }

    @Transactional
    public User findOrCreateLdapUser(String username, LdapAuthResult ldapResult) {
        return userRepository.findByUsername(username).orElseGet(() -> {
            var attrs = ldapResult.getUserAttributes();
            User newUser = User.builder()
                .username(username)
                .email(attrs.getOrDefault("email", username + "@ldap.local"))
                .firstName(attrs.get("firstName"))
                .lastName(attrs.get("lastName"))
                .displayName(attrs.get("displayName"))
                .authType(User.AuthType.LDAP)
                .ldapDn(attrs.get("dn"))
                .ldapProviderId(ldapResult.getProviderId())
                .isActive(true)
                .build();
            return userRepository.save(newUser);
        });
    }

    @Transactional
    public void updateLastLogin(String username) {
        userRepository.findByUsername(username).ifPresent(user -> {
            user.setLastLogin(LocalDateTime.now());
            user.setFailedLoginAttempts(0);
            userRepository.save(user);
        });
    }
}
