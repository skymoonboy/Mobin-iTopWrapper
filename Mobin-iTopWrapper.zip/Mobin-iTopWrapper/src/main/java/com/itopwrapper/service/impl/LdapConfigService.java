package com.itopwrapper.service.impl;

import com.itopwrapper.audit.AuditService;
import com.itopwrapper.model.entity.LdapProviderEntity;
import com.itopwrapper.repository.LdapProviderRepository;
import com.itopwrapper.security.ldap.LdapProviderConfig;
import com.itopwrapper.security.ldap.MultiLdapAuthService;
import jakarta.annotation.PostConstruct;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.Optional;

/**
 * سرویس مدیریت تنظیمات LDAP
 * پیکربندی‌ها از پایگاه داده بارگذاری و پویا مدیریت می‌شوند
 */
@Service
@Slf4j
@RequiredArgsConstructor
public class LdapConfigService {

    private final LdapProviderRepository ldapProviderRepository;
    private final MultiLdapAuthService multiLdapAuthService;
    private final AuditService auditService;

    @Value("${ldap.providers[0].url:ldap://localhost:389}")
    private String primaryUrl;
    @Value("${ldap.providers[0].base:dc=example,dc=com}")
    private String primaryBase;
    @Value("${ldap.providers[0].enabled:false}")
    private boolean primaryEnabled;

    /**
     * بارگذاری تنظیمات LDAP از پایگاه داده هنگام راه‌اندازی
     */
    @PostConstruct
    public void loadProvidersFromDatabase() {
        List<LdapProviderEntity> providers = ldapProviderRepository.findAllByOrderByDisplayOrderAsc();
        if (providers.isEmpty()) {
            log.info("پیکربندی LDAP در پایگاه داده یافت نشد — از فایل application.yml استفاده می‌شود");
            return;
        }
        providers.stream().filter(LdapProviderEntity::getIsEnabled).forEach(this::registerProvider);
        log.info("{} ارائه‌دهنده LDAP از پایگاه داده بارگذاری شد", providers.size());
    }

    /**
     * افزودن یا بروزرسانی ارائه‌دهنده LDAP
     */
    @Transactional
    public LdapProviderEntity saveProvider(LdapProviderEntity entity, String savedBy) {
        boolean isNew = entity.getId() == null;
        LdapProviderEntity saved = ldapProviderRepository.save(entity);

        // ثبت در سرویس احراز هویت
        registerProvider(saved);

        auditService.log(
            isNew ? "LDAP_PROVIDER_CREATE" : "LDAP_PROVIDER_UPDATE",
            "LDAP_CONFIG", saved.getId(), savedBy,
            (isNew ? "افزودن" : "بروزرسانی") + " ارائه‌دهنده LDAP: " + entity.getName(),
            "system", true
        );
        return saved;
    }

    /**
     * آزمایش اتصال به سرور LDAP
     */
    public boolean testConnection(LdapProviderEntity entity) {
        try {
            LdapProviderConfig config = toConfig(entity);
            LdapProviderConfig testConfig = LdapProviderConfig.builder()
                .id("test-" + entity.getProviderId())
                .name(entity.getName())
                .url(entity.getUrl())
                .base(entity.getBaseDn())
                .userDn(entity.getBindDn())
                .password(entity.getBindPassword())
                .enabled(true)
                .build();
            multiLdapAuthService.registerProvider(testConfig);
            log.info("اتصال به سرور LDAP {} موفق بود", entity.getName());
            return true;
        } catch (Exception e) {
            log.warn("اتصال به سرور LDAP {} ناموفق بود: {}", entity.getName(), e.getMessage());
            return false;
        }
    }

    /**
     * غیرفعال‌سازی ارائه‌دهنده LDAP
     */
    @Transactional
    public void disableProvider(Long id, String disabledBy) {
        ldapProviderRepository.findById(id).ifPresent(p -> {
            p.setIsEnabled(false);
            ldapProviderRepository.save(p);
            LdapProviderConfig config = toConfig(p);
            config.setEnabled(false);
            multiLdapAuthService.updateProvider(config);
            auditService.log("LDAP_PROVIDER_DISABLE", "LDAP_CONFIG", id,
                disabledBy, "غیرفعال‌سازی: " + p.getName(), "system", true);
        });
    }

    public List<LdapProviderEntity> getAllProviders() {
        return ldapProviderRepository.findAllByOrderByDisplayOrderAsc();
    }

    public Optional<LdapProviderEntity> getById(Long id) {
        return ldapProviderRepository.findById(id);
    }

    @Transactional
    public void deleteProvider(Long id, String deletedBy) {
        ldapProviderRepository.findById(id).ifPresent(p -> {
            ldapProviderRepository.delete(p);
            auditService.log("LDAP_PROVIDER_DELETE", "LDAP_CONFIG", id,
                deletedBy, "حذف ارائه‌دهنده LDAP: " + p.getName(), "system", true);
        });
    }

    private void registerProvider(LdapProviderEntity entity) {
        try {
            multiLdapAuthService.registerProvider(toConfig(entity));
        } catch (Exception e) {
            log.error("خطا در ثبت ارائه‌دهنده LDAP {}: {}", entity.getName(), e.getMessage());
        }
    }

    private LdapProviderConfig toConfig(LdapProviderEntity e) {
        return LdapProviderConfig.builder()
            .id(e.getProviderId())
            .name(e.getName())
            .url(e.getUrl())
            .base(e.getBaseDn())
            .userDn(e.getBindDn())
            .password(e.getBindPassword())
            .userSearchAttribute(extractAttributeFromFilter(e.getUserSearchFilter()))
            .enabled(Boolean.TRUE.equals(e.getIsEnabled()))
            .build();
    }

    private String extractAttributeFromFilter(String filter) {
        if (filter == null) return "uid";
        if (filter.contains("sAMAccountName")) return "sAMAccountName";
        if (filter.contains("mail")) return "mail";
        if (filter.contains("uid")) return "uid";
        return "uid";
    }
}
