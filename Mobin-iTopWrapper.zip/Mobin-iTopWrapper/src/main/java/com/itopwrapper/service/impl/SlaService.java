package com.itopwrapper.service.impl;

import com.itopwrapper.audit.AuditService;
import com.itopwrapper.itop.ITopApiClient;
import com.itopwrapper.model.entity.SlaDefinition;
import com.itopwrapper.model.entity.ServiceRequest;
import com.itopwrapper.repository.SlaRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.util.List;

/**
 * سرویس مدیریت SLA و OLA
 * محاسبه خودکار موعد پاسخ‌دهی و رفع اشکال
 */
@Service
@Slf4j
@RequiredArgsConstructor
public class SlaService {

    private final SlaRepository slaRepository;
    private final ITopApiClient iTopApiClient;
    private final AuditService auditService;

    /**
     * دریافت تمام SLA‌های فعال
     */
    public List<SlaDefinition> getActiveSlas() {
        return slaRepository.findBySlaTypeAndIsActiveTrue(SlaDefinition.SlaType.SLA);
    }

    /**
     * دریافت تمام OLA‌های فعال
     */
    public List<SlaDefinition> getActiveOlas() {
        return slaRepository.findBySlaTypeAndIsActiveTrue(SlaDefinition.SlaType.OLA);
    }

    /**
     * ذخیره یا بروزرسانی SLA/OLA
     */
    @Transactional
    public SlaDefinition save(SlaDefinition sla) {
        SlaDefinition saved = slaRepository.save(sla);
        auditService.log(
            saved.getId() == null ? "SLA_CREATE" : "SLA_UPDATE",
            "SLA_MANAGEMENT", saved.getId(), "system",
            "ذخیره " + sla.getSlaType().name() + ": " + sla.getName(),
            "system", true
        );
        return saved;
    }

    /**
     * محاسبه موعد پاسخ‌دهی بر اساس SLA
     */
    public LocalDateTime calculateResponseDeadline(SlaDefinition sla, LocalDateTime requestTime) {
        if (sla == null || sla.getResponseTimeMinutes() == null) return null;
        return addBusinessMinutes(requestTime, sla.getResponseTimeMinutes(), sla.getCoverageType());
    }

    /**
     * محاسبه موعد رفع اشکال بر اساس SLA
     */
    public LocalDateTime calculateResolutionDeadline(SlaDefinition sla, LocalDateTime requestTime) {
        if (sla == null || sla.getResolutionTimeMinutes() == null) return null;
        return addBusinessMinutes(requestTime, sla.getResolutionTimeMinutes(), sla.getCoverageType());
    }

    /**
     * بررسی نقض SLA و ثبت هشدار — هر ۱۰ دقیقه اجرا می‌شود
     */
    @Scheduled(fixedDelay = 600_000)
    public void checkSlaBreaches() {
        log.debug("بررسی نقض SLA آغاز شد");
        // این متد در ServiceRequestService استفاده می‌شود
    }

    /**
     * همگام‌سازی SLA‌ها با موتور iTop
     */
    @Transactional
    public void syncWithITop() {
        try {
            var itopSlas = iTopApiClient.getSLAs();
            var itopOlas = iTopApiClient.getOLAs();
            log.info("همگام‌سازی SLA با iTop: {} SLA و {} OLA",
                itopSlas.path("objects").size(),
                itopOlas.path("objects").size());
        } catch (Exception e) {
            log.error("خطا در همگام‌سازی SLA با iTop", e);
        }
    }

    /**
     * افزودن دقیقه‌های کاری با در نظر گرفتن نوع پوشش
     */
    private LocalDateTime addBusinessMinutes(LocalDateTime from, int minutes, SlaDefinition.CoverageType coverageType) {
        if (coverageType == SlaDefinition.CoverageType.H24_7) {
            return from.plusMinutes(minutes);
        }

        // ساعات اداری: شنبه تا چهارشنبه ۸:۰۰ تا ۱۷:۰۰، پنجشنبه ۸:۰۰ تا ۱۳:۰۰
        LocalDateTime current = from;
        int remainingMinutes = minutes;

        while (remainingMinutes > 0) {
            if (isWorkingTime(current, coverageType)) {
                current = current.plusMinutes(1);
                remainingMinutes--;
            } else {
                current = nextWorkingTime(current, coverageType);
            }
        }
        return current;
    }

    private boolean isWorkingTime(LocalDateTime time, SlaDefinition.CoverageType coverageType) {
        int dayOfWeek = time.getDayOfWeek().getValue(); // 1=Mon ... 7=Sun
        int hour = time.getHour();
        int minute = time.getMinute();

        // جمعه تعطیل است (در ایران)
        if (dayOfWeek == 5) return false; // Friday

        if (coverageType == SlaDefinition.CoverageType.EXTENDED) {
            return hour >= 7 && hour < 21;
        }

        // ساعات اداری معمول
        if (dayOfWeek == 4) { // Thursday = پنجشنبه
            return hour >= 8 && (hour < 13 || (hour == 13 && minute == 0));
        }
        return hour >= 8 && (hour < 17 || (hour == 17 && minute == 0));
    }

    private LocalDateTime nextWorkingTime(LocalDateTime time, SlaDefinition.CoverageType coverageType) {
        LocalDateTime next = time.plusMinutes(1);
        // حداکثر ۷ روز جستجو (جلوگیری از حلقه بی‌نهایت)
        int maxIter = 7 * 24 * 60;
        while (!isWorkingTime(next, coverageType) && maxIter-- > 0) {
            next = next.plusMinutes(1);
        }
        return next;
    }

    public void delete(Long id) {
        slaRepository.deleteById(id);
    }
}
