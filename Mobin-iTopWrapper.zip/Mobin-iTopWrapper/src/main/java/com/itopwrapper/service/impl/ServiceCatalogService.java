package com.itopwrapper.service.impl;

import com.itopwrapper.audit.AuditService;
import com.itopwrapper.model.entity.ServiceCategory;
import com.itopwrapper.model.entity.ServiceItem;
import com.itopwrapper.pricing.PricingEngine;
import com.itopwrapper.pricing.PricingResult;
import com.itopwrapper.repository.ServiceCategoryRepository;
import com.itopwrapper.repository.ServiceItemRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.*;

/**
 * سرویس مدیریت کاتالوگ خدمات
 * شامل منطق دسته‌بندی، زیردسته و آیتم خدمت
 */
@Service
@Slf4j
@RequiredArgsConstructor
public class ServiceCatalogService {

    private final ServiceCategoryRepository categoryRepository;
    private final ServiceItemRepository serviceItemRepository;
    private final PricingEngine pricingEngine;
    private final AuditService auditService;

    // ===== دسته‌بندی‌ها =====

    public List<ServiceCategory> getRootCategories() {
        return categoryRepository.findByParentIsNullAndIsActiveTrue();
    }

    public List<ServiceCategory> getAllCategories() {
        return categoryRepository.findAll();
    }

    public Optional<ServiceCategory> getCategoryById(Long id) {
        return categoryRepository.findById(id);
    }

    @Transactional
    public ServiceCategory saveCategory(ServiceCategory category, String savedBy) {
        boolean isNew = category.getId() == null;
        ServiceCategory saved = categoryRepository.save(category);
        auditService.log(
            isNew ? "CATEGORY_CREATE" : "CATEGORY_UPDATE",
            "SERVICE_CATALOG", saved.getId(), savedBy,
            (isNew ? "ایجاد" : "بروزرسانی") + " دسته: " + category.getName(),
            "system", true);
        return saved;
    }

    @Transactional
    public void deleteCategory(Long id, String deletedBy) {
        categoryRepository.findById(id).ifPresent(cat -> {
            // غیرفعال به جای حذف (برای حفظ سابقه)
            cat.setIsActive(false);
            categoryRepository.save(cat);
            auditService.log("CATEGORY_DELETE", "SERVICE_CATALOG", id,
                deletedBy, "حذف دسته: " + cat.getName(), "system", true);
        });
    }

    /**
     * ساخت درخت دسته‌بندی برای نمایش در UI
     */
    public List<Map<String, Object>> buildCategoryTree() {
        List<ServiceCategory> all = categoryRepository.findAll();
        return buildTreeRecursive(all, null);
    }

    private List<Map<String, Object>> buildTreeRecursive(List<ServiceCategory> all, Long parentId) {
        List<Map<String, Object>> result = new ArrayList<>();
        all.stream()
            .filter(c -> Objects.equals(parentId, c.getParent() != null ? c.getParent().getId() : null))
            .sorted(Comparator.comparing(ServiceCategory::getDisplayOrder))
            .forEach(cat -> {
                Map<String, Object> node = new LinkedHashMap<>();
                node.put("id",          cat.getId());
                node.put("name",        cat.getName());
                node.put("description", cat.getDescription());
                node.put("iconClass",   cat.getIconClass());
                node.put("isActive",    cat.getIsActive());
                node.put("serviceCount", serviceItemRepository.findByCategoryAndIsActiveTrue(cat).size());
                node.put("children",    buildTreeRecursive(all, cat.getId()));
                result.add(node);
            });
        return result;
    }

    // ===== آیتم‌های خدمت =====

    public List<ServiceItem> getServicesByCategory(Long categoryId) {
        return categoryRepository.findById(categoryId)
            .map(serviceItemRepository::findByCategoryAndIsActiveTrue)
            .orElse(List.of());
    }

    public List<ServiceItem> getFeaturedServices() {
        return serviceItemRepository.findByIsFeaturedTrueAndIsActiveTrue();
    }

    public List<ServiceItem> getAllActiveServices() {
        return serviceItemRepository.findByIsActiveTrue();
    }

    public Optional<ServiceItem> getServiceById(Long id) {
        return serviceItemRepository.findById(id);
    }

    @Transactional
    public ServiceItem saveService(ServiceItem service, String savedBy) {
        boolean isNew = service.getId() == null;
        ServiceItem saved = serviceItemRepository.save(service);
        auditService.log(
            isNew ? "SERVICE_CREATE" : "SERVICE_UPDATE",
            "SERVICE_CATALOG", saved.getId(), savedBy,
            (isNew ? "ایجاد" : "بروزرسانی") + " خدمت: " + service.getName(),
            "system", true);
        return saved;
    }

    @Transactional
    public void deleteService(Long id, String deletedBy) {
        serviceItemRepository.findById(id).ifPresent(svc -> {
            svc.setIsActive(false);
            serviceItemRepository.save(svc);
            auditService.log("SERVICE_DELETE", "SERVICE_CATALOG", id,
                deletedBy, "حذف خدمت: " + svc.getName(), "system", true);
        });
    }

    /**
     * محاسبه قیمت برای آیتم خدمت
     */
    public PricingResult calculatePrice(Long serviceId, Map<String, Object> params,
                                         String customerTierName) {
        ServiceItem service = serviceItemRepository.findById(serviceId)
            .orElseThrow(() -> new RuntimeException("خدمت یافت نشد: " + serviceId));
        PricingEngine.CustomerTier tier = parseTier(customerTierName);
        return pricingEngine.calculatePrice(service, params, tier);
    }

    /**
     * آمار کاتالوگ برای داشبورد
     */
    public Map<String, Object> getCatalogStats() {
        Map<String, Object> stats = new LinkedHashMap<>();
        stats.put("totalCategories",   categoryRepository.count());
        stats.put("activeCategories",  categoryRepository.findByParentIsNullAndIsActiveTrue().size());
        stats.put("totalServices",     serviceItemRepository.count());
        stats.put("activeServices",    serviceItemRepository.findByIsActiveTrue().size());
        stats.put("featuredServices",  serviceItemRepository.findByIsFeaturedTrueAndIsActiveTrue().size());
        // شمارش بر اساس نوع خدمت
        Map<String, Long> byType = new LinkedHashMap<>();
        for (ServiceItem.ServiceType t : ServiceItem.ServiceType.values()) {
            long cnt = serviceItemRepository.findByIsActiveTrue().stream()
                .filter(s -> s.getServiceType() == t).count();
            if (cnt > 0) byType.put(t.name(), cnt);
        }
        stats.put("byType", byType);
        return stats;
    }

    private PricingEngine.CustomerTier parseTier(String name) {
        try {
            return PricingEngine.CustomerTier.valueOf(name.toUpperCase());
        } catch (Exception e) {
            return PricingEngine.CustomerTier.BRONZE;
        }
    }
}
