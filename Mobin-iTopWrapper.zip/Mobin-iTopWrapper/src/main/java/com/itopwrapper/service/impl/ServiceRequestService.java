package com.itopwrapper.service.impl;

import com.fasterxml.jackson.databind.JsonNode;
import com.itopwrapper.audit.AuditService;
import com.itopwrapper.itop.ITopApiClient;
import com.itopwrapper.itop.ITopApiException;
import com.itopwrapper.model.entity.*;
import com.itopwrapper.pricing.PricingEngine;
import com.itopwrapper.pricing.PricingResult;
import com.itopwrapper.repository.*;
import com.itopwrapper.wallet.InsufficientBalanceException;
import com.itopwrapper.wallet.WalletService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Sort;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

/**
 * سرویس مدیریت درخواست‌های خدمت
 * پل ارتباطی میان Wrapper و موتور iTop — همچنین مسئول یکپارچگی با کیف‌پول مشتری:
 *  - اگر خدمت walletEnabled=true و IMMEDIATE باشد: هنگام ثبت درخواست، مبلغ فوراً کسر می‌شود.
 *  - اگر ON_APPROVAL باشد: هنگام ثبت، مبلغ Hold و با تأیید/رفع نهایی (Capture) یا
 *    با رد/لغو آزاد (Release) می‌شود.
 */
@Service
@Slf4j
@RequiredArgsConstructor
public class ServiceRequestService {

    private final ServiceRequestRepository requestRepository;
    private final UserRepository userRepository;
    private final ServiceItemRepository serviceItemRepository;
    private final SlaRepository slaRepository;
    private final ITopApiClient iTopApiClient;
    private final AuditService auditService;
    private final SlaService slaService;
    private final WalletService walletService;
    private final PricingEngine pricingEngine;

    /**
     * ثبت درخواست جدید — همزمان در wrapper و iTop، با کسر/مسدودسازی کیف‌پول
     */
    @Transactional
    public ServiceRequest createRequest(Long requesterId, Long serviceItemId,
                                        String title, String description,
                                        ServiceRequest.Priority priority) {
        return createRequest(requesterId, serviceItemId, title, description, priority,
            Map.of(), PricingEngine.CustomerTier.BRONZE);
    }

    /**
     * ثبت درخواست جدید با پارامترهای محاسبه قیمت (تعداد ماه/ساعت/کاربر و سطح مشتری)
     */
    @Transactional
    public ServiceRequest createRequest(Long requesterId, Long serviceItemId,
                                        String title, String description,
                                        ServiceRequest.Priority priority,
                                        Map<String, Object> pricingParams,
                                        PricingEngine.CustomerTier customerTier) {

        User requester = userRepository.findById(requesterId)
            .orElseThrow(() -> new RuntimeException("کاربر یافت نشد"));

        ServiceItem serviceItem = null;
        SlaDefinition sla = null;
        BigDecimal finalPrice = BigDecimal.ZERO;

        if (serviceItemId != null) {
            serviceItem = serviceItemRepository.findById(serviceItemId).orElse(null);
            if (serviceItem != null && serviceItem.getSlaHours() != null) {
                sla = slaRepository.findBySlaTypeAndIsActiveTrue(SlaDefinition.SlaType.SLA)
                    .stream().findFirst().orElse(null);
            }
            if (serviceItem != null && Boolean.TRUE.equals(serviceItem.getWalletEnabled())) {
                PricingResult pricing = pricingEngine.calculatePrice(
                    serviceItem, pricingParams != null ? pricingParams : Map.of(), customerTier);
                finalPrice = pricing.getFinalPrice();
            }
        }

        // محاسبه موعدهای SLA
        LocalDateTime now = LocalDateTime.now();
        LocalDateTime responseDeadline = (sla != null)
            ? slaService.calculateResponseDeadline(sla, now) : now.plusHours(4);
        LocalDateTime resolutionDeadline = (sla != null)
            ? slaService.calculateResolutionDeadline(sla, now) : now.plusHours(24);

        String ticketNumber = generateTicketNumber();

        ServiceRequest request = ServiceRequest.builder()
            .ticketNumber(ticketNumber)
            .title(title)
            .description(description)
            .requester(requester)
            .serviceItem(serviceItem)
            .sla(sla)
            .priority(priority)
            .status(ServiceRequest.RequestStatus.NEW)
            .responseDeadline(responseDeadline)
            .resolutionDeadline(resolutionDeadline)
            .agreedPrice(finalPrice)
            .walletPaymentStatus(ServiceRequest.WalletPaymentStatus.NOT_APPLICABLE)
            .build();

        request = requestRepository.save(request);

        // ===== یکپارچگی کیف‌پول =====
        if (serviceItem != null && Boolean.TRUE.equals(serviceItem.getWalletEnabled())
                && finalPrice.compareTo(BigDecimal.ZERO) > 0) {
            chargeWalletOnCreate(request, serviceItem, finalPrice);
        }

        // ثبت در موتور iTop
        syncToITop(request);

        auditService.log("REQUEST_CREATE", "SERVICE_REQUEST", request.getId(),
            requester.getUsername(), "درخواست جدید: " + ticketNumber +
                (finalPrice.compareTo(BigDecimal.ZERO) > 0 ? " — مبلغ: " + finalPrice + " ریال" : ""),
            "system", true);

        return request;
    }

    /** اعمال کسر فوری یا Hold روی کیف‌پول هنگام ثبت درخواست (بر اساس تنظیم خدمت) */
    private void chargeWalletOnCreate(ServiceRequest request, ServiceItem serviceItem, BigDecimal amount) {
        try {
            WalletTransaction tx;
            if (serviceItem.getWalletDeductTiming() == ServiceItem.WalletDeductTiming.IMMEDIATE) {
                tx = walletService.purchase(request.getRequester().getId(), amount, request,
                    "خرید خدمت: " + serviceItem.getName() + " — تیکت " + request.getTicketNumber(),
                    request.getRequester().getUsername(), "system");
                request.setWalletPaymentStatus(ServiceRequest.WalletPaymentStatus.CAPTURED);
            } else {
                tx = walletService.hold(request.getRequester().getId(), amount, request,
                    "مسدودسازی بابت خدمت: " + serviceItem.getName() + " — تیکت " + request.getTicketNumber(),
                    request.getRequester().getUsername(), "system");
                request.setWalletPaymentStatus(ServiceRequest.WalletPaymentStatus.HELD);
            }
            if (tx != null) request.setWalletTransactionId(tx.getId());
            requestRepository.save(request);
        } catch (InsufficientBalanceException e) {
            // در صورت کمبود موجودی، درخواست لغو می‌شود تا کاربر ابتدا کیف‌پول را شارژ کند
            request.setStatus(ServiceRequest.RequestStatus.CANCELLED);
            requestRepository.save(request);
            auditService.log("REQUEST_WALLET_REJECTED", "WALLET", request.getId(),
                request.getRequester().getUsername(),
                "ثبت درخواست به‌دلیل کمبود موجودی کیف‌پول لغو شد: " + e.getMessage(), "system", false);
            throw e;
        }
    }

    /**
     * بروزرسانی وضعیت درخواست — همراه با تسویه کیف‌پول (Capture/Release) برای خدمات ON_APPROVAL
     */
    @Transactional
    public ServiceRequest updateStatus(Long requestId, ServiceRequest.RequestStatus newStatus,
                                        String comment, String updatedBy) {
        ServiceRequest request = requestRepository.findById(requestId)
            .orElseThrow(() -> new RuntimeException("درخواست یافت نشد"));

        ServiceRequest.RequestStatus oldStatus = request.getStatus();
        request.setStatus(newStatus);

        LocalDateTime now = LocalDateTime.now();
        if (newStatus == ServiceRequest.RequestStatus.RESOLVED && request.getRespondedAt() == null) {
            request.setRespondedAt(now);
            request.setResolvedAt(now);
        } else if (newStatus == ServiceRequest.RequestStatus.CLOSED) {
            request.setClosedAt(now);
        }

        request = requestRepository.save(request);

        // ===== تسویه کیف‌پول برای خدماتی که در حالت HELD هستند =====
        if (request.getWalletPaymentStatus() == ServiceRequest.WalletPaymentStatus.HELD) {
            settleWalletOnStatusChange(request, newStatus, updatedBy);
        }

        // همگام‌سازی با iTop
        if (request.getItopRequestId() != null) {
            updateITopStatus(request, newStatus);
        }

        auditService.log("REQUEST_STATUS_CHANGE", "SERVICE_REQUEST", requestId,
            updatedBy,
            "تغییر وضعیت " + request.getTicketNumber() + ": " + oldStatus + " → " + newStatus,
            "system", true);

        return request;
    }

    /** نهایی‌سازی یا آزادسازی مبلغ Hold شده بر اساس وضعیت جدید درخواست */
    private void settleWalletOnStatusChange(ServiceRequest request,
                                             ServiceRequest.RequestStatus newStatus, String performedBy) {
        if (newStatus == ServiceRequest.RequestStatus.RESOLVED) {
            walletService.capture(request, performedBy, "system");
            request.setWalletPaymentStatus(ServiceRequest.WalletPaymentStatus.CAPTURED);
            requestRepository.save(request);
        } else if (newStatus == ServiceRequest.RequestStatus.CANCELLED) {
            walletService.release(request, performedBy, "system");
            request.setWalletPaymentStatus(ServiceRequest.WalletPaymentStatus.RELEASED);
            requestRepository.save(request);
        }
        // سایر وضعیت‌ها (ASSIGNED, IN_PROGRESS, PENDING) تأثیری بر کیف‌پول ندارند
    }

    /**
     * افزودن نظر به درخواست
     */
    @Transactional
    public RequestComment addComment(Long requestId, Long authorId, String content,
                                      RequestComment.CommentType type) {
        ServiceRequest request = requestRepository.findById(requestId)
            .orElseThrow(() -> new RuntimeException("درخواست یافت نشد"));
        User author = userRepository.findById(authorId)
            .orElseThrow(() -> new RuntimeException("کاربر یافت نشد"));

        RequestComment comment = RequestComment.builder()
            .request(request)
            .author(author)
            .content(content)
            .commentType(type)
            .build();

        request.getComments().add(comment);
        requestRepository.save(request);

        auditService.log("REQUEST_COMMENT", "SERVICE_REQUEST", requestId,
            author.getUsername(), "افزودن نظر به " + request.getTicketNumber(), "system", true);

        return comment;
    }

    /**
     * تخصیص درخواست به اپراتور
     */
    @Transactional
    public ServiceRequest assignRequest(Long requestId, Long assigneeId, String assignedBy) {
        ServiceRequest request = requestRepository.findById(requestId)
            .orElseThrow(() -> new RuntimeException("درخواست یافت نشد"));
        User assignee = userRepository.findById(assigneeId)
            .orElseThrow(() -> new RuntimeException("کاربر یافت نشد"));

        request.setAssignee(assignee);
        request.setStatus(ServiceRequest.RequestStatus.ASSIGNED);
        request = requestRepository.save(request);

        auditService.log("REQUEST_ASSIGN", "SERVICE_REQUEST", requestId,
            assignedBy, "تخصیص " + request.getTicketNumber() + " به " + assignee.getUsername(),
            "system", true);

        return request;
    }

    /**
     * دریافت درخواست‌های کاربر
     */
    public Page<ServiceRequest> getRequesterRequests(Long userId, int page, int size) {
        User user = userRepository.findById(userId)
            .orElseThrow(() -> new RuntimeException("کاربر یافت نشد"));
        return requestRepository.findByRequesterOrderByCreatedAtDesc(
            user, PageRequest.of(page, size, Sort.by(Sort.Direction.DESC, "createdAt")));
    }

    /**
     * دریافت درخواست‌های تخصیص‌یافته به اپراتور
     */
    public Page<ServiceRequest> getAssigneeRequests(Long userId, int page, int size) {
        User user = userRepository.findById(userId)
            .orElseThrow(() -> new RuntimeException("کاربر یافت نشد"));
        return requestRepository.findByAssignee(
            user, PageRequest.of(page, size, Sort.by(Sort.Direction.DESC, "createdAt")));
    }

    /**
     * بررسی خودکار نقض SLA — هر ۵ دقیقه
     */
    @Scheduled(fixedDelay = 300_000)
    public void checkAndAlertSlaBreaches() {
        List<ServiceRequest> breached = requestRepository.findBreachedSla(LocalDateTime.now());
        if (!breached.isEmpty()) {
            log.warn("تعداد {} درخواست با نقض SLA شناسایی شد", breached.size());
            breached.forEach(req ->
                auditService.log("SLA_BREACH", "SLA_MANAGEMENT", req.getId(),
                    "system", "نقض SLA در درخواست: " + req.getTicketNumber(),
                    "system", false)
            );
        }
    }

    /**
     * آمار کلی درخواست‌ها برای داشبورد
     */
    public Map<String, Long> getRequestStats() {
        Map<String, Long> stats = new HashMap<>();
        for (ServiceRequest.RequestStatus status : ServiceRequest.RequestStatus.values()) {
            stats.put(status.name(), requestRepository.countByStatus(status));
        }
        stats.put("BREACHED_SLA", (long) requestRepository.findBreachedSla(LocalDateTime.now()).size());
        return stats;
    }

    /** ثبت درخواست در iTop */
    private void syncToITop(ServiceRequest request) {
        try {
            Map<String, Object> fields = new HashMap<>();
            fields.put("title",       request.getTitle());
            fields.put("description", request.getDescription());
            fields.put("priority",    mapPriority(request.getPriority()));
            fields.put("origin",      "portal");

            JsonNode result = iTopApiClient.createObject("UserRequest", fields);
            if (result.has("objects")) {
                result.path("objects").fields().forEachRemaining(entry -> {
                    JsonNode obj = entry.getValue();
                    if (obj.has("key")) {
                        request.setItopRequestId(obj.get("key").asLong());
                        if (obj.has("fields") && obj.path("fields").has("ref")) {
                            request.setItopRef(obj.path("fields").get("ref").asText());
                        }
                    }
                });
                requestRepository.save(request);
            }
        } catch (Exception e) {
            log.warn("خطا در ثبت درخواست در iTop: {}", e.getMessage());
        }
    }

    /** بروزرسانی وضعیت در iTop */
    private void updateITopStatus(ServiceRequest request, ServiceRequest.RequestStatus newStatus) {
        try {
            String stimulus = mapStatusToStimulus(newStatus);
            if (stimulus != null) {
                iTopApiClient.applyStimulus("UserRequest",
                    "SELECT UserRequest WHERE id=" + request.getItopRequestId(),
                    stimulus, null);
            }
        } catch (Exception e) {
            log.warn("خطا در بروزرسانی وضعیت در iTop: {}", e.getMessage());
        }
    }

    private String mapPriority(ServiceRequest.Priority p) {
        return switch (p) {
            case LOW      -> "4";
            case MEDIUM   -> "3";
            case HIGH     -> "2";
            case CRITICAL -> "1";
        };
    }

    private String mapStatusToStimulus(ServiceRequest.RequestStatus status) {
        return switch (status) {
            case ASSIGNED    -> "ev_assign";
            case IN_PROGRESS -> "ev_start_working";
            case RESOLVED    -> "ev_resolve";
            case CLOSED      -> "ev_close";
            case CANCELLED   -> "ev_cancel";
            default          -> null;
        };
    }

    private String generateTicketNumber() {
        String prefix = "REQ";
        String timestamp = LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyyMMdd"));
        long count = requestRepository.count() + 1;
        return String.format("%s-%s-%05d", prefix, timestamp, count);
    }
}
