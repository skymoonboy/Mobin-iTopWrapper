package com.itopwrapper.service.impl;

import com.itopwrapper.audit.AuditService;
import com.itopwrapper.model.entity.Project;
import com.itopwrapper.model.entity.ProjectTask;
import com.itopwrapper.model.entity.User;
import com.itopwrapper.repository.ProjectRepository;
import com.itopwrapper.repository.UserRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.temporal.ChronoUnit;
import java.util.*;

/**
 * سرویس مدیریت پروژه
 * شامل داده‌های گانت چارت
 */
@Service
@Slf4j
@RequiredArgsConstructor
public class ProjectService {

    private final ProjectRepository projectRepository;
    private final UserRepository userRepository;
    private final AuditService auditService;

    public List<Project> getAllProjects() {
        return projectRepository.findAll();
    }

    public Optional<Project> getById(Long id) {
        return projectRepository.findByIdWithTasks(id);
    }

    @Transactional
    public Project createProject(Project project, String createdBy) {
        project.setCreatedBy(createdBy);
        project.setCompletionPercent(0);
        Project saved = projectRepository.save(project);
        auditService.log("PROJECT_CREATE", "PROJECT_MGMT", saved.getId(),
            createdBy, "پروژه جدید: " + project.getName(), "system", true);
        return saved;
    }

    @Transactional
    public Project updateProject(Long id, Project updated, String updatedBy) {
        Project project = projectRepository.findById(id)
            .orElseThrow(() -> new RuntimeException("پروژه یافت نشد"));

        project.setName(updated.getName());
        project.setDescription(updated.getDescription());
        project.setStatus(updated.getStatus());
        project.setStartDate(updated.getStartDate());
        project.setEndDate(updated.getEndDate());
        project.setBudget(updated.getBudget());

        if (updated.getManager() != null) project.setManager(updated.getManager());
        if (updated.getCostCenter() != null) project.setCostCenter(updated.getCostCenter());

        recalculateCompletion(project);
        Project saved = projectRepository.save(project);
        auditService.log("PROJECT_UPDATE", "PROJECT_MGMT", id,
            updatedBy, "بروزرسانی پروژه: " + project.getName(), "system", true);
        return saved;
    }

    @Transactional
    public ProjectTask addTask(Long projectId, ProjectTask task, String createdBy) {
        Project project = projectRepository.findByIdWithTasks(projectId)
            .orElseThrow(() -> new RuntimeException("پروژه یافت نشد"));
        task.setProject(project);
        project.getTasks().add(task);
        projectRepository.save(project);
        auditService.log("TASK_CREATE", "PROJECT_MGMT", projectId,
            createdBy, "وظیفه جدید: " + task.getName(), "system", true);
        return task;
    }

    @Transactional
    public ProjectTask updateTaskProgress(Long projectId, Long taskId, int percent, String updatedBy) {
        Project project = projectRepository.findByIdWithTasks(projectId)
            .orElseThrow(() -> new RuntimeException("پروژه یافت نشد"));

        ProjectTask task = project.getTasks().stream()
            .filter(t -> t.getId().equals(taskId))
            .findFirst()
            .orElseThrow(() -> new RuntimeException("وظیفه یافت نشد"));

        task.setCompletionPercent(Math.min(100, Math.max(0, percent)));
        if (percent >= 100) task.setStatus(ProjectTask.TaskStatus.COMPLETED);
        else if (percent > 0) task.setStatus(ProjectTask.TaskStatus.IN_PROGRESS);

        recalculateCompletion(project);
        projectRepository.save(project);
        return task;
    }

    /**
     * تولید داده گانت چارت در قالب JSON
     */
    public List<Map<String, Object>> buildGanttData(Long projectId) {
        Project project = projectRepository.findByIdWithTasks(projectId)
            .orElseThrow(() -> new RuntimeException("پروژه یافت نشد"));

        List<Map<String, Object>> ganttRows = new ArrayList<>();
        LocalDate projectStart = project.getStartDate() != null
            ? project.getStartDate() : LocalDate.now().withDayOfMonth(1);

        for (ProjectTask task : project.getTasks()) {
            if (task.getParentTask() != null) continue; // فقط وظایف سطح اول

            Map<String, Object> row = new LinkedHashMap<>();
            row.put("id",         task.getId());
            row.put("name",       task.getName());
            row.put("start",      task.getStartDate().toString());
            row.put("end",        task.getEndDate().toString());
            row.put("progress",   task.getCompletionPercent());
            row.put("status",     task.getStatus().name());
            row.put("color",      task.getColor());
            row.put("assignee",   task.getAssignee() != null ? task.getAssignee().getFullName() : "");
            row.put("offsetDays", ChronoUnit.DAYS.between(projectStart, task.getStartDate()));
            row.put("durationDays", ChronoUnit.DAYS.between(task.getStartDate(), task.getEndDate()) + 1);
            row.put("isOnTime",   !task.getEndDate().isBefore(LocalDate.now())
                                   || task.getStatus() == ProjectTask.TaskStatus.COMPLETED);
            ganttRows.add(row);
        }
        return ganttRows;
    }

    /**
     * آمار پروژه برای داشبورد
     */
    public Map<String, Object> getProjectStats() {
        List<Project> all = projectRepository.findAll();
        Map<String, Object> stats = new HashMap<>();
        stats.put("total", all.size());
        stats.put("active", all.stream().filter(p -> p.getStatus() == Project.ProjectStatus.ACTIVE).count());
        stats.put("completed", all.stream().filter(p -> p.getStatus() == Project.ProjectStatus.COMPLETED).count());
        stats.put("onHold", all.stream().filter(p -> p.getStatus() == Project.ProjectStatus.ON_HOLD).count());
        stats.put("avgCompletion", all.stream()
            .mapToInt(Project::getCompletionPercent).average().orElse(0));
        BigDecimal totalBudget = all.stream()
            .filter(p -> p.getBudget() != null)
            .map(Project::getBudget)
            .reduce(BigDecimal.ZERO, BigDecimal::add);
        stats.put("totalBudget", totalBudget);
        return stats;
    }

    private void recalculateCompletion(Project project) {
        if (project.getTasks().isEmpty()) return;
        int avg = (int) project.getTasks().stream()
            .mapToInt(ProjectTask::getCompletionPercent)
            .average().orElse(0);
        project.setCompletionPercent(avg);
        if (avg >= 100) project.setStatus(Project.ProjectStatus.COMPLETED);
    }

    public void deleteProject(Long id, String deletedBy) {
        projectRepository.deleteById(id);
        auditService.log("PROJECT_DELETE", "PROJECT_MGMT", id,
            deletedBy, "حذف پروژه", "system", true);
    }
}
