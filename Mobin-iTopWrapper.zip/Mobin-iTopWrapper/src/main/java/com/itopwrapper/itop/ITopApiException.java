package com.itopwrapper.itop;

public class ITopApiException extends Exception {
    public ITopApiException(String message) { super(message); }
    public ITopApiException(String message, Throwable cause) { super(message, cause); }
}
