package com.itopwrapper.itop;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ObjectNode;
import ir.itop.client.core.ITopRestClient;
import ir.itop.client.model.ITopObject;
import jakarta.annotation.PostConstruct;
import jakarta.annotation.PreDestroy;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Map;

/**
 * کلاینت ارتباط با موتور iTop — لایه سازگاری (Facade) روی {@link ITopRestClient}.
 *
 * این کلاس به‌گونه‌ای طراحی شده که:
 *  ۱) امضای متدهای قدیمی (که در سرویس‌های قبلی پروژه استفاده شده) را حفظ کند
 *     تا نیازی به بازنویسی کنترلرها/سرویس‌های موجود نباشد؛
 *  ۲) در پشت صحنه از کلاینت کامل و حرفه‌ای {@link ITopRestClient}
 *     (پشتیبانی Incident/Change/Problem/Project/Gantt/CostCenter/CMDB) استفاده کند.
 *
 * برای دسترسی به قابلیت‌های پیشرفته‌تر (گردش‌کار تیکت، پروژه و گانت،
 * مرکز هزینه و غیره) از متد {@link #raw()} برای دسترسی مستقیم به
 * {@link ITopRestClient} استفاده کنید.
 */
@Service
@Slf4j
public class ITopApiClient {

    @Value("${itop.api.url}")
    private String itopUrl;

    @Value("${itop.api.username}")
    private String apiUsername;

    @Value("${itop.api.password}")
    private String apiPassword;

    @Value("${itop.api.version:1.3}")
    private String apiVersion;

    private final ObjectMapper objectMapper = new ObjectMapper();
    private ITopRestClient client;

    @PostConstruct
    private void init() {
        this.client = new ITopRestClient(itopUrl, apiUsername, apiPassword, null, apiVersion);
        log.info("ITopApiClient راه‌اندازی شد (مبتنی بر ITopRestClient) — آدرس: {}", itopUrl);
    }

    @PreDestroy
    private void shutdown() {
        try { if (client != null) client.close(); } catch (Exception e) { log.warn("خطا در بستن اتصال iTop: {}", e.getMessage()); }
    }

    /** دسترسی مستقیم به کلاینت کامل برای قابلیت‌های پیشرفته (Incident/Change/Project/...) */
    public ITopRestClient raw() { return client; }

    // ===================================================================
    //  متدهای سازگار با نسخه قبلی (Legacy Compatibility) — خروجی JsonNode
    // ===================================================================

    public JsonNode getObjects(String className, String oqlFilter, String... fields) throws ITopApiException {
        try {
            String outputFields = fields.length > 0 ? String.join(",", fields) : "*";
            List<ITopObject> objects = client.getObjectsByOQL(className, oqlFilter, outputFields);
            return toResponseNode(objects);
        } catch (Exception e) {
            throw wrap(e);
        }
    }

    public JsonNode createObject(String className, Map<String, Object> fields) throws ITopApiException {
        try {
            ITopObject obj = client.createObject(className, fields, "ایجاد از طریق iTop Wrapper", "*");
            return toResponseNode(List.of(obj));
        } catch (Exception e) {
            throw wrap(e);
        }
    }

    public JsonNode updateObject(String className, String key, Map<String, Object> fields) throws ITopApiException {
        try {
            ITopObject obj = client.updateObject(className, resolveKey(key), fields, "بروزرسانی از طریق iTop Wrapper", "*");
            return toResponseNode(List.of(obj));
        } catch (Exception e) {
            throw wrap(e);
        }
    }

    public JsonNode deleteObject(String className, String key) throws ITopApiException {
        try {
            var result = client.deleteObject(className, resolveKey(key), "حذف از طریق iTop Wrapper", false);
            ObjectNode node = objectMapper.createObjectNode();
            node.put("code", 0);
            node.put("message", result.getMessage());
            node.put("affected", result.getAffectedCount());
            return node;
        } catch (Exception e) {
            throw wrap(e);
        }
    }

    public JsonNode applyStimulus(String className, String key, String stimulus,
                                   Map<String, Object> fields) throws ITopApiException {
        try {
            ITopObject obj = client.applyStimulus(className, resolveKey(key), stimulus,
                fields, "محرک از طریق iTop Wrapper", "*");
            return toResponseNode(List.of(obj));
        } catch (Exception e) {
            throw wrap(e);
        }
    }

    public JsonNode getUserInfo(String login) throws ITopApiException {
        return getObjects("Person", "SELECT Person WHERE email = '" + login + "'");
    }

    public JsonNode getSLAs() throws ITopApiException {
        return getObjects("SLA", "SELECT SLA", "name", "description");
    }

    public JsonNode getOLAs() throws ITopApiException {
        return getObjects("OLA", "SELECT OLA", "name", "description");
    }

    public JsonNode getProjects() throws ITopApiException {
        return getObjects("Project", "SELECT Project");
    }

    public JsonNode getCostCenters() throws ITopApiException {
        return getObjects("CostCenter", "SELECT CostCenter");
    }

    public JsonNode getUserRequests(String orgId) throws ITopApiException {
        String oql = orgId != null
            ? "SELECT UserRequest WHERE org_id = " + orgId
            : "SELECT UserRequest";
        return getObjects("UserRequest", oql);
    }

    public boolean isITopAvailable() {
        try {
            client.getObjectsByOQL("Organization", "SELECT Organization", "id");
            return true;
        } catch (Exception e) {
            log.warn("موتور iTop در دسترس نیست: {}", e.getMessage());
            return false;
        }
    }

    // ===================================================================
    //  کمکی‌ها
    // ===================================================================

    private Object resolveKey(String key) {
        try { return Integer.parseInt(key); } catch (NumberFormatException e) { return key; }
    }

    /** تبدیل List<ITopObject> به ساختار JsonNode مشابه پاسخ خام iTop (برای سازگاری با کد قدیمی) */
    private JsonNode toResponseNode(List<ITopObject> objects) {
        ObjectNode root = objectMapper.createObjectNode();
        root.put("code", 0);
        root.put("message", "");
        ObjectNode objectsNode = objectMapper.createObjectNode();
        int i = 0;
        for (ITopObject obj : objects) {
            ObjectNode entry = objectMapper.createObjectNode();
            entry.put("key", obj.getKey());
            entry.put("class", obj.getClassName());
            ObjectNode fieldsNode = objectMapper.createObjectNode();
            for (Map.Entry<String, Object> f : obj.getFields().entrySet()) {
                Object v = f.getValue();
                if (v == null) fieldsNode.putNull(f.getKey());
                else if (v instanceof Boolean) fieldsNode.put(f.getKey(), (Boolean) v);
                else fieldsNode.put(f.getKey(), v.toString());
            }
            entry.set("fields", fieldsNode);
            objectsNode.set("Item_" + (i++), entry);
        }
        root.set("objects", objectsNode);
        return root;
    }

    private ITopApiException wrap(Exception e) {
        if (e instanceof ITopApiException) return (ITopApiException) e;
        return new ITopApiException("خطا در ارتباط با موتور iTop: " + e.getMessage(), e);
    }
}
