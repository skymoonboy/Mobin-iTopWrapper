package com.itopwrapper.itop;

import com.fasterxml.jackson.databind.JsonNode;
import com.itopwrapper.audit.AuditService;
import com.itopwrapper.model.entity.*;
import com.itopwrapper.repository.*;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.Map;

/**
 * سرویس همگام‌سازی دوره‌ای با موتور iTop
 * تمام داده‌های موتور iTop با پایگاه داده محلی هماهنگ می‌شود
 */
@Service
@Slf4j
@RequiredArgsConstructor
public class ITopSyncService {

    private final ITopApiClient iTopApiClient;
    private final ServiceCategoryRepository categoryRepository;
    private final ServiceItemRepository serviceItemRepository;
    private final SlaRepository slaRepository;
    private final CostCenterRepository costCenterRepository;
    private final ServiceRequestRepository requestRepository;
    private final AuditService auditService;

    private boolean iTopAvailable = false;
    private LocalDateTime lastSyncTime = null;

    /**
     * بررسی وضعیت iTop — هر ۳۰ ثانیه
     */
    @Scheduled(fixedDelay = 30_000)
    public void checkITopHealth() {
        boolean available = iTopApiClient.isITopAvailable();
        if (available != iTopAvailable) {
            log.info("وضعیت موتور iTop تغییر کرد: {} → {}", iTopAvailable ? "متصل" : "قطع", available ? "متصل" : "قطع");
            iTopAvailable = available;
            if (available) {
                // اتصال برقرار شد، همگام‌سازی کامل انجام شود
                log.info("اتصال به iTop برقرار شد — همگام‌سازی کامل آغاز می‌شود");
                runFullSync();
            }
        }
    }

    /**
     * همگام‌سازی کامل — هر ۱ ساعت
     */
    @Scheduled(fixedDelay = 3_600_000, initialDelay = 60_000)
    public void scheduledFullSync() {
        if (!iTopAvailable) {
            log.debug("همگام‌سازی رد شد — iTop در دسترس نیست");
            return;
        }
        runFullSync();
    }

    /**
     * همگام‌سازی سریع درخواست‌ها — هر ۵ دقیقه
     */
    @Scheduled(fixedDelay = 300_000, initialDelay = 120_000)
    public void scheduledRequestSync() {
        if (!iTopAvailable) return;
        try {
            syncRequests();
        } catch (Exception e) {
            log.warn("خطا در همگام‌سازی سریع درخواست‌ها: {}", e.getMessage());
        }
    }

    /**
     * اجرای همگام‌سازی کامل
     */
    @Transactional
    public void runFullSync() {
        log.info("=== شروع همگام‌سازی کامل با iTop ===");
        long start = System.currentTimeMillis();

        syncServiceCatalog();
        syncSlas();
        syncCostCenters();
        syncRequests();

        lastSyncTime = LocalDateTime.now();
        long duration = System.currentTimeMillis() - start;
        log.info("=== همگام‌سازی کامل در {}ms انجام شد ===", duration);

        auditService.log("ITOP_SYNC_COMPLETE", "ITOP_SYNC", null, "system",
            String.format("همگام‌سازی کامل در %dms", duration), "system", true);
    }

    /**
     * همگام‌سازی کاتالوگ خدمات با iTop
     */
    @Transactional
    public void syncServiceCatalog() {
        try {
            // همگام‌سازی سرویس‌ها از iTop
            JsonNode result = iTopApiClient.getObjects("Service",
                "SELECT Service", "name", "description", "status");

            if (result.has("objects")) {
                result.path("objects").fields().forEachRemaining(entry -> {
                    JsonNode obj = entry.getValue();
                    JsonNode fields = obj.path("fields");
                    Long itopId = obj.path("key").asLong();
                    String name = fields.path("name").asText("");
                    String desc = fields.path("description").asText("");

                    if (name.isBlank()) return;

                    // بررسی وجود دسته
                    categoryRepository.findAll().stream()
                        .filter(c -> itopId.equals(c.getItopServiceId()))
                        .findFirst()
                        .orElseGet(() -> {
                            ServiceCategory cat = ServiceCategory.builder()
                                .name(name)
                                .description(desc)
                                .itopServiceId(itopId)
                                .isActive(true)
                                .build();
                            return categoryRepository.save(cat);
                        });
                });
                log.info("کاتالوگ خدمات از iTop همگام‌سازی شد");
            }

            // همگام‌سازی زیردسته‌ها
            JsonNode subResult = iTopApiClient.getObjects("ServiceSubcategory",
                "SELECT ServiceSubcategory", "name", "description", "service_id");

            if (subResult.has("objects")) {
                subResult.path("objects").fields().forEachRemaining(entry -> {
                    JsonNode obj = entry.getValue();
                    JsonNode fields = obj.path("fields");
                    Long itopId = obj.path("key").asLong();
                    String name = fields.path("name").asText("");

                    if (name.isBlank()) return;

                    // یافتن یا ایجاد آیتم خدمت
                    serviceItemRepository.findAll().stream()
                        .filter(s -> itopId.equals(s.getItopServiceSubcategoryId()))
                        .findFirst()
                        .ifPresentOrElse(
                            s -> {
                                s.setName(name);
                                serviceItemRepository.save(s);
                            },
                            () -> log.debug("زیردسته iTop بدون نگاشت محلی: {}", name)
                        );
                });
            }

        } catch (Exception e) {
            log.error("خطا در همگام‌سازی کاتالوگ خدمات: {}", e.getMessage());
        }
    }

    /**
     * همگام‌سازی SLA/OLA از iTop
     */
    @Transactional
    public void syncSlas() {
        try {
            JsonNode slaResult = iTopApiClient.getSLAs();
            if (slaResult.has("objects")) {
                slaResult.path("objects").fields().forEachRemaining(entry -> {
                    JsonNode obj = entry.getValue();
                    JsonNode fields = obj.path("fields");
                    Long itopId = obj.path("key").asLong();
                    String name = fields.path("name").asText("");

                    if (name.isBlank()) return;

                    slaRepository.findAll().stream()
                        .filter(s -> itopId.equals(s.getItopSlaId()))
                        .findFirst()
                        .ifPresentOrElse(
                            existing -> {
                                existing.setName(name);
                                slaRepository.save(existing);
                            },
                            () -> {
                                SlaDefinition newSla = SlaDefinition.builder()
                                    .name(name)
                                    .description(fields.path("description").asText(""))
                                    .slaType(SlaDefinition.SlaType.SLA)
                                    .itopSlaId(itopId)
                                    .isActive(true)
                                    .build();
                                slaRepository.save(newSla);
                            }
                        );
                });
                log.info("SLA‌ها از iTop همگام‌سازی شد");
            }
        } catch (Exception e) {
            log.error("خطا در همگام‌سازی SLA: {}", e.getMessage());
        }
    }

    /**
     * همگام‌سازی مراکز هزینه
     */
    @Transactional
    public void syncCostCenters() {
        try {
            JsonNode result = iTopApiClient.getCostCenters();
            if (result.has("objects")) {
                result.path("objects").fields().forEachRemaining(entry -> {
                    JsonNode obj = entry.getValue();
                    JsonNode fields = obj.path("fields");
                    Long itopId = obj.path("key").asLong();
                    String name = fields.path("name").asText("");

                    if (name.isBlank()) return;

                    costCenterRepository.findAll().stream()
                        .filter(c -> itopId.equals(c.getItopCostCenterId()))
                        .findFirst()
                        .ifPresentOrElse(
                            c -> {
                                c.setName(name);
                                costCenterRepository.save(c);
                            },
                            () -> {
                                String code = "CC-ITOP-" + itopId;
                                if (!costCenterRepository.findByCode(code).isPresent()) {
                                    CostCenter cc = CostCenter.builder()
                                        .code(code)
                                        .name(name)
                                        .itopCostCenterId(itopId)
                                        .annualBudget(BigDecimal.ZERO)
                                        .isActive(true)
                                        .build();
                                    costCenterRepository.save(cc);
                                }
                            }
                        );
                });
                log.info("مراکز هزینه از iTop همگام‌سازی شد");
            }
        } catch (Exception e) {
            log.error("خطا در همگام‌سازی مراکز هزینه: {}", e.getMessage());
        }
    }

    /**
     * همگام‌سازی وضعیت درخواست‌ها با iTop
     */
    @Transactional
    public void syncRequests() {
        try {
            JsonNode result = iTopApiClient.getUserRequests(null);
            if (!result.has("objects")) return;

            result.path("objects").fields().forEachRemaining(entry -> {
                JsonNode obj = entry.getValue();
                JsonNode fields = obj.path("fields");
                Long itopId = obj.path("key").asLong();

                requestRepository.findAll().stream()
                    .filter(r -> itopId.equals(r.getItopRequestId()))
                    .findFirst()
                    .ifPresent(req -> {
                        String itopStatus = fields.path("status").asText("");
                        ServiceRequest.RequestStatus newStatus = mapITopStatus(itopStatus);
                        if (newStatus != null && newStatus != req.getStatus()) {
                            req.setStatus(newStatus);
                            if (newStatus == ServiceRequest.RequestStatus.RESOLVED)
                                req.setResolvedAt(LocalDateTime.now());
                            requestRepository.save(req);
                            log.debug("وضعیت درخواست {} به {} تغییر یافت", req.getTicketNumber(), newStatus);
                        }
                    });
            });

            log.debug("درخواست‌ها از iTop همگام‌سازی شد");

        } catch (Exception e) {
            log.warn("خطا در همگام‌سازی درخواست‌ها: {}", e.getMessage());
        }
    }

    /**
     * تبدیل وضعیت iTop به enum داخلی
     */
    private ServiceRequest.RequestStatus mapITopStatus(String itopStatus) {
        return switch (itopStatus.toLowerCase()) {
            case "new"          -> ServiceRequest.RequestStatus.NEW;
            case "assigned"     -> ServiceRequest.RequestStatus.ASSIGNED;
            case "in_progress"  -> ServiceRequest.RequestStatus.IN_PROGRESS;
            case "waiting_for_approval", "pending" -> ServiceRequest.RequestStatus.PENDING;
            case "resolved"     -> ServiceRequest.RequestStatus.RESOLVED;
            case "closed"       -> ServiceRequest.RequestStatus.CLOSED;
            case "rejected"     -> ServiceRequest.RequestStatus.CANCELLED;
            default             -> null;
        };
    }

    public boolean isITopAvailable() { return iTopAvailable; }
    public LocalDateTime getLastSyncTime() { return lastSyncTime; }
}
