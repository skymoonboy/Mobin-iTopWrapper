package com.itopwrapper.audit;

import com.itopwrapper.model.entity.AuditLog;
import com.itopwrapper.repository.AuditLogRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

/**
 * سرویس ثبت لاگ سامانه
 * تمام رویدادها به صورت ناهمزمان در پایگاه داده ذخیره می‌شوند
 */
@Service
@Slf4j
@RequiredArgsConstructor
public class AuditService {

    private final AuditLogRepository auditLogRepository;

    @Async
    @Transactional(propagation = Propagation.REQUIRES_NEW)
    public void log(String action, String module, Long resourceId,
                    String username, String description, String ip, boolean success) {
        try {
            AuditLog auditLog = AuditLog.builder()
                .action(action)
                .module(module)
                .resourceId(resourceId)
                .username(username)
                .description(description)
                .ipAddress(ip)
                .success(success)
                .level(success ? AuditLog.LogLevel.INFO : AuditLog.LogLevel.WARN)
                .build();
            auditLogRepository.save(auditLog);
        } catch (Exception e) {
            log.error("خطا در ثبت لاگ: {}", e.getMessage());
        }
    }

    @Async
    @Transactional(propagation = Propagation.REQUIRES_NEW)
    public void logError(String action, String module, String username,
                         String description, String errorMessage, String ip) {
        try {
            AuditLog auditLog = AuditLog.builder()
                .action(action)
                .module(module)
                .username(username)
                .description(description)
                .errorMessage(errorMessage)
                .ipAddress(ip)
                .success(false)
                .level(AuditLog.LogLevel.ERROR)
                .build();
            auditLogRepository.save(auditLog);
        } catch (Exception e) {
            log.error("خطا در ثبت لاگ خطا: {}", e.getMessage());
        }
    }

    @Async
    @Transactional(propagation = Propagation.REQUIRES_NEW)
    public void logSecurity(String action, String username, String description, String ip) {
        try {
            AuditLog auditLog = AuditLog.builder()
                .action(action)
                .module("SECURITY")
                .username(username)
                .description(description)
                .ipAddress(ip)
                .success(false)
                .level(AuditLog.LogLevel.SECURITY)
                .build();
            auditLogRepository.save(auditLog);
        } catch (Exception e) {
            log.error("خطا در ثبت لاگ امنیتی: {}", e.getMessage());
        }
    }
}
