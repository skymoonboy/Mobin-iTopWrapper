package com.itopwrapper.controller.portal;

import com.itopwrapper.audit.AuditService;
import com.itopwrapper.model.entity.User;
import com.itopwrapper.repository.UserRepository;
import jakarta.servlet.http.HttpServletRequest;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.web.bind.annotation.*;

import java.util.Map;

/**
 * REST API پروفایل کاربری — پرتال مشتریان
 */
@RestController
@RequestMapping("/api/portal/profile")
@RequiredArgsConstructor
@Slf4j
public class PortalProfileApiController {

    private final UserRepository userRepository;
    private final PasswordEncoder passwordEncoder;
    private final AuditService auditService;

    /**
     * دریافت اطلاعات پروفایل کاربر جاری
     */
    @GetMapping
    public ResponseEntity<User> getProfile(@AuthenticationPrincipal UserDetails userDetails) {
        return userRepository.findByUsername(userDetails.getUsername())
            .map(u -> {
                // رمز عبور را بر نمی‌گردانیم
                u.setPasswordHash(null);
                return ResponseEntity.ok(u);
            })
            .orElse(ResponseEntity.notFound().build());
    }

    /**
     * ویرایش پروفایل کاربر جاری
     */
    @PutMapping
    public ResponseEntity<?> updateProfile(
            @RequestBody Map<String, String> fields,
            @AuthenticationPrincipal UserDetails userDetails,
            HttpServletRequest request) {

        return userRepository.findByUsername(userDetails.getUsername()).map(user -> {
            String oldEmail = user.getEmail();

            if (fields.containsKey("firstName"))    user.setFirstName(fields.get("firstName"));
            if (fields.containsKey("lastName"))     user.setLastName(fields.get("lastName"));
            if (fields.containsKey("phone"))        user.setPhone(fields.get("phone"));
            if (fields.containsKey("organization")) user.setOrganization(fields.get("organization"));

            // تغییر ایمیل — بررسی تکراری نبودن
            String newEmail = fields.get("email");
            if (newEmail != null && !newEmail.isBlank() && !newEmail.equals(oldEmail)) {
                if (userRepository.existsByEmail(newEmail)) {
                    return ResponseEntity.badRequest().body("این ایمیل قبلاً استفاده شده است");
                }
                user.setEmail(newEmail);
            }

            userRepository.save(user);
            auditService.log("PROFILE_UPDATE", "USER_PROFILE", user.getId(),
                userDetails.getUsername(), "ویرایش پروفایل", request.getRemoteAddr(), true);

            user.setPasswordHash(null);
            return ResponseEntity.ok(user);
        }).orElse(ResponseEntity.notFound().build());
    }

    /**
     * تغییر رمز عبور توسط کاربر
     */
    @PostMapping("/change-password")
    public ResponseEntity<String> changePassword(
            @RequestBody Map<String, String> body,
            @AuthenticationPrincipal UserDetails userDetails,
            HttpServletRequest request) {

        String currentPw = body.get("currentPassword");
        String newPw     = body.get("newPassword");

        if (currentPw == null || newPw == null) {
            return ResponseEntity.badRequest().body("رمز عبور فعلی و جدید الزامی است");
        }
        if (newPw.length() < 8) {
            return ResponseEntity.badRequest().body("رمز عبور جدید باید حداقل ۸ کاراکتر باشد");
        }

        return userRepository.findByUsername(userDetails.getUsername()).map(user -> {
            // بررسی رمز عبور فعلی
            if (user.getPasswordHash() == null ||
                !passwordEncoder.matches(currentPw, user.getPasswordHash())) {
                auditService.log("PASSWORD_CHANGE_FAILED", "USER_PROFILE", user.getId(),
                    userDetails.getUsername(), "رمز عبور فعلی اشتباه است",
                    request.getRemoteAddr(), false);
                return ResponseEntity.status(401).body("رمز عبور فعلی اشتباه است");
            }

            user.setPasswordHash(passwordEncoder.encode(newPw));
            user.setPasswordChangedAt(java.time.LocalDateTime.now());
            userRepository.save(user);

            auditService.log("PASSWORD_CHANGE", "USER_PROFILE", user.getId(),
                userDetails.getUsername(), "تغییر موفق رمز عبور",
                request.getRemoteAddr(), true);

            return ResponseEntity.ok("رمز عبور با موفقیت تغییر یافت");
        }).orElse(ResponseEntity.notFound().build());
    }
}
