package com.itopwrapper.controller;

import com.itopwrapper.audit.AuditService;
import com.itopwrapper.model.dto.AuthRequest;
import com.itopwrapper.model.dto.AuthResponse;
import com.itopwrapper.security.jwt.JwtTokenProvider;
import com.itopwrapper.security.ldap.LdapAuthResult;
import com.itopwrapper.security.ldap.MultiLdapAuthService;
import com.itopwrapper.service.UserService;
import jakarta.servlet.http.Cookie;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.ResponseEntity;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.AuthenticationException;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.web.bind.annotation.*;

/**
 * کنترلر REST احراز هویت
 * پشتیبانی از JWT، LDAP و Multi-LDAP
 */
@RestController
@RequestMapping("/api/auth")
@RequiredArgsConstructor
@Slf4j
public class AuthController {

    private final AuthenticationManager authManager;
    private final JwtTokenProvider jwtProvider;
    private final MultiLdapAuthService ldapAuthService;
    private final UserService userService;
    private final AuditService auditService;

    /**
     * ورود با نام کاربری و رمز عبور (محلی یا LDAP)
     */
    @PostMapping("/login")
    public ResponseEntity<AuthResponse> login(@Valid @RequestBody AuthRequest request,
                                               HttpServletRequest httpRequest,
                                               HttpServletResponse httpResponse) {
        String ip = getClientIp(httpRequest);

        // ابتدا LDAP را بررسی می‌کنیم
        if ("LDAP".equals(request.getAuthType())) {
            return handleLdapLogin(request, ip, httpResponse);
        }

        // احراز هویت محلی
        try {
            Authentication auth = authManager.authenticate(
                new UsernamePasswordAuthenticationToken(request.getUsername(), request.getPassword())
            );

            String token = jwtProvider.generateToken(auth);
            String refreshToken = jwtProvider.generateRefreshToken(request.getUsername());

            // ذخیره توکن در کوکی برای پرتال وب
            setJwtCookie(httpResponse, token);

            auditService.log("LOGIN", "AUTH", null, request.getUsername(),
                "ورود موفق", ip, true);

            UserDetails user = (UserDetails) auth.getPrincipal();
            return ResponseEntity.ok(AuthResponse.builder()
                .token(token)
                .refreshToken(refreshToken)
                .username(request.getUsername())
                .roles(user.getAuthorities().stream()
                    .map(a -> a.getAuthority()).toList())
                .expiresIn(jwtProvider.getExpiration())
                .message("ورود موفقیت‌آمیز")
                .build());

        } catch (AuthenticationException e) {
            auditService.log("LOGIN_FAILED", "AUTH", null, request.getUsername(),
                "ورود ناموفق: " + e.getMessage(), ip, false);
            return ResponseEntity.status(401).body(
                AuthResponse.builder().message("نام کاربری یا رمز عبور اشتباه است").build());
        }
    }

    /**
     * ورود از طریق LDAP
     */
    private ResponseEntity<AuthResponse> handleLdapLogin(AuthRequest request, String ip,
                                                          HttpServletResponse response) {
        LdapAuthResult result = ldapAuthService.authenticate(request.getUsername(), request.getPassword());

        if (!result.isSuccess()) {
            auditService.log("LOGIN_FAILED", "LDAP", null, request.getUsername(),
                result.getErrorMessage(), ip, false);
            return ResponseEntity.status(401).body(
                AuthResponse.builder().message(result.getErrorMessage()).build());
        }

        // ایجاد یا بروزرسانی کاربر در پایگاه داده
        var user = userService.findOrCreateLdapUser(request.getUsername(), result);
        String token = jwtProvider.generateTokenFromUsername(
            user.getUsername(),
            user.getRoles().stream().map(r -> r.getName()).reduce("", (a, b) -> a + "," + b)
        );

        setJwtCookie(response, token);
        auditService.log("LOGIN", "LDAP", null, request.getUsername(),
            "ورود LDAP موفق از سرور: " + result.getProviderId(), ip, true);

        return ResponseEntity.ok(AuthResponse.builder()
            .token(token)
            .username(request.getUsername())
            .message("ورود موفقیت‌آمیز از طریق LDAP")
            .build());
    }

    /**
     * تجدید توکن
     */
    @PostMapping("/refresh")
    public ResponseEntity<AuthResponse> refreshToken(@RequestParam String refreshToken) {
        if (!jwtProvider.validateToken(refreshToken)) {
            return ResponseEntity.status(401).body(
                AuthResponse.builder().message("توکن تجدید نامعتبر است").build());
        }
        String username = jwtProvider.getUsernameFromToken(refreshToken);
        var userDetails = userService.loadUserByUsername(username);
        String newToken = jwtProvider.generateTokenFromUsername(username,
            userDetails.getAuthorities().stream()
                .map(a -> a.getAuthority()).reduce("", (a, b) -> a + "," + b));

        return ResponseEntity.ok(AuthResponse.builder()
            .token(newToken)
            .username(username)
            .expiresIn(jwtProvider.getExpiration())
            .message("توکن تجدید شد")
            .build());
    }

    /**
     * خروج از سامانه
     */
    @PostMapping("/logout")
    public ResponseEntity<Void> logout(HttpServletResponse response) {
        Cookie cookie = new Cookie("JWT_TOKEN", null);
        cookie.setMaxAge(0);
        cookie.setPath("/");
        response.addCookie(cookie);
        return ResponseEntity.ok().build();
    }

    private void setJwtCookie(HttpServletResponse response, String token) {
        Cookie cookie = new Cookie("JWT_TOKEN", token);
        cookie.setHttpOnly(true);
        cookie.setSecure(false); // در production باید true باشد
        cookie.setPath("/");
        cookie.setMaxAge((int) (jwtProvider.getExpiration() / 1000));
        response.addCookie(cookie);
    }

    private String getClientIp(HttpServletRequest request) {
        String ip = request.getHeader("X-Forwarded-For");
        if (ip == null || ip.isEmpty()) ip = request.getRemoteAddr();
        return ip;
    }
}
