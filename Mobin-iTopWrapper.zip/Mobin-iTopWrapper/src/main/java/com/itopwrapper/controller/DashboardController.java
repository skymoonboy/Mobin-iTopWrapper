package com.itopwrapper.controller;

import org.springframework.security.core.Authentication;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;

/**
 * کنترلر مسیرهای اصلی — مدیریت ریدایرکت بر اساس نقش کاربر
 */
@Controller
public class DashboardController {

    /**
     * ریدایرکت ریشه بر اساس نقش
     */
    @GetMapping("/")
    public String root(Authentication auth) {
        return redirectByRole(auth);
    }

    /**
     * مسیر /dashboard — ریدایرکت هوشمند
     */
    @GetMapping("/dashboard")
    public String dashboard(Authentication auth) {
        return redirectByRole(auth);
    }

    /**
     * صفحه ورود را نشان می‌دهد (Thymeleaf)
     */
    @GetMapping("/login")
    public String loginPage() {
        return "login";
    }

    /**
     * صفحه خطای دسترسی
     */
    @GetMapping("/access-denied")
    public String accessDenied() {
        return "error/access-denied";
    }

    /**
     * تعیین مسیر بر اساس نقش کاربر
     */
    private String redirectByRole(Authentication auth) {
        if (auth == null || !auth.isAuthenticated()) {
            return "redirect:/login";
        }

        boolean isAdmin = auth.getAuthorities().stream()
            .map(GrantedAuthority::getAuthority)
            .anyMatch(a -> a.equals("ROLE_SUPER_ADMIN") || a.equals("ROLE_ADMIN") || a.equals("ROLE_MANAGER"));

        return isAdmin
            ? "redirect:/admin/dashboard"
            : "redirect:/portal/dashboard";
    }
}
