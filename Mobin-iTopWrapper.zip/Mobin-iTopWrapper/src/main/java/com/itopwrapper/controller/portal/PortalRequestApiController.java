package com.itopwrapper.controller.portal;

import com.itopwrapper.model.entity.RequestComment;
import com.itopwrapper.model.entity.ServiceRequest;
import com.itopwrapper.model.entity.User;
import com.itopwrapper.pricing.PricingEngine;
import com.itopwrapper.repository.UserRepository;
import com.itopwrapper.service.impl.ServiceRequestService;
import com.itopwrapper.wallet.InsufficientBalanceException;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.data.domain.Page;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.Map;

/**
 * REST API پرتال مشتریان — مدیریت درخواست‌ها
 */
@RestController
@RequestMapping("/api/portal/requests")
@RequiredArgsConstructor
@Slf4j
public class PortalRequestApiController {

    private final ServiceRequestService requestService;
    private final UserRepository userRepository;

    /** لیست درخواست‌های کاربر جاری */
    @GetMapping
    public Page<ServiceRequest> myRequests(
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "10") int size,
            @AuthenticationPrincipal UserDetails userDetails) {

        User user = userRepository.findByUsername(userDetails.getUsername())
            .orElseThrow(() -> new RuntimeException("کاربر یافت نشد"));
        return requestService.getRequesterRequests(user.getId(), page, size);
    }

    /**
     * ثبت درخواست جدید — در صورت فعال‌بودن کیف‌پول برای خدمت انتخابی،
     * بسته به تنظیم خدمت، مبلغ به‌صورت فوری کسر یا Hold می‌شود.
     */
    @PostMapping
    public ResponseEntity<?> createRequest(
            @RequestParam String title,
            @RequestParam String description,
            @RequestParam(required = false) Long serviceItemId,
            @RequestParam(defaultValue = "MEDIUM") String priority,
            @RequestParam(defaultValue = "1") Integer months,
            @RequestParam(defaultValue = "1") Integer hours,
            @RequestParam(defaultValue = "1") Integer users,
            @RequestParam(defaultValue = "1") Integer quantity,
            @RequestParam(defaultValue = "BRONZE") String customerTier,
            @AuthenticationPrincipal UserDetails userDetails) {

        User user = userRepository.findByUsername(userDetails.getUsername())
            .orElseThrow(() -> new RuntimeException("کاربر یافت نشد"));

        Map<String, Object> pricingParams = new HashMap<>();
        pricingParams.put("months", months);
        pricingParams.put("hours", hours);
        pricingParams.put("users", users);
        pricingParams.put("quantity", quantity);

        try {
            ServiceRequest request = requestService.createRequest(
                user.getId(), serviceItemId, title, description,
                ServiceRequest.Priority.valueOf(priority.toUpperCase()),
                pricingParams, parseTier(customerTier)
            );
            return ResponseEntity.ok(request);
        } catch (InsufficientBalanceException e) {
            return ResponseEntity.status(402).body(Map.of(
                "error", "INSUFFICIENT_BALANCE",
                "message", e.getMessage(),
                "available", e.getAvailable(),
                "requested", e.getRequested(),
                "shortfall", e.getShortfall()
            ));
        }
    }

    private PricingEngine.CustomerTier parseTier(String tier) {
        try { return PricingEngine.CustomerTier.valueOf(tier.toUpperCase()); }
        catch (Exception e) { return PricingEngine.CustomerTier.BRONZE; }
    }

    /** جزئیات یک درخواست */
    @GetMapping("/{id}")
    public ResponseEntity<ServiceRequest> getById(@PathVariable Long id,
                                                   @AuthenticationPrincipal UserDetails userDetails) {
        // TODO: بررسی مالکیت درخواست
        return ResponseEntity.ok().build();
    }

    /** افزودن نظر */
    @PostMapping("/{id}/comments")
    public ResponseEntity<RequestComment> addComment(
            @PathVariable Long id,
            @RequestParam String content,
            @AuthenticationPrincipal UserDetails userDetails) {

        User user = userRepository.findByUsername(userDetails.getUsername())
            .orElseThrow(() -> new RuntimeException("کاربر یافت نشد"));

        RequestComment comment = requestService.addComment(
            id, user.getId(), content, RequestComment.CommentType.PUBLIC);
        return ResponseEntity.ok(comment);
    }

    /** امتیازدهی به خدمت پس از بسته‌شدن */
    @PostMapping("/{id}/satisfaction")
    public ResponseEntity<Map<String, String>> rateSatisfaction(
            @PathVariable Long id,
            @RequestParam int score,
            @RequestParam(required = false) String comment) {

        // TODO: ذخیره امتیاز رضایت
        return ResponseEntity.ok(Map.of("message", "امتیاز ثبت شد"));
    }

    /** آمار درخواست‌های کاربر */
    @GetMapping("/my-stats")
    public ResponseEntity<Map<String, Long>> myStats(@AuthenticationPrincipal UserDetails userDetails) {
        User user = userRepository.findByUsername(userDetails.getUsername())
            .orElseThrow(() -> new RuntimeException("کاربر یافت نشد"));
        // آمار ساده
        return ResponseEntity.ok(Map.of("total", 0L));
    }
}
