package com.itopwrapper.controller.admin;

import com.itopwrapper.model.entity.ServiceRequest;
import com.itopwrapper.repository.ServiceRequestRepository;
import com.itopwrapper.repository.UserRepository;
import com.itopwrapper.service.impl.ServiceRequestService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Sort;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

/**
 * کنترلر مدیریت درخواست‌های خدمت در پنل مدیریتی
 */
@Controller
@RequiredArgsConstructor
@Slf4j
@PreAuthorize("hasAnyRole('ADMIN','SUPER_ADMIN','MANAGER','OPERATOR')")
public class AdminRequestsController {

    private final ServiceRequestRepository requestRepository;
    private final ServiceRequestService requestService;
    private final UserRepository userRepository;

    // ===== صفحه HTML =====

    @GetMapping("/admin/requests")
    public String requestsPage(Model model) {
        model.addAttribute("pageTitle", "مدیریت درخواست‌ها");
        model.addAttribute("totalRequests",   requestRepository.count());
        model.addAttribute("newRequests",     requestRepository.countByStatus(ServiceRequest.RequestStatus.NEW));
        model.addAttribute("openRequests",    requestRepository.countByStatus(ServiceRequest.RequestStatus.IN_PROGRESS)
                + requestRepository.countByStatus(ServiceRequest.RequestStatus.ASSIGNED));
        model.addAttribute("resolvedRequests",requestRepository.countByStatus(ServiceRequest.RequestStatus.RESOLVED));
        model.addAttribute("breachedSla",     requestRepository.findBreachedSla(java.time.LocalDateTime.now()).size());
        return "admin/requests";
    }

    // ===== REST API =====

    @GetMapping("/api/admin/requests")
    @ResponseBody
    public Page<ServiceRequest> getAllRequests(
            @RequestParam(defaultValue = "0")   int page,
            @RequestParam(defaultValue = "20")  int size,
            @RequestParam(required = false)     String status,
            @RequestParam(required = false)     String priority) {

        PageRequest pageable = PageRequest.of(page, size, Sort.by(Sort.Direction.DESC, "createdAt"));

        if (status != null && !status.isBlank()) {
            try {
                ServiceRequest.RequestStatus s = ServiceRequest.RequestStatus.valueOf(status.toUpperCase());
                return requestRepository.findByStatus(s, pageable);
            } catch (IllegalArgumentException ignored) {}
        }
        return requestRepository.findAll(pageable);
    }

    @GetMapping("/api/admin/requests/{id}")
    @ResponseBody
    public ResponseEntity<ServiceRequest> getRequest(@PathVariable Long id) {
        return requestRepository.findById(id)
            .map(ResponseEntity::ok)
            .orElse(ResponseEntity.notFound().build());
    }

    @PatchMapping("/api/admin/requests/{id}/status")
    @ResponseBody
    public ResponseEntity<?> updateStatus(
            @PathVariable Long id,
            @RequestParam String status,
            @RequestParam(required = false) String comment,
            @AuthenticationPrincipal UserDetails user) {
        try {
            ServiceRequest.RequestStatus newStatus = ServiceRequest.RequestStatus.valueOf(status.toUpperCase());
            ServiceRequest req = requestService.updateStatus(id, newStatus, comment, user.getUsername());
            return ResponseEntity.ok(req);
        } catch (IllegalArgumentException e) {
            return ResponseEntity.badRequest().body("وضعیت نامعتبر: " + status);
        }
    }

    @PatchMapping("/api/admin/requests/{id}/assign")
    @ResponseBody
    public ResponseEntity<?> assignRequest(
            @PathVariable Long id,
            @RequestParam Long assigneeId,
            @AuthenticationPrincipal UserDetails user) {
        ServiceRequest req = requestService.assignRequest(id, assigneeId, user.getUsername());
        return ResponseEntity.ok(req);
    }

    @PostMapping("/api/admin/requests/{id}/comments")
    @ResponseBody
    public ResponseEntity<?> addComment(
            @PathVariable Long id,
            @RequestParam String content,
            @RequestParam(defaultValue = "PRIVATE") String commentType,
            @AuthenticationPrincipal UserDetails user) {
        return userRepository.findByUsername(user.getUsername()).map(u -> {
            var type = parseCommentType(commentType);
            var comment = requestService.addComment(id, u.getId(), content, type);
            return ResponseEntity.ok(comment);
        }).orElse(ResponseEntity.badRequest().build());
    }

    @GetMapping("/api/admin/requests/stats")
    @ResponseBody
    public Map<String, Object> getStats() {
        return requestService.getRequestStats();
    }

    @GetMapping("/api/admin/requests/breached-sla")
    @ResponseBody
    public List<ServiceRequest> getBreachedSla() {
        return requestRepository.findBreachedSla(java.time.LocalDateTime.now());
    }

    private com.itopwrapper.model.entity.RequestComment.CommentType parseCommentType(String s) {
        try { return com.itopwrapper.model.entity.RequestComment.CommentType.valueOf(s.toUpperCase()); }
        catch (Exception e) { return com.itopwrapper.model.entity.RequestComment.CommentType.PRIVATE; }
    }
}
