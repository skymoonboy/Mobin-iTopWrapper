package com.itopwrapper.controller.admin;

import com.itopwrapper.model.entity.ModuleInfo;
import com.itopwrapper.module.ModuleException;
import com.itopwrapper.module.ModuleManager;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.util.List;

/**
 * REST API مدیریت ماژول‌ها
 */
@RestController
@RequestMapping("/api/admin/modules")
@RequiredArgsConstructor
@Slf4j
@PreAuthorize("hasRole('SUPER_ADMIN')")
public class ModuleApiController {

    private final ModuleManager moduleManager;

    @GetMapping
    public List<ModuleInfo> getModules() {
        return moduleManager.getInstalledModules();
    }

    @PostMapping("/install")
    public ResponseEntity<?> installModule(@RequestParam("file") MultipartFile file,
                                            @AuthenticationPrincipal UserDetails user) {
        try {
            ModuleInfo module = moduleManager.installModule(file, user.getUsername());
            return ResponseEntity.ok(module);
        } catch (ModuleException e) {
            return ResponseEntity.badRequest().body(e.getMessage());
        }
    }

    @PostMapping("/{moduleId}/activate")
    public ResponseEntity<?> activateModule(@PathVariable String moduleId) {
        try {
            moduleManager.activateModule(moduleId);
            return ResponseEntity.ok("ماژول فعال شد");
        } catch (ModuleException e) {
            return ResponseEntity.badRequest().body(e.getMessage());
        }
    }

    @PostMapping("/{moduleId}/deactivate")
    public ResponseEntity<?> deactivateModule(@PathVariable String moduleId) {
        try {
            moduleManager.deactivateModule(moduleId);
            return ResponseEntity.ok("ماژول غیرفعال شد");
        } catch (ModuleException e) {
            return ResponseEntity.badRequest().body(e.getMessage());
        }
    }

    @DeleteMapping("/{moduleId}")
    public ResponseEntity<?> removeModule(@PathVariable String moduleId) {
        try {
            moduleManager.removeModule(moduleId);
            return ResponseEntity.ok("ماژول حذف شد");
        } catch (ModuleException e) {
            return ResponseEntity.badRequest().body(e.getMessage());
        }
    }
}
