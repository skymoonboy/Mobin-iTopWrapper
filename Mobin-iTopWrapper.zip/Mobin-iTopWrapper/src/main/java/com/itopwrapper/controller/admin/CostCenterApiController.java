package com.itopwrapper.controller.admin;

import com.itopwrapper.model.entity.CostCenter;
import com.itopwrapper.service.impl.CostCenterService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.web.bind.annotation.*;

import java.math.BigDecimal;
import java.util.List;
import java.util.Map;

/**
 * REST API مدیریت مراکز هزینه
 */
@RestController
@RequestMapping("/api/admin/cost-centers")
@RequiredArgsConstructor
@PreAuthorize("hasAnyRole('ADMIN','SUPER_ADMIN','MANAGER')")
public class CostCenterApiController {

    private final CostCenterService costCenterService;

    @GetMapping
    public List<CostCenter> getAll() {
        return costCenterService.getAllActive();
    }

    @GetMapping("/roots")
    public List<CostCenter> getRoots() {
        return costCenterService.getRootCostCenters();
    }

    @GetMapping("/summary")
    public Map<String, Object> getSummary() {
        return costCenterService.getBudgetSummary();
    }

    @GetMapping("/{id}")
    public ResponseEntity<CostCenter> getById(@PathVariable Long id) {
        return costCenterService.getById(id)
            .map(ResponseEntity::ok)
            .orElse(ResponseEntity.notFound().build());
    }

    @PostMapping
    public ResponseEntity<CostCenter> create(@RequestBody CostCenter cc,
                                              @AuthenticationPrincipal UserDetails user) {
        return ResponseEntity.ok(costCenterService.save(cc, user.getUsername()));
    }

    @PutMapping("/{id}")
    public ResponseEntity<CostCenter> update(@PathVariable Long id,
                                              @RequestBody CostCenter cc,
                                              @AuthenticationPrincipal UserDetails user) {
        cc.setId(id);
        return ResponseEntity.ok(costCenterService.save(cc, user.getUsername()));
    }

    @PostMapping("/{id}/expense")
    public ResponseEntity<CostCenter> recordExpense(@PathVariable Long id,
                                                     @RequestParam BigDecimal amount,
                                                     @RequestParam String description,
                                                     @AuthenticationPrincipal UserDetails user) {
        return ResponseEntity.ok(
            costCenterService.recordExpense(id, amount, description, user.getUsername()));
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> delete(@PathVariable Long id,
                                        @AuthenticationPrincipal UserDetails user) {
        costCenterService.delete(id, user.getUsername());
        return ResponseEntity.ok().build();
    }
}
