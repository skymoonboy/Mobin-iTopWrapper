package com.itopwrapper.controller.portal;

import com.itopwrapper.itop.ITopApiClient;
import com.itopwrapper.model.entity.ServiceItem;
import com.itopwrapper.pricing.PricingEngine;
import com.itopwrapper.pricing.PricingResult;
import com.itopwrapper.repository.ServiceCategoryRepository;
import com.itopwrapper.repository.ServiceItemRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.util.Map;

/**
 * کنترلر پرتال مشتریان
 * پنجره واحد ارائه خدمات فناوری اطلاعات
 */
@Controller
@RequestMapping("/portal")
@RequiredArgsConstructor
@Slf4j
public class PortalController {

    private final ServiceCategoryRepository categoryRepository;
    private final ServiceItemRepository serviceItemRepository;
    private final PricingEngine pricingEngine;
    private final ITopApiClient iTopApiClient;

    /**
     * صفحه اصلی پرتال - پنجره واحد خدمات
     */
    @GetMapping({"", "/", "/home"})
    public String portalHome(Model model, @AuthenticationPrincipal UserDetails userDetails) {
        model.addAttribute("categories", categoryRepository.findByParentIsNullAndIsActiveTrue());
        model.addAttribute("featuredServices", serviceItemRepository.findByIsFeaturedTrueAndIsActiveTrue());
        model.addAttribute("username", userDetails.getUsername());
        model.addAttribute("pageTitle", "پنجره واحد خدمات فناوری اطلاعات");
        return "portal/home";
    }

    /**
     * کاتالوگ خدمات
     */
    @GetMapping("/catalog")
    public String serviceCatalog(Model model,
                                  @RequestParam(required = false) Long categoryId) {
        model.addAttribute("categories", categoryRepository.findByParentIsNullAndIsActiveTrue());

        if (categoryId != null) {
            var category = categoryRepository.findById(categoryId);
            category.ifPresent(c -> {
                model.addAttribute("selectedCategory", c);
                model.addAttribute("services", serviceItemRepository.findByCategoryAndIsActiveTrue(c));
                model.addAttribute("subCategories", categoryRepository.findByParentAndIsActiveTrue(c));
            });
        } else {
            model.addAttribute("services", serviceItemRepository.findByIsActiveTrue());
        }

        model.addAttribute("pageTitle", "کاتالوگ خدمات");
        return "portal/catalog";
    }

    /**
     * جزئیات خدمت و محاسبه قیمت
     */
    @GetMapping("/service/{id}")
    public String serviceDetail(@PathVariable Long id, Model model) {
        var service = serviceItemRepository.findById(id)
            .orElseThrow(() -> new RuntimeException("خدمت یافت نشد"));

        // محاسبه قیمت پیش‌فرض
        PricingResult price = pricingEngine.calculatePrice(
            service, Map.of("months", 1), PricingEngine.CustomerTier.BRONZE);

        model.addAttribute("service", service);
        model.addAttribute("pricing", price);
        model.addAttribute("pageTitle", service.getName());
        return "portal/service-detail";
    }

    /**
     * محاسبه قیمت پویا
     */
    @PostMapping("/service/{id}/calculate-price")
    @ResponseBody
    public PricingResult calculatePrice(@PathVariable Long id,
                                         @RequestParam Map<String, Object> params,
                                         @RequestParam(defaultValue = "BRONZE") String tier) {
        var service = serviceItemRepository.findById(id)
            .orElseThrow(() -> new RuntimeException("خدمت یافت نشد"));
        PricingEngine.CustomerTier customerTier = PricingEngine.CustomerTier.valueOf(tier.toUpperCase());
        return pricingEngine.calculatePrice(service, params, customerTier);
    }

    /**
     * درخواست‌های من
     */
    @GetMapping("/requests")
    public String myRequests(Model model, @AuthenticationPrincipal UserDetails userDetails) {
        try {
            var requests = iTopApiClient.getUserRequests(null);
            model.addAttribute("requests", requests);
        } catch (Exception e) {
            log.error("خطا در دریافت درخواست‌ها", e);
            model.addAttribute("error", "خطا در دریافت درخواست‌ها");
        }
        model.addAttribute("pageTitle", "درخواست‌های من");
        return "portal/requests";
    }

    /**
     * ثبت درخواست جدید
     */
    @GetMapping("/requests/new")
    public String newRequest(Model model) {
        model.addAttribute("categories", categoryRepository.findByParentIsNullAndIsActiveTrue());
        model.addAttribute("pageTitle", "ثبت درخواست جدید");
        return "portal/new-request";
    }

    /**
     * پروفایل کاربری
     */
    @GetMapping("/profile")
    public String profile(Model model, @AuthenticationPrincipal UserDetails userDetails) {
        model.addAttribute("pageTitle", "پروفایل کاربری");
        model.addAttribute("username", userDetails.getUsername());
        return "portal/profile";
    }

    /**
     * داشبورد پرتال
     */
    @GetMapping("/dashboard")
    public String dashboard(Model model, @AuthenticationPrincipal UserDetails userDetails) {
        try {
            var requests = iTopApiClient.getUserRequests(null);
            model.addAttribute("requests", requests);
        } catch (Exception e) {
            log.warn("خطا در دریافت درخواست‌ها برای داشبورد");
        }
        model.addAttribute("featuredServices", serviceItemRepository.findByIsFeaturedTrueAndIsActiveTrue());
        model.addAttribute("pageTitle", "داشبورد کاربری");
        return "portal/dashboard";
    }

    /**
     * کیف‌پول من
     */
    @GetMapping("/wallet")
    public String wallet(Model model) {
        model.addAttribute("pageTitle", "کیف‌پول من");
        return "portal/wallet";
    }
}
