package com.itopwrapper.controller.admin;

import com.itopwrapper.model.entity.SlaDefinition;
import com.itopwrapper.service.impl.SlaService;
import jakarta.servlet.http.HttpServletRequest;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

/**
 * REST API مدیریت SLA و OLA
 */
@RestController
@RequestMapping("/api/admin/sla")
@RequiredArgsConstructor
@PreAuthorize("hasAnyRole('ADMIN','SUPER_ADMIN','MANAGER')")
public class SlaApiController {

    private final SlaService slaService;

    @GetMapping
    public List<SlaDefinition> getAll() {
        return slaService.getActiveSlas();
    }

    @GetMapping("/ola")
    public List<SlaDefinition> getAllOla() {
        return slaService.getActiveOlas();
    }

    @PostMapping
    public ResponseEntity<SlaDefinition> create(@RequestBody SlaDefinition sla,
                                                 @AuthenticationPrincipal UserDetails user) {
        return ResponseEntity.ok(slaService.save(sla));
    }

    @PutMapping("/{id}")
    public ResponseEntity<SlaDefinition> update(@PathVariable Long id,
                                                 @RequestBody SlaDefinition sla,
                                                 @AuthenticationPrincipal UserDetails user) {
        sla.setId(id);
        return ResponseEntity.ok(slaService.save(sla));
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> delete(@PathVariable Long id) {
        slaService.delete(id);
        return ResponseEntity.ok().build();
    }

    @PostMapping("/sync-itop")
    public ResponseEntity<Map<String, String>> syncWithITop() {
        slaService.syncWithITop();
        return ResponseEntity.ok(Map.of("message", "همگام‌سازی با iTop آغاز شد"));
    }
}
