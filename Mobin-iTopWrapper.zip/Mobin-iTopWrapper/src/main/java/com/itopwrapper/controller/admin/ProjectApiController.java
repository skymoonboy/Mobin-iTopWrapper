package com.itopwrapper.controller.admin;

import com.itopwrapper.model.entity.Project;
import com.itopwrapper.model.entity.ProjectTask;
import com.itopwrapper.service.impl.ProjectService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

/**
 * REST API مدیریت پروژه‌ها و گانت چارت
 */
@RestController
@RequestMapping("/api/admin/projects")
@RequiredArgsConstructor
@PreAuthorize("hasAnyRole('ADMIN','SUPER_ADMIN','MANAGER')")
public class ProjectApiController {

    private final ProjectService projectService;

    @GetMapping
    public List<Project> getAll() {
        return projectService.getAllProjects();
    }

    @GetMapping("/{id}")
    public ResponseEntity<Project> getById(@PathVariable Long id) {
        return projectService.getById(id)
            .map(ResponseEntity::ok)
            .orElse(ResponseEntity.notFound().build());
    }

    @PostMapping
    public ResponseEntity<Project> create(@RequestBody Project project,
                                           @AuthenticationPrincipal UserDetails user) {
        return ResponseEntity.ok(projectService.createProject(project, user.getUsername()));
    }

    @PutMapping("/{id}")
    public ResponseEntity<Project> update(@PathVariable Long id,
                                           @RequestBody Project project,
                                           @AuthenticationPrincipal UserDetails user) {
        return ResponseEntity.ok(projectService.updateProject(id, project, user.getUsername()));
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> delete(@PathVariable Long id,
                                        @AuthenticationPrincipal UserDetails user) {
        projectService.deleteProject(id, user.getUsername());
        return ResponseEntity.ok().build();
    }

    /** دریافت داده گانت چارت */
    @GetMapping("/{id}/gantt")
    public ResponseEntity<List<Map<String, Object>>> getGanttData(@PathVariable Long id) {
        return ResponseEntity.ok(projectService.buildGanttData(id));
    }

    /** افزودن وظیفه */
    @PostMapping("/{id}/tasks")
    public ResponseEntity<ProjectTask> addTask(@PathVariable Long id,
                                                @RequestBody ProjectTask task,
                                                @AuthenticationPrincipal UserDetails user) {
        return ResponseEntity.ok(projectService.addTask(id, task, user.getUsername()));
    }

    /** بروزرسانی پیشرفت وظیفه */
    @PatchMapping("/{projectId}/tasks/{taskId}/progress")
    public ResponseEntity<ProjectTask> updateProgress(@PathVariable Long projectId,
                                                       @PathVariable Long taskId,
                                                       @RequestParam int percent,
                                                       @AuthenticationPrincipal UserDetails user) {
        return ResponseEntity.ok(
            projectService.updateTaskProgress(projectId, taskId, percent, user.getUsername()));
    }

    /** آمار پروژه‌ها */
    @GetMapping("/stats")
    public Map<String, Object> getStats() {
        return projectService.getProjectStats();
    }
}
