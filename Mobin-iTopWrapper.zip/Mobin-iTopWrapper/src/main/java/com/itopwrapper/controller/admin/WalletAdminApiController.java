package com.itopwrapper.controller.admin;

import com.itopwrapper.model.dto.WalletSummaryDto;
import com.itopwrapper.model.dto.WalletTransactionDto;
import com.itopwrapper.model.entity.User;
import com.itopwrapper.model.entity.Wallet;
import com.itopwrapper.model.entity.WalletTransaction;
import com.itopwrapper.repository.UserRepository;
import com.itopwrapper.repository.WalletRepository;
import com.itopwrapper.wallet.WalletException;
import com.itopwrapper.wallet.WalletService;
import jakarta.servlet.http.HttpServletRequest;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Sort;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.*;

import java.math.BigDecimal;
import java.util.List;
import java.util.Map;

/**
 * REST API مدیریت کیف‌پول مشتریان — قابل استفاده توسط سوپرادمین و ادمین محلی.
 * شامل شارژ/کسر دستی اعتبار، تنظیم سقف اعتباری، فعال/غیرفعال‌سازی، و گزارش گردش حساب.
 */
@RestController
@RequestMapping("/api/admin/wallets")
@RequiredArgsConstructor
@PreAuthorize("hasAnyRole('ADMIN','SUPER_ADMIN')")
public class WalletAdminApiController {

    private final WalletService walletService;
    private final WalletRepository walletRepository;
    private final UserRepository userRepository;

    /** لیست همه کیف‌پول‌ها با خلاصه وضعیت */
    @GetMapping
    @Transactional(readOnly = true)
    public List<WalletSummaryDto> getAllWallets() {
        return walletRepository.findAllWithUser().stream().map(this::toDto).toList();
    }

    /** جزئیات کیف‌پول یک کاربر مشخص */
    @GetMapping("/user/{userId}")
    public ResponseEntity<WalletSummaryDto> getByUser(@PathVariable Long userId) {
        Wallet wallet = walletService.getOrCreateWallet(userId);
        return ResponseEntity.ok(toDto(wallet));
    }

    /** شارژ اعتبار */
    @PostMapping("/top-up")
    public ResponseEntity<?> topUp(@RequestBody Map<String, Object> body,
                                    @AuthenticationPrincipal UserDetails admin,
                                    HttpServletRequest request) {
        try {
            Long userId = Long.valueOf(String.valueOf(body.get("userId")));
            BigDecimal amount = new BigDecimal(String.valueOf(body.get("amount")));
            String description = (String) body.getOrDefault("description", "شارژ کیف‌پول توسط ادمین");

            WalletTransaction tx = walletService.topUp(userId, amount, description,
                admin.getUsername(), request.getRemoteAddr());
            return ResponseEntity.ok(Map.of(
                "message", "کیف‌پول با موفقیت شارژ شد",
                "transactionId", tx.getId(),
                "newBalance", tx.getBalanceAfter()
            ));
        } catch (WalletException e) {
            return ResponseEntity.badRequest().body(Map.of("error", e.getMessage()));
        }
    }

    /** کسر دستی اعتبار */
    @PostMapping("/deduct")
    public ResponseEntity<?> deduct(@RequestBody Map<String, Object> body,
                                     @AuthenticationPrincipal UserDetails admin,
                                     HttpServletRequest request) {
        try {
            Long userId = Long.valueOf(String.valueOf(body.get("userId")));
            BigDecimal amount = new BigDecimal(String.valueOf(body.get("amount")));
            String description = (String) body.getOrDefault("description", "کسر دستی توسط ادمین");

            WalletTransaction tx = walletService.adminDeduct(userId, amount, description,
                admin.getUsername(), request.getRemoteAddr());
            return ResponseEntity.ok(Map.of(
                "message", "اعتبار با موفقیت کسر شد",
                "transactionId", tx.getId(),
                "newBalance", tx.getBalanceAfter()
            ));
        } catch (WalletException e) {
            return ResponseEntity.badRequest().body(Map.of("error", e.getMessage()));
        }
    }

    /** تنظیم سقف اعتباری (مشتری می‌تواند تا این مقدار منفی برود) */
    @PostMapping("/credit-limit")
    public ResponseEntity<?> setCreditLimit(@RequestBody Map<String, Object> body,
                                             @AuthenticationPrincipal UserDetails admin,
                                             HttpServletRequest request) {
        try {
            Long userId = Long.valueOf(String.valueOf(body.get("userId")));
            BigDecimal limit = new BigDecimal(String.valueOf(body.get("creditLimit")));
            Wallet wallet = walletService.setCreditLimit(userId, limit, admin.getUsername(), request.getRemoteAddr());
            return ResponseEntity.ok(toDto(wallet));
        } catch (WalletException e) {
            return ResponseEntity.badRequest().body(Map.of("error", e.getMessage()));
        }
    }

    /** فعال/غیرفعال‌سازی کیف‌پول */
    @PostMapping("/user/{userId}/toggle-active")
    public ResponseEntity<WalletSummaryDto> toggleActive(@PathVariable Long userId,
                                                           @RequestParam boolean active,
                                                           @AuthenticationPrincipal UserDetails admin,
                                                           HttpServletRequest request) {
        Wallet wallet = walletService.setActive(userId, active, admin.getUsername(), request.getRemoteAddr());
        return ResponseEntity.ok(toDto(wallet));
    }

    /** گردش‌حساب یک کاربر مشخص */
    @GetMapping("/user/{userId}/transactions")
    @Transactional(readOnly = true)
    public Page<WalletTransactionDto> getUserTransactions(
            @PathVariable Long userId,
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "20") int size) {
        return walletService.getHistory(userId, PageRequest.of(page, size, Sort.by(Sort.Direction.DESC, "createdAt")))
            .map(WalletTransactionDto::from);
    }

    /** گردش‌حساب کل سامانه (همه کاربران) — برای حسابرسی */
    @GetMapping("/transactions")
    @Transactional(readOnly = true)
    public Page<WalletTransactionDto> getAllTransactions(
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "50") int size) {
        return walletService.getAllTransactions(PageRequest.of(page, size, Sort.by(Sort.Direction.DESC, "createdAt")))
            .map(WalletTransactionDto::from);
    }

    /** لیست کیف‌پول‌هایی که موجودی کم دارند (برای هشدار) */
    @GetMapping("/low-balance")
    @Transactional(readOnly = true)
    public List<WalletSummaryDto> getLowBalanceWallets() {
        return walletService.getLowBalanceWallets().stream().map(this::toDto).toList();
    }

    private WalletSummaryDto toDto(Wallet w) {
        return WalletSummaryDto.builder()
            .walletId(w.getId())
            .userId(w.getUser().getId())
            .username(w.getUser().getUsername())
            .fullName(w.getUser().getFullName())
            .balance(w.getBalance())
            .heldAmount(w.getHeldAmount())
            .availableBalance(w.getAvailableBalance())
            .creditLimit(w.getCreditLimit())
            .maxWithdrawable(w.getMaxWithdrawable())
            .currency(w.getCurrency())
            .isActive(w.getIsActive())
            .isLowBalance(w.isLowBalance())
            .build();
    }
}
