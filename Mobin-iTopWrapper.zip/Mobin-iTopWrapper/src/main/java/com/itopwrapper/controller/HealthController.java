package com.itopwrapper.controller;

import com.itopwrapper.itop.ITopSyncService;
import com.itopwrapper.repository.AuditLogRepository;
import com.itopwrapper.repository.ServiceRequestRepository;
import com.itopwrapper.repository.UserRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.time.LocalDateTime;
import java.util.LinkedHashMap;
import java.util.Map;

/**
 * کنترلر وضعیت سامانه — برای مانیتورینگ و Healthcheck
 */
@RestController
@RequestMapping("/api/system")
@RequiredArgsConstructor
public class HealthController {

    private final ITopSyncService iTopSyncService;
    private final UserRepository userRepository;
    private final ServiceRequestRepository requestRepository;
    private final AuditLogRepository auditLogRepository;

    /**
     * وضعیت کلی سامانه
     */
    @GetMapping("/status")
    @PreAuthorize("hasAnyRole('ADMIN','SUPER_ADMIN')")
    public ResponseEntity<Map<String, Object>> systemStatus() {
        Map<String, Object> status = new LinkedHashMap<>();

        status.put("status", "UP");
        status.put("timestamp", LocalDateTime.now().toString());
        status.put("version", "1.0.0");

        // وضعیت موتور iTop
        Map<String, Object> itopStatus = new LinkedHashMap<>();
        itopStatus.put("connected", iTopSyncService.isITopAvailable());
        itopStatus.put("lastSync",  iTopSyncService.getLastSyncTime() != null
            ? iTopSyncService.getLastSyncTime().toString() : "هنوز همگام‌سازی نشده");
        status.put("itopEngine", itopStatus);

        // آمار پایگاه داده
        Map<String, Object> dbStats = new LinkedHashMap<>();
        dbStats.put("totalUsers",    userRepository.count());
        dbStats.put("activeUsers",   userRepository.countByIsActive(true));
        dbStats.put("totalRequests", requestRepository.count());
        dbStats.put("openRequests",  requestRepository.countByStatus(
            com.itopwrapper.model.entity.ServiceRequest.RequestStatus.IN_PROGRESS)
            + requestRepository.countByStatus(
            com.itopwrapper.model.entity.ServiceRequest.RequestStatus.NEW));
        dbStats.put("totalLogs", auditLogRepository.count());
        status.put("database", dbStats);

        // منابع JVM
        Runtime runtime = Runtime.getRuntime();
        Map<String, Object> jvm = new LinkedHashMap<>();
        jvm.put("heapUsedMB",  (runtime.totalMemory() - runtime.freeMemory()) / 1_048_576);
        jvm.put("heapMaxMB",    runtime.maxMemory() / 1_048_576);
        jvm.put("availableProcessors", runtime.availableProcessors());
        status.put("jvm", jvm);

        return ResponseEntity.ok(status);
    }

    /**
     * Healthcheck عمومی — بدون احراز هویت
     */
    @GetMapping("/health")
    public ResponseEntity<Map<String, String>> health() {
        return ResponseEntity.ok(Map.of(
            "status",    "UP",
            "service",   "iTop Wrapper",
            "timestamp", LocalDateTime.now().toString()
        ));
    }
}
