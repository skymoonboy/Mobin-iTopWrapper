package com.itopwrapper.controller.admin;

import com.itopwrapper.audit.AuditService;
import com.itopwrapper.model.entity.ServiceCategory;
import com.itopwrapper.model.entity.ServiceItem;
import com.itopwrapper.repository.ServiceCategoryRepository;
import com.itopwrapper.repository.ServiceItemRepository;
import jakarta.servlet.http.HttpServletRequest;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/**
 * REST API مدیریت کاتالوگ خدمات
 */
@RestController
@RequestMapping("/api/admin/service-categories")
@RequiredArgsConstructor
public class ServiceCatalogApiController {

    private final ServiceCategoryRepository categoryRepository;
    private final ServiceItemRepository serviceItemRepository;
    private final AuditService auditService;

    @GetMapping
    public List<ServiceCategory> getCategories() {
        return categoryRepository.findAll();
    }

    @GetMapping("/{id}")
    public ResponseEntity<ServiceCategory> getCategory(@PathVariable Long id) {
        return categoryRepository.findById(id)
            .map(ResponseEntity::ok)
            .orElse(ResponseEntity.notFound().build());
    }

    @PreAuthorize("hasAnyRole('ADMIN','SUPER_ADMIN')")
    @PostMapping
    public ResponseEntity<ServiceCategory> createCategory(@RequestBody ServiceCategory category,
                                                           @AuthenticationPrincipal UserDetails user,
                                                           HttpServletRequest request) {
        ServiceCategory saved = categoryRepository.save(category);
        auditService.log("SERVICE_CATEGORY_CREATE", "SERVICE_CATALOG", saved.getId(),
            user.getUsername(), "دسته خدمت جدید: " + category.getName(),
            request.getRemoteAddr(), true);
        return ResponseEntity.ok(saved);
    }

    @PreAuthorize("hasAnyRole('ADMIN','SUPER_ADMIN')")
    @PutMapping("/{id}")
    public ResponseEntity<ServiceCategory> updateCategory(@PathVariable Long id,
                                                           @RequestBody ServiceCategory updated,
                                                           @AuthenticationPrincipal UserDetails user,
                                                           HttpServletRequest request) {
        return categoryRepository.findById(id).map(cat -> {
            cat.setName(updated.getName());
            cat.setDescription(updated.getDescription());
            cat.setIconClass(updated.getIconClass());
            cat.setDisplayOrder(updated.getDisplayOrder());
            cat.setIsActive(updated.getIsActive());
            ServiceCategory saved = categoryRepository.save(cat);
            auditService.log("SERVICE_CATEGORY_UPDATE", "SERVICE_CATALOG", id,
                user.getUsername(), "بروزرسانی دسته: " + cat.getName(),
                request.getRemoteAddr(), true);
            return ResponseEntity.ok(saved);
        }).orElse(ResponseEntity.notFound().build());
    }

    @PreAuthorize("hasAnyRole('ADMIN','SUPER_ADMIN')")
    @DeleteMapping("/{id}")
    public ResponseEntity<?> deleteCategory(@PathVariable Long id,
                                             @AuthenticationPrincipal UserDetails user,
                                             HttpServletRequest request) {
        return categoryRepository.findById(id).map(cat -> {
            categoryRepository.delete(cat);
            auditService.log("SERVICE_CATEGORY_DELETE", "SERVICE_CATALOG", id,
                user.getUsername(), "حذف دسته: " + cat.getName(),
                request.getRemoteAddr(), true);
            return ResponseEntity.ok("دسته حذف شد");
        }).orElse(ResponseEntity.notFound().build());
    }

    // ===== آیتم‌های خدمت =====

    @GetMapping("/{categoryId}/services")
    public List<ServiceItem> getServices(@PathVariable Long categoryId) {
        return categoryRepository.findById(categoryId)
            .map(serviceItemRepository::findByCategoryAndIsActiveTrue)
            .orElse(List.of());
    }

    @PreAuthorize("hasAnyRole('ADMIN','SUPER_ADMIN')")
    @PostMapping("/{categoryId}/services")
    public ResponseEntity<?> createService(@PathVariable Long categoryId,
                                            @RequestBody ServiceItem service,
                                            @AuthenticationPrincipal UserDetails user,
                                            HttpServletRequest request) {
        return categoryRepository.findById(categoryId).map(cat -> {
            service.setCategory(cat);
            ServiceItem saved = serviceItemRepository.save(service);
            auditService.log("SERVICE_CREATE", "SERVICE_CATALOG", saved.getId(),
                user.getUsername(), "خدمت جدید: " + service.getName(),
                request.getRemoteAddr(), true);
            return ResponseEntity.ok(saved);
        }).orElse(ResponseEntity.notFound().build());
    }

    @PreAuthorize("hasAnyRole('ADMIN','SUPER_ADMIN')")
    @PutMapping("/services/{id}")
    public ResponseEntity<ServiceItem> updateService(@PathVariable Long id,
                                                      @RequestBody ServiceItem updated,
                                                      @AuthenticationPrincipal UserDetails user,
                                                      HttpServletRequest request) {
        return serviceItemRepository.findById(id).map(svc -> {
            svc.setName(updated.getName());
            svc.setDescription(updated.getDescription());
            svc.setShortDescription(updated.getShortDescription());
            svc.setBasePrice(updated.getBasePrice());
            svc.setPricingModel(updated.getPricingModel());
            svc.setPricingFormula(updated.getPricingFormula());
            svc.setSlaHours(updated.getSlaHours());
            svc.setOlaHours(updated.getOlaHours());
            svc.setDeliveryTimeDays(updated.getDeliveryTimeDays());
            svc.setIsActive(updated.getIsActive());
            svc.setIsFeatured(updated.getIsFeatured());
            svc.setIconClass(updated.getIconClass());
            svc.setWalletEnabled(updated.getWalletEnabled());
            svc.setWalletDeductTiming(updated.getWalletDeductTiming());
            ServiceItem saved = serviceItemRepository.save(svc);
            auditService.log("SERVICE_UPDATE", "SERVICE_CATALOG", id,
                user.getUsername(), "بروزرسانی خدمت: " + svc.getName(),
                request.getRemoteAddr(), true);
            return ResponseEntity.ok(saved);
        }).orElse(ResponseEntity.notFound().build());
    }

    @PreAuthorize("hasAnyRole('ADMIN','SUPER_ADMIN')")
    @DeleteMapping("/services/{id}")
    public ResponseEntity<?> deleteService(@PathVariable Long id,
                                            @AuthenticationPrincipal UserDetails user,
                                            HttpServletRequest request) {
        return serviceItemRepository.findById(id).map(svc -> {
            serviceItemRepository.delete(svc);
            auditService.log("SERVICE_DELETE", "SERVICE_CATALOG", id,
                user.getUsername(), "حذف خدمت: " + svc.getName(),
                request.getRemoteAddr(), true);
            return ResponseEntity.ok("خدمت حذف شد");
        }).orElse(ResponseEntity.notFound().build());
    }
}
