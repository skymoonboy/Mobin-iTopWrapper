package com.itopwrapper.controller.admin;

import com.itopwrapper.model.entity.LdapProviderEntity;
import com.itopwrapper.service.impl.LdapConfigService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

/**
 * REST API مدیریت تنظیمات LDAP
 */
@RestController
@RequestMapping("/api/admin/ldap")
@RequiredArgsConstructor
@PreAuthorize("hasRole('SUPER_ADMIN')")
public class LdapApiController {

    private final LdapConfigService ldapConfigService;

    @GetMapping
    public List<LdapProviderEntity> getAll() {
        return ldapConfigService.getAllProviders();
    }

    @GetMapping("/{id}")
    public ResponseEntity<LdapProviderEntity> getById(@PathVariable Long id) {
        return ldapConfigService.getById(id)
            .map(ResponseEntity::ok)
            .orElse(ResponseEntity.notFound().build());
    }

    @PostMapping
    public ResponseEntity<LdapProviderEntity> create(@RequestBody LdapProviderEntity provider,
                                                      @AuthenticationPrincipal UserDetails user) {
        return ResponseEntity.ok(ldapConfigService.saveProvider(provider, user.getUsername()));
    }

    @PutMapping("/{id}")
    public ResponseEntity<LdapProviderEntity> update(@PathVariable Long id,
                                                      @RequestBody LdapProviderEntity provider,
                                                      @AuthenticationPrincipal UserDetails user) {
        provider.setId(id);
        return ResponseEntity.ok(ldapConfigService.saveProvider(provider, user.getUsername()));
    }

    @PostMapping("/{id}/test")
    public ResponseEntity<Map<String, Object>> testConnection(@PathVariable Long id) {
        return ldapConfigService.getById(id).map(p -> {
            boolean ok = ldapConfigService.testConnection(p);
            return ResponseEntity.ok(Map.of(
                "success", ok,
                "message", ok ? "اتصال به سرور LDAP برقرار شد" : "اتصال به سرور LDAP ناموفق بود"
            ));
        }).orElse(ResponseEntity.notFound().build());
    }

    @PostMapping("/{id}/disable")
    public ResponseEntity<Void> disable(@PathVariable Long id,
                                         @AuthenticationPrincipal UserDetails user) {
        ldapConfigService.disableProvider(id, user.getUsername());
        return ResponseEntity.ok().build();
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> delete(@PathVariable Long id,
                                        @AuthenticationPrincipal UserDetails user) {
        ldapConfigService.deleteProvider(id, user.getUsername());
        return ResponseEntity.ok().build();
    }
}
