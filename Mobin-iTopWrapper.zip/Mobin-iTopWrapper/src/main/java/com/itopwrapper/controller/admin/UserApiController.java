package com.itopwrapper.controller.admin;

import com.itopwrapper.audit.AuditService;
import com.itopwrapper.model.entity.User;
import com.itopwrapper.repository.UserRepository;
import jakarta.servlet.http.HttpServletRequest;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

/**
 * REST API مدیریت کاربران
 */
@RestController
@RequestMapping("/api/admin/users")
@RequiredArgsConstructor
@PreAuthorize("hasAnyRole('ADMIN','SUPER_ADMIN')")
public class UserApiController {

    private final UserRepository userRepository;
    private final PasswordEncoder passwordEncoder;
    private final AuditService auditService;

    @GetMapping
    public List<User> getAllUsers() {
        return userRepository.findAll();
    }

    @GetMapping("/{id}")
    public ResponseEntity<User> getUser(@PathVariable Long id) {
        return userRepository.findById(id)
            .map(ResponseEntity::ok)
            .orElse(ResponseEntity.notFound().build());
    }

    @PostMapping
    public ResponseEntity<?> createUser(@RequestBody User user,
                                         @AuthenticationPrincipal UserDetails currentUser,
                                         HttpServletRequest request) {
        if (userRepository.existsByUsername(user.getUsername())) {
            return ResponseEntity.badRequest().body("نام کاربری قبلاً استفاده شده است");
        }
        if (user.getPasswordHash() != null) {
            user.setPasswordHash(passwordEncoder.encode(user.getPasswordHash()));
        }
        user.setCreatedBy(currentUser.getUsername());
        User saved = userRepository.save(user);
        auditService.log("USER_CREATE", "USER_MANAGEMENT", saved.getId(),
            currentUser.getUsername(), "کاربر جدید ایجاد شد: " + user.getUsername(),
            request.getRemoteAddr(), true);
        return ResponseEntity.ok(saved);
    }

    @PutMapping("/{id}")
    public ResponseEntity<?> updateUser(@PathVariable Long id,
                                         @RequestBody User updatedUser,
                                         @AuthenticationPrincipal UserDetails currentUser,
                                         HttpServletRequest request) {
        return userRepository.findById(id).map(user -> {
            user.setFirstName(updatedUser.getFirstName());
            user.setLastName(updatedUser.getLastName());
            user.setEmail(updatedUser.getEmail());
            user.setOrganization(updatedUser.getOrganization());
            user.setPhone(updatedUser.getPhone());
            user.setRoles(updatedUser.getRoles());
            if (updatedUser.getPasswordHash() != null && !updatedUser.getPasswordHash().isBlank()) {
                user.setPasswordHash(passwordEncoder.encode(updatedUser.getPasswordHash()));
            }
            User saved = userRepository.save(user);
            auditService.log("USER_UPDATE", "USER_MANAGEMENT", id,
                currentUser.getUsername(), "کاربر بروزرسانی شد: " + user.getUsername(),
                request.getRemoteAddr(), true);
            return ResponseEntity.ok(saved);
        }).orElse(ResponseEntity.notFound().build());
    }

    @PostMapping("/{id}/toggle-active")
    public ResponseEntity<?> toggleActive(@PathVariable Long id,
                                           @RequestBody Map<String, Boolean> body,
                                           @AuthenticationPrincipal UserDetails currentUser,
                                           HttpServletRequest request) {
        return userRepository.findById(id).map(user -> {
            boolean active = Boolean.TRUE.equals(body.get("active"));
            user.setIsActive(active);
            userRepository.save(user);
            auditService.log(active ? "USER_ACTIVATE" : "USER_DEACTIVATE",
                "USER_MANAGEMENT", id, currentUser.getUsername(),
                (active ? "فعال" : "غیرفعال") + " کردن کاربر: " + user.getUsername(),
                request.getRemoteAddr(), true);
            return ResponseEntity.ok(Map.of("active", active));
        }).orElse(ResponseEntity.notFound().build());
    }

    @PostMapping("/{id}/reset-password")
    public ResponseEntity<?> resetPassword(@PathVariable Long id,
                                            @RequestBody Map<String, String> body,
                                            @AuthenticationPrincipal UserDetails currentUser,
                                            HttpServletRequest request) {
        return userRepository.findById(id).map(user -> {
            String newPassword = body.get("password");
            if (newPassword == null || newPassword.length() < 8) {
                return ResponseEntity.badRequest().body("رمز عبور باید حداقل ۸ کاراکتر باشد");
            }
            user.setPasswordHash(passwordEncoder.encode(newPassword));
            userRepository.save(user);
            auditService.log("PASSWORD_RESET", "USER_MANAGEMENT", id,
                currentUser.getUsername(), "بازنشانی رمز عبور کاربر: " + user.getUsername(),
                request.getRemoteAddr(), true);
            return ResponseEntity.ok("رمز عبور بازنشانی شد");
        }).orElse(ResponseEntity.notFound().build());
    }

    @DeleteMapping("/{id}")
    @PreAuthorize("hasRole('SUPER_ADMIN')")
    public ResponseEntity<?> deleteUser(@PathVariable Long id,
                                         @AuthenticationPrincipal UserDetails currentUser,
                                         HttpServletRequest request) {
        return userRepository.findById(id).map(user -> {
            userRepository.delete(user);
            auditService.log("USER_DELETE", "USER_MANAGEMENT", id,
                currentUser.getUsername(), "حذف کاربر: " + user.getUsername(),
                request.getRemoteAddr(), true);
            return ResponseEntity.ok("کاربر حذف شد");
        }).orElse(ResponseEntity.notFound().build());
    }
}
