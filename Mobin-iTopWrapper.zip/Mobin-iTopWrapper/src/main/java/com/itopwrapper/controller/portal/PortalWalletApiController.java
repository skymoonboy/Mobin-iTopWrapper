package com.itopwrapper.controller.portal;

import com.itopwrapper.model.dto.WalletSummaryDto;
import com.itopwrapper.model.dto.WalletTransactionDto;
import com.itopwrapper.model.entity.User;
import com.itopwrapper.model.entity.Wallet;
import com.itopwrapper.repository.UserRepository;
import com.itopwrapper.wallet.WalletService;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Sort;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.*;

/**
 * REST API کیف‌پول — پرتال مشتریان (فقط مشاهده، بدون قابلیت شارژ/کسر دستی).
 */
@RestController
@RequestMapping("/api/portal/wallet")
@RequiredArgsConstructor
public class PortalWalletApiController {

    private final WalletService walletService;
    private final UserRepository userRepository;

    /** موجودی و خلاصه کیف‌پول کاربر جاری */
    @GetMapping
    public ResponseEntity<WalletSummaryDto> getMyWallet(@AuthenticationPrincipal UserDetails userDetails) {
        User user = currentUser(userDetails);
        Wallet wallet = walletService.getOrCreateWallet(user.getId());
        return ResponseEntity.ok(toDto(wallet));
    }

    /** گردش‌حساب کیف‌پول کاربر جاری */
    @GetMapping("/transactions")
    @Transactional(readOnly = true)
    public Page<WalletTransactionDto> myTransactions(
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "20") int size,
            @AuthenticationPrincipal UserDetails userDetails) {
        User user = currentUser(userDetails);
        return walletService.getHistory(user.getId(),
            PageRequest.of(page, size, Sort.by(Sort.Direction.DESC, "createdAt")))
            .map(WalletTransactionDto::from);
    }

    private User currentUser(UserDetails userDetails) {
        return userRepository.findByUsername(userDetails.getUsername())
            .orElseThrow(() -> new RuntimeException("کاربر یافت نشد"));
    }

    private WalletSummaryDto toDto(Wallet w) {
        return WalletSummaryDto.builder()
            .walletId(w.getId())
            .userId(w.getUser().getId())
            .username(w.getUser().getUsername())
            .fullName(w.getUser().getFullName())
            .balance(w.getBalance())
            .heldAmount(w.getHeldAmount())
            .availableBalance(w.getAvailableBalance())
            .creditLimit(w.getCreditLimit())
            .maxWithdrawable(w.getMaxWithdrawable())
            .currency(w.getCurrency())
            .isActive(w.getIsActive())
            .isLowBalance(w.isLowBalance())
            .build();
    }
}
