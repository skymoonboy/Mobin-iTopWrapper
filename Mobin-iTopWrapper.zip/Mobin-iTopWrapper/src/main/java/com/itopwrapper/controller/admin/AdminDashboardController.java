package com.itopwrapper.controller.admin;

import com.itopwrapper.itop.ITopApiClient;
import com.itopwrapper.model.entity.AuditLog;
import com.itopwrapper.repository.AuditLogRepository;
import com.itopwrapper.repository.UserRepository;
import com.itopwrapper.repository.ServiceCategoryRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.data.domain.PageRequest;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import java.time.LocalDateTime;

/**
 * کنترلر پرتال مدیریتی
 */
@Controller
@RequestMapping("/admin")
@RequiredArgsConstructor
@Slf4j
@PreAuthorize("hasAnyRole('ADMIN','SUPER_ADMIN')")
public class AdminDashboardController {

    private final UserRepository userRepository;
    private final AuditLogRepository auditLogRepository;
    private final ServiceCategoryRepository serviceCategoryRepository;
    private final ITopApiClient iTopApiClient;

    @GetMapping({"", "/", "/dashboard"})
    public String dashboard(Model model) {
        // آمار کلی
        model.addAttribute("totalUsers", userRepository.count());
        model.addAttribute("activeUsers", userRepository.countByIsActive(true));
        model.addAttribute("totalServices", serviceCategoryRepository.count());
        model.addAttribute("recentLogs",
            auditLogRepository.findTop10ByOrderByCreatedAtDesc());

        // وضعیت موتور iTop
        boolean itopAvailable = iTopApiClient.isITopAvailable();
        model.addAttribute("itopStatus", itopAvailable ? "متصل" : "قطع");
        model.addAttribute("itopAvailable", itopAvailable);

        // آمار لاگ‌ها در ۲۴ ساعت گذشته
        LocalDateTime yesterday = LocalDateTime.now().minusDays(1);
        model.addAttribute("errorCount",
            auditLogRepository.countByLevelAndCreatedAtAfter(AuditLog.LogLevel.ERROR, yesterday));
        model.addAttribute("loginCount",
            auditLogRepository.countByActionAndCreatedAtAfter("LOGIN", yesterday));

        model.addAttribute("pageTitle", "داشبورد مدیریتی");
        return "admin/dashboard";
    }

    @GetMapping("/users")
    public String users(Model model) {
        model.addAttribute("users", userRepository.findAll());
        model.addAttribute("pageTitle", "مدیریت کاربران");
        return "admin/users";
    }

    @GetMapping("/services")
    public String services(Model model) {
        model.addAttribute("categories", serviceCategoryRepository.findByParentIsNull());
        model.addAttribute("pageTitle", "مدیریت کاتالوگ خدمات");
        return "admin/services";
    }

    @GetMapping("/sla")
    public String slaManagement(Model model) {
        try {
            var slas = iTopApiClient.getSLAs();
            var olas = iTopApiClient.getOLAs();
            model.addAttribute("slas", slas);
            model.addAttribute("olas", olas);
        } catch (Exception e) {
            log.error("خطا در دریافت SLA/OLA", e);
            model.addAttribute("error", "خطا در ارتباط با موتور iTop");
        }
        model.addAttribute("pageTitle", "مدیریت SLA و OLA");
        return "admin/sla";
    }

    @GetMapping("/projects")
    public String projects(Model model) {
        try {
            var projects = iTopApiClient.getProjects();
            model.addAttribute("projects", projects);
        } catch (Exception e) {
            model.addAttribute("error", "خطا در دریافت پروژه‌ها");
        }
        model.addAttribute("pageTitle", "مدیریت پروژه‌ها");
        return "admin/projects";
    }

    @GetMapping("/cost-centers")
    public String costCenters(Model model) {
        try {
            var costCenters = iTopApiClient.getCostCenters();
            model.addAttribute("costCenters", costCenters);
        } catch (Exception e) {
            model.addAttribute("error", "خطا در دریافت مراکز هزینه");
        }
        model.addAttribute("pageTitle", "مراکز هزینه");
        return "admin/cost-centers";
    }

    @GetMapping("/logs")
    public String logs(Model model) {
        model.addAttribute("logs",
            auditLogRepository.findAll(PageRequest.of(0, 100)).getContent());
        model.addAttribute("pageTitle", "لاگ‌های سامانه");
        return "admin/logs";
    }

    @GetMapping("/modules")
    @PreAuthorize("hasRole('SUPER_ADMIN')")
    public String modules(Model model) {
        model.addAttribute("pageTitle", "مدیریت ماژول‌ها");
        return "admin/modules";
    }

    @GetMapping("/ldap")
    public String ldapConfig(Model model) {
        model.addAttribute("pageTitle", "تنظیمات LDAP");
        return "admin/ldap";
    }

    @GetMapping("/pricing")
    public String pricingEngine(Model model) {
        model.addAttribute("pageTitle", "موتور قیمت‌گذاری");
        return "admin/pricing";
    }

    /** مدیریت کیف‌پول مشتریان — تخصیص اعتبار توسط سوپرادمین/ادمین محلی */
    @GetMapping("/wallets")
    public String wallets(Model model) {
        model.addAttribute("pageTitle", "مدیریت کیف‌پول مشتریان");
        return "admin/wallets";
    }
}
