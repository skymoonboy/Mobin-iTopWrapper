package com.itopwrapper.config;

import com.itopwrapper.security.jwt.JwtAuthenticationFilter;
import lombok.RequiredArgsConstructor;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.config.annotation.authentication.configuration.AuthenticationConfiguration;
import org.springframework.security.config.annotation.method.configuration.EnableMethodSecurity;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configurers.AbstractHttpConfigurer;
import org.springframework.security.config.http.SessionCreationPolicy;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.web.SecurityFilterChain;
import org.springframework.security.web.authentication.UsernamePasswordAuthenticationFilter;
import org.springframework.web.cors.CorsConfiguration;
import org.springframework.web.cors.CorsConfigurationSource;
import org.springframework.web.cors.UrlBasedCorsConfigurationSource;

import java.util.List;

/**
 * پیکربندی امنیتی سامانه
 * شامل JWT، Session، CORS و تعریف مسیرهای دسترسی
 */
@Configuration
@EnableWebSecurity
@EnableMethodSecurity(prePostEnabled = true)
@RequiredArgsConstructor
public class SecurityConfig {

    private final JwtAuthenticationFilter jwtAuthFilter;

    @Bean
    public SecurityFilterChain securityFilterChain(HttpSecurity http) throws Exception {
        http
            .csrf(AbstractHttpConfigurer::disable)
            .cors(cors -> cors.configurationSource(corsConfigurationSource()))
            .sessionManagement(session ->
                session.sessionCreationPolicy(SessionCreationPolicy.IF_REQUIRED))
            .authorizeHttpRequests(auth -> auth
                // مسیرهای عمومی
                .requestMatchers(
                    "/login", "/logout",
                    "/api/auth/**",
                    "/api/system/health",
                    "/css/**", "/js/**", "/images/**", "/webjars/**",
                    "/favicon.ico", "/actuator/health",
                    "/error"
                ).permitAll()

                // کاتالوگ خدمات قابل خواندن برای همه کاربران احراز‌هویت‌شده
                // (پرتال مشتریان برای نمایش کاتالوگ از همین API استفاده می‌کند؛
                //  عملیات نوشتن با @PreAuthorize در سطح متد محدود به ADMIN است)
                .requestMatchers(org.springframework.http.HttpMethod.GET, "/api/admin/service-categories/**")
                    .authenticated()

                // پرتال مدیریتی - فقط برای ادمین
                .requestMatchers("/admin/**")
                    .hasAnyRole("SUPER_ADMIN", "ADMIN", "MANAGER", "OPERATOR")

                // مدیریت ماژول - فقط سوپر ادمین
                .requestMatchers("/api/admin/modules/**")
                    .hasRole("SUPER_ADMIN")

                // مدیریت کاربران و LDAP - ادمین به بالا
                .requestMatchers("/api/admin/users/**", "/api/admin/ldap/**")
                    .hasAnyRole("SUPER_ADMIN", "ADMIN")

                // سایر API مدیریتی
                .requestMatchers("/api/admin/**")
                    .hasAnyRole("SUPER_ADMIN", "ADMIN", "MANAGER", "OPERATOR")

                // پرتال مشتریان
                .requestMatchers("/portal/**")
                    .hasAnyRole("CUSTOMER", "OPERATOR", "ADMIN", "SUPER_ADMIN", "MANAGER")

                // API پرتال
                .requestMatchers("/api/portal/**")
                    .authenticated()

                // سایر مسیرها
                .anyRequest().authenticated()
            )
            .formLogin(form -> form
                .loginPage("/login")
                .loginProcessingUrl("/login")
                .defaultSuccessUrl("/dashboard", true)
                .failureUrl("/login?error=true")
                .usernameParameter("username")
                .passwordParameter("password")
                .permitAll()
            )
            .logout(logout -> logout
                .logoutUrl("/logout")
                .logoutSuccessUrl("/login?logout=true")
                .deleteCookies("JSESSIONID", "JWT_TOKEN")
                .invalidateHttpSession(true)
                .clearAuthentication(true)
                .permitAll()
            )
            .addFilterBefore(jwtAuthFilter, UsernamePasswordAuthenticationFilter.class);

        return http.build();
    }

    @Bean
    public PasswordEncoder passwordEncoder() {
        return new BCryptPasswordEncoder(12);
    }

    @Bean
    public AuthenticationManager authenticationManager(AuthenticationConfiguration config) throws Exception {
        return config.getAuthenticationManager();
    }

    @Bean
    public CorsConfigurationSource corsConfigurationSource() {
        CorsConfiguration configuration = new CorsConfiguration();
        configuration.setAllowedOriginPatterns(List.of("*"));
        configuration.setAllowedMethods(List.of("GET", "POST", "PUT", "DELETE", "OPTIONS", "PATCH"));
        configuration.setAllowedHeaders(List.of("*"));
        configuration.setAllowCredentials(true);
        configuration.setMaxAge(3600L);

        UrlBasedCorsConfigurationSource source = new UrlBasedCorsConfigurationSource();
        source.registerCorsConfiguration("/**", configuration);
        return source;
    }
}
