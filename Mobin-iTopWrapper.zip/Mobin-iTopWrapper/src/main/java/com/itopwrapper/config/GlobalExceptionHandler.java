package com.itopwrapper.config;

import com.itopwrapper.audit.AuditService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.AccessDeniedException;
import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.validation.FieldError;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;
import org.springframework.web.multipart.MaxUploadSizeExceededException;

import jakarta.servlet.http.HttpServletRequest;
import java.time.LocalDateTime;
import java.util.HashMap;
import java.util.Map;
import java.util.stream.Collectors;

/**
 * مدیریت متمرکز خطاهای سامانه
 */
@RestControllerAdvice
@Slf4j
@RequiredArgsConstructor
public class GlobalExceptionHandler {

    private final AuditService auditService;

    /** خطاهای کیف‌پول (کمبود موجودی، کیف‌پول غیرفعال و غیره) */
    @ExceptionHandler(com.itopwrapper.wallet.InsufficientBalanceException.class)
    public ResponseEntity<Map<String, Object>> handleInsufficientBalance(
            com.itopwrapper.wallet.InsufficientBalanceException ex) {
        return ResponseEntity.status(402).body(Map.of(
            "status",    402,
            "error",     "موجودی کیف‌پول کافی نیست",
            "message",   ex.getMessage(),
            "available", ex.getAvailable(),
            "requested", ex.getRequested(),
            "shortfall", ex.getShortfall()
        ));
    }

    @ExceptionHandler(com.itopwrapper.wallet.WalletException.class)
    public ResponseEntity<Map<String, Object>> handleWalletException(
            com.itopwrapper.wallet.WalletException ex) {
        return ResponseEntity.badRequest().body(Map.of(
            "status",  400,
            "error",   "خطای کیف‌پول",
            "message", ex.getMessage()
        ));
    }

    /** خطاهای اعتبارسنجی */
    @ExceptionHandler(MethodArgumentNotValidException.class)
    public ResponseEntity<Map<String, Object>> handleValidationErrors(
            MethodArgumentNotValidException ex) {

        Map<String, String> fieldErrors = ex.getBindingResult().getFieldErrors().stream()
            .collect(Collectors.toMap(
                FieldError::getField,
                fe -> fe.getDefaultMessage() != null ? fe.getDefaultMessage() : "خطای اعتبارسنجی",
                (a, b) -> a
            ));

        return ResponseEntity.badRequest().body(Map.of(
            "status",    400,
            "error",     "خطای اعتبارسنجی",
            "fields",    fieldErrors,
            "timestamp", LocalDateTime.now().toString()
        ));
    }

    /** خطای دسترسی غیرمجاز */
    @ExceptionHandler(AccessDeniedException.class)
    public ResponseEntity<Map<String, Object>> handleAccessDenied(
            AccessDeniedException ex, HttpServletRequest request) {

        String username = request.getUserPrincipal() != null
            ? request.getUserPrincipal().getName() : "anonymous";

        auditService.logSecurity("ACCESS_DENIED", username,
            "دسترسی غیرمجاز به: " + request.getRequestURI(),
            request.getRemoteAddr());

        return ResponseEntity.status(HttpStatus.FORBIDDEN).body(Map.of(
            "status",  403,
            "error",   "دسترسی غیرمجاز",
            "message", "شما مجوز دسترسی به این بخش را ندارید",
            "path",    request.getRequestURI()
        ));
    }

    /** خطای احراز هویت */
    @ExceptionHandler(BadCredentialsException.class)
    public ResponseEntity<Map<String, Object>> handleBadCredentials(BadCredentialsException ex) {
        return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body(Map.of(
            "status",  401,
            "error",   "خطای احراز هویت",
            "message", "نام کاربری یا رمز عبور اشتباه است"
        ));
    }

    /** خطای حجم فایل */
    @ExceptionHandler(MaxUploadSizeExceededException.class)
    public ResponseEntity<Map<String, Object>> handleFileSizeExceeded(MaxUploadSizeExceededException ex) {
        return ResponseEntity.status(HttpStatus.PAYLOAD_TOO_LARGE).body(Map.of(
            "status",  413,
            "error",   "حجم فایل بیش از حد مجاز",
            "message", "حداکثر حجم مجاز آپلود ۵۰ مگابایت است"
        ));
    }

    /** خطای موجودیت یافت نشد */
    @ExceptionHandler(RuntimeException.class)
    public ResponseEntity<Map<String, Object>> handleRuntimeException(
            RuntimeException ex, HttpServletRequest request) {

        String msg = ex.getMessage();
        if (msg != null && (msg.contains("یافت نشد") || msg.contains("not found"))) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(Map.of(
                "status",  404,
                "error",   "یافت نشد",
                "message", msg
            ));
        }

        log.error("خطای ناشناخته در {}: {}", request.getRequestURI(), ex.getMessage(), ex);
        auditService.logError("SYSTEM_ERROR", "SYSTEM", "system", ex.getMessage(), ex.getMessage(), request.getRemoteAddr());

        return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(Map.of(
            "status",  500,
            "error",   "خطای داخلی سامانه",
            "message", "خطایی در پردازش درخواست رخ داد. لطفاً مجدداً تلاش کنید."
        ));
    }

    /** خطاهای عمومی */
    @ExceptionHandler(Exception.class)
    public ResponseEntity<Map<String, Object>> handleGenericException(
            Exception ex, HttpServletRequest request) {

        log.error("خطای غیرمنتظره: {}", ex.getMessage(), ex);
        return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(Map.of(
            "status",  500,
            "error",   "خطای سرور",
            "message", "خطای داخلی سامانه"
        ));
    }
}
