package com.itopwrapper.config;

import com.itopwrapper.model.entity.*;
import com.itopwrapper.repository.*;
import com.itopwrapper.security.ldap.LdapProviderConfig;
import com.itopwrapper.security.ldap.MultiLdapAuthService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.ApplicationArguments;
import org.springframework.boot.ApplicationRunner;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.Set;

/**
 * راه‌اندازی اولیه سامانه هنگام اجرا
 * ایجاد داده‌های پایه، کاربر ادمین، و بارگذاری تنظیمات LDAP
 */
@Component
@Slf4j
@RequiredArgsConstructor
public class DataInitializer implements ApplicationRunner {

    private final UserRepository userRepository;
    private final RoleRepository roleRepository;
    private final LdapProviderRepository ldapProviderRepository;
    private final SlaRepository slaRepository;
    private final CostCenterRepository costCenterRepository;
    private final ProjectRepository projectRepository;
    private final MultiLdapAuthService multiLdapAuthService;
    private final PasswordEncoder passwordEncoder;
    private final com.itopwrapper.wallet.WalletService walletService;

    @Value("${ldap.providers[0].url:ldap://localhost:389}")
    private String primaryLdapUrl;
    @Value("${ldap.providers[0].base:dc=example,dc=com}")
    private String primaryLdapBase;
    @Value("${ldap.providers[0].enabled:false}")
    private boolean primaryLdapEnabled;

    @Override
    @Transactional
    public void run(ApplicationArguments args) {
        log.info("=== راه‌اندازی سامانه مدیریت خدمات فناوری اطلاعات ===");
        ensureRoles();
        ensureAdminUser();
        ensureAdminWallet();
        ensureDefaultSlas();
        ensureDefaultCostCenters();
        loadLdapProviders();
        log.info("=== راه‌اندازی اولیه با موفقیت انجام شد ===");
    }

    private void ensureRoles() {
        String[][] rolesData = {
            {"ROLE_SUPER_ADMIN", "سوپر ادمین — دسترسی کامل به تمام بخش‌ها"},
            {"ROLE_ADMIN",       "مدیر سامانه — مدیریت کاربران و خدمات"},
            {"ROLE_MANAGER",     "مدیر عملیات — مدیریت SLA و پروژه‌ها"},
            {"ROLE_OPERATOR",    "اپراتور — پردازش درخواست‌ها"},
            {"ROLE_CUSTOMER",    "مشتری — دسترسی به پرتال خدمات"}
        };
        for (String[] r : rolesData) {
            if (!roleRepository.existsByName(r[0])) {
                roleRepository.save(Role.builder()
                    .name(r[0]).description(r[1]).isSystemRole(true).build());
                log.debug("نقش ایجاد شد: {}", r[0]);
            }
        }
    }

    private void ensureAdminUser() {
        if (userRepository.existsByUsername("admin")) return;

        Role superAdmin = roleRepository.findByName("ROLE_SUPER_ADMIN")
            .orElseThrow(() -> new RuntimeException("نقش ROLE_SUPER_ADMIN یافت نشد"));

        User admin = User.builder()
            .username("admin")
            .email("admin@itop.local")
            .passwordHash(passwordEncoder.encode("Admin@123"))
            .firstName("مدیر")
            .lastName("سامانه")
            .authType(User.AuthType.LOCAL)
            .isActive(true)
            .createdBy("system")
            .roles(Set.of(superAdmin))
            .build();
        userRepository.save(admin);
        log.info("کاربر ادمین پیش‌فرض ایجاد شد — رمز عبور: Admin@123  ← در محیط production تغییر دهید!");
    }

    /** ایجاد کیف‌پول اولیه برای ادمین (سایر کاربران به‌صورت Lazy هنگام اولین استفاده ساخته می‌شوند) */
    private void ensureAdminWallet() {
        userRepository.findByUsername("admin").ifPresent(admin ->
            walletService.getOrCreateWallet(admin.getId()));
    }

    private void ensureDefaultSlas() {
        if (slaRepository.count() > 0) return;

        SlaDefinition[] defaults = {
            SlaDefinition.builder()
                .name("SLA طلایی")
                .description("بالاترین سطح خدمت برای مشتریان VIP")
                .slaType(SlaDefinition.SlaType.SLA)
                .responseTimeMinutes(60)
                .resolutionTimeMinutes(480)
                .coverageType(SlaDefinition.CoverageType.H24_7)
                .isActive(true).build(),

            SlaDefinition.builder()
                .name("SLA نقره‌ای")
                .description("سطح خدمت استاندارد")
                .slaType(SlaDefinition.SlaType.SLA)
                .responseTimeMinutes(240)
                .resolutionTimeMinutes(1440)
                .coverageType(SlaDefinition.CoverageType.BUSINESS_HOURS)
                .isActive(true).build(),

            SlaDefinition.builder()
                .name("SLA برنزی")
                .description("سطح خدمت پایه")
                .slaType(SlaDefinition.SlaType.SLA)
                .responseTimeMinutes(480)
                .resolutionTimeMinutes(2880)
                .coverageType(SlaDefinition.CoverageType.BUSINESS_HOURS)
                .isActive(true).build(),

            SlaDefinition.builder()
                .name("OLA تیم زیرساخت")
                .description("توافقنامه داخلی تیم زیرساخت")
                .slaType(SlaDefinition.SlaType.OLA)
                .responseTimeMinutes(120)
                .resolutionTimeMinutes(720)
                .coverageType(SlaDefinition.CoverageType.BUSINESS_HOURS)
                .isActive(true).build(),

            SlaDefinition.builder()
                .name("OLA تیم شبکه")
                .description("توافقنامه داخلی تیم شبکه")
                .slaType(SlaDefinition.SlaType.OLA)
                .responseTimeMinutes(60)
                .resolutionTimeMinutes(360)
                .coverageType(SlaDefinition.CoverageType.H24_7)
                .isActive(true).build()
        };

        for (SlaDefinition s : defaults) slaRepository.save(s);
        log.info("{} SLA/OLA پیش‌فرض ایجاد شد", defaults.length);
    }

    private void ensureDefaultCostCenters() {
        if (costCenterRepository.count() > 0) return;

        CostCenter it = CostCenter.builder()
            .code("CC-IT").name("اداره فناوری اطلاعات")
            .description("مرکز هزینه اصلی واحد IT")
            .annualBudget(new BigDecimal("5000000000"))
            .currency("IRR").isActive(true).build();
        it = costCenterRepository.save(it);

        CostCenter[] children = {
            CostCenter.builder().code("CC-IT-INF").name("زیرساخت و سرورها")
                .annualBudget(new BigDecimal("2000000000")).parent(it)
                .currency("IRR").isActive(true).build(),
            CostCenter.builder().code("CC-IT-NET").name("شبکه و ارتباطات")
                .annualBudget(new BigDecimal("1500000000")).parent(it)
                .currency("IRR").isActive(true).build(),
            CostCenter.builder().code("CC-IT-SEC").name("امنیت اطلاعات")
                .annualBudget(new BigDecimal("1000000000")).parent(it)
                .currency("IRR").isActive(true).build(),
            CostCenter.builder().code("CC-IT-DEV").name("توسعه نرم‌افزار")
                .annualBudget(new BigDecimal("500000000")).parent(it)
                .currency("IRR").isActive(true).build()
        };
        for (CostCenter c : children) costCenterRepository.save(c);
        log.info("مراکز هزینه پیش‌فرض ایجاد شد");
    }

    private void loadLdapProviders() {
        ldapProviderRepository.findByIsEnabledTrue().forEach(p -> {
            try {
                multiLdapAuthService.registerProvider(
                    LdapProviderConfig.builder()
                        .id(p.getProviderId()).name(p.getName())
                        .url(p.getUrl()).base(p.getBaseDn())
                        .userDn(p.getBindDn()).password(p.getBindPassword())
                        .enabled(true).build());
                log.info("ارائه‌دهنده LDAP بارگذاری شد: {}", p.getName());
            } catch (Exception e) {
                log.warn("خطا در بارگذاری LDAP {}: {}", p.getName(), e.getMessage());
            }
        });

        // اگر LDAP در application.yml فعال است و در DB نیست، ثبت موقت می‌کنیم
        if (primaryLdapEnabled && ldapProviderRepository.count() == 0) {
            multiLdapAuthService.registerProvider(
                LdapProviderConfig.builder()
                    .id("primary").name("سرور LDAP اصلی")
                    .url(primaryLdapUrl).base(primaryLdapBase)
                    .enabled(true).build());
            log.info("LDAP از application.yml بارگذاری شد");
        }
    }
}
