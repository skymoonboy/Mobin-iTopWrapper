package ir.itop.client.model;

import java.util.List;

/** بسته داده گانت چارت یک پروژه — پروژه + لیست وظایف */
public class GanttData {
    private final ITopObject project;
    private final List<ITopObject> tasks;

    public GanttData(ITopObject project, List<ITopObject> tasks) {
        this.project = project;
        this.tasks = tasks;
    }

    public ITopObject getProject() { return project; }
    public List<ITopObject> getTasks() { return tasks; }
}
