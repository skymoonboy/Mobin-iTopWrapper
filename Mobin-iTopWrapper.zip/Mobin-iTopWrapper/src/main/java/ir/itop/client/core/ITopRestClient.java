package ir.itop.client.core;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ArrayNode;
import com.fasterxml.jackson.databind.node.ObjectNode;
import ir.itop.client.exception.ITopApiException;
import ir.itop.client.exception.ITopAuthException;
import ir.itop.client.exception.ITopObjectNotFoundException;
import ir.itop.client.model.*;
import org.apache.hc.client5.http.classic.methods.HttpPost;
import org.apache.hc.client5.http.entity.mime.MultipartEntityBuilder;
import org.apache.hc.client5.http.impl.classic.CloseableHttpClient;
import org.apache.hc.client5.http.impl.classic.CloseableHttpResponse;
import org.apache.hc.client5.http.impl.classic.HttpClients;
import org.apache.hc.client5.http.impl.io.PoolingHttpClientConnectionManager;
import org.apache.hc.core5.http.ContentType;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.util.*;
import java.util.concurrent.TimeUnit;

/**
 * ========================================================
 * کلاس کامل کلاینت REST/JSON وب‌سرویس iTop ITSM
 * ========================================================
 *
 * این کلاس تمامی عملیات‌های API iTop را پوشش می‌دهد:
 *
 * ۱. عملیات‌های هسته‌ای (Core Services):
 *    - list_operations     : لیست تمام عملیات‌های موجود
 *    - core/get            : جستجو و دریافت اشیاء
 *    - core/create         : ایجاد شیء جدید
 *    - core/update         : بروزرسانی شیء
 *    - core/delete         : حذف شیء
 *    - core/apply_stimulus : تغییر وضعیت شیء (workflow)
 *    - core/get_related    : دریافت اشیاء مرتبط
 *    - core/check_credentials : تایید اعتبارنامه
 *
 * ۲. ماژول درخواست کاربر (UserRequest):
 *    - ایجاد، ویرایش، بستن، بازگشایی، تخصیص
 *    - مدیریت گزارشات، پیگیری SLA/TTO/TTR
 *
 * ۳. ماژول حوادث (Incident):
 *    - مدیریت کامل چرخه عمر حادثه
 *    - تخصیص، بررسی، تایید، بستن
 *
 * ۴. ماژول تغییرات (Change Management):
 *    - NormalChange, RoutineChange, EmergencyChange
 *    - مدیریت گردش کار تغییرات
 *
 * ۵. ماژول مشکلات (Problem Management):
 *    - مدیریت چرخه عمر مشکل
 *    - اتصال به Known Errors
 *
 * ۶. ماژول SLA/OLA/SLT:
 *    - مدیریت قراردادهای سطح سرویس
 *    - محاسبه TTO/TTR
 *    - گزارش‌گیری از نقض SLA
 *
 * ۷. ماژول پروژه (Project Management + Gantt):
 *    - مدیریت پروژه، وظایف، دشبورد Gantt
 *
 * ۸. ماژول مرکز هزینه (Cost Center):
 *    - مدیریت مراکز هزینه، بودجه و تخصیص
 *
 * ۹. CMDB (Configuration Management Database):
 *    - مدیریت CI ها، روابط، تاثیرات
 *
 * ۱۰. مدیریت پیوست‌ها و مدارک:
 *    - آپلود، دانلود، حذف فایل
 *
 * مستندات رسمی: https://www.itophub.io/wiki/page?id=latest:advancedtopics:rest_json
 *
 * @author  IT Service Management Team
 * @version 1.0.0
 */
public class ITopRestClient implements AutoCloseable {

    private static final Logger log = LoggerFactory.getLogger(ITopRestClient.class);

    // ─── نسخه‌های API پشتیبانی شده ───────────────────────────
    public static final String API_VERSION_1_3 = "1.3";
    public static final String API_VERSION_1_2 = "1.2";
    public static final String API_VERSION_1_1 = "1.1";

    // ─── عملیات‌های هسته‌ای ───────────────────────────────────
    public static final String OP_LIST_OPERATIONS     = "list_operations";
    public static final String OP_CORE_GET            = "core/get";
    public static final String OP_CORE_CREATE         = "core/create";
    public static final String OP_CORE_UPDATE         = "core/update";
    public static final String OP_CORE_DELETE         = "core/delete";
    public static final String OP_CORE_APPLY_STIMULUS = "core/apply_stimulus";
    public static final String OP_CORE_GET_RELATED    = "core/get_related";
    public static final String OP_CHECK_CREDENTIALS   = "core/check_credentials";

    // ─── کدهای خطا (طبق مستندات iTop) ───────────────────────
    public static final int CODE_OK                 = 0;
    public static final int CODE_UNAUTHORIZED       = 1;
    public static final int CODE_MISSING_VERSION    = 2;
    public static final int CODE_MISSING_JSON       = 3;
    public static final int CODE_INVALID_JSON       = 4;
    public static final int CODE_MISSING_AUTH_USER  = 5;
    public static final int CODE_MISSING_AUTH_PWD   = 6;
    public static final int CODE_UNSUPPORTED_VER    = 10;
    public static final int CODE_UNKNOWN_OPERATION  = 11;
    public static final int CODE_UNSAFE             = 12;
    public static final int CODE_INTERNAL_ERROR     = 100;

    // ─── محرک‌های وضعیت (Stimuli) ─────────────────────────────
    // UserRequest
    public static final String STIMULUS_UR_ASSIGN     = "ev_assign";
    public static final String STIMULUS_UR_ESCALATE   = "ev_escalate";
    public static final String STIMULUS_UR_RESOLVE    = "ev_resolve";
    public static final String STIMULUS_UR_REOPEN     = "ev_reopen";
    public static final String STIMULUS_UR_CLOSE      = "ev_close";
    public static final String STIMULUS_UR_WAIT_REPL  = "ev_wait_for_approval";
    public static final String STIMULUS_UR_APPROVE    = "ev_approve";
    public static final String STIMULUS_UR_REJECT     = "ev_reject";

    // Incident
    public static final String STIMULUS_INC_ASSIGN     = "ev_assign";
    public static final String STIMULUS_INC_ESCALATE   = "ev_escalate";
    public static final String STIMULUS_INC_RESOLVE    = "ev_resolve";
    public static final String STIMULUS_INC_REOPEN     = "ev_reopen";
    public static final String STIMULUS_INC_CLOSE      = "ev_close";

    // Change
    public static final String STIMULUS_CHG_SUBMIT    = "ev_submit";
    public static final String STIMULUS_CHG_APPROVE   = "ev_approve";
    public static final String STIMULUS_CHG_REJECT    = "ev_reject";
    public static final String STIMULUS_CHG_PLAN      = "ev_plan";
    public static final String STIMULUS_CHG_IMPLEMENT = "ev_implement";
    public static final String STIMULUS_CHG_MONITOR   = "ev_monitor";
    public static final String STIMULUS_CHG_CLOSE     = "ev_close";
    public static final String STIMULUS_CHG_REOPEN    = "ev_reopen";

    // Problem
    public static final String STIMULUS_PRB_ASSIGN   = "ev_assign";
    public static final String STIMULUS_PRB_RESOLVE  = "ev_resolve";
    public static final String STIMULUS_PRB_REOPEN   = "ev_reopen";
    public static final String STIMULUS_PRB_CLOSE    = "ev_close";

    // ─── کلاس‌های موجود در مدل داده iTop ─────────────────────
    public static final String CLASS_USER_REQUEST       = "UserRequest";
    public static final String CLASS_INCIDENT           = "Incident";
    public static final String CLASS_PROBLEM            = "Problem";
    public static final String CLASS_CHANGE             = "Change";
    public static final String CLASS_NORMAL_CHANGE      = "NormalChange";
    public static final String CLASS_ROUTINE_CHANGE     = "RoutineChange";
    public static final String CLASS_EMERGENCY_CHANGE   = "EmergencyChange";
    public static final String CLASS_KNOWN_ERROR        = "KnownError";
    public static final String CLASS_SLA                = "SLA";
    public static final String CLASS_SLT                = "SLT";
    public static final String CLASS_SERVICE            = "Service";
    public static final String CLASS_SERVICE_SUBFAMILY  = "ServiceSubcategory";
    public static final String CLASS_SERVICE_FAMILY     = "ServiceFamily";
    public static final String CLASS_ORGANIZATION       = "Organization";
    public static final String CLASS_PERSON             = "Person";
    public static final String CLASS_TEAM               = "Team";
    public static final String CLASS_CONTACT            = "Contact";
    public static final String CLASS_LOCATION           = "Location";
    public static final String CLASS_CONTRACT_CUSTOMER  = "CustomerContract";
    public static final String CLASS_CONTRACT_PROVIDER  = "ProviderContract";
    public static final String CLASS_DELIVERY_MODEL     = "DeliveryModel";
    public static final String CLASS_ATTACHMENT         = "Attachment";
    public static final String CLASS_DOCUMENT           = "Document";
    public static final String CLASS_DOCUMENT_FILE      = "DocumentFile";
    public static final String CLASS_DOCUMENT_WEB       = "DocumentWeb";
    public static final String CLASS_USER               = "User";
    public static final String CLASS_USER_LOCAL         = "UserLocal";
    public static final String CLASS_USER_LDAP          = "UserLDAP";
    public static final String CLASS_PROFILE            = "Profile";
    public static final String CLASS_URP_PROFILES       = "URP_Profiles";
    // CMDB Classes
    public static final String CLASS_SERVER             = "Server";
    public static final String CLASS_VIRTUAL_MACHINE    = "VirtualMachine";
    public static final String CLASS_PC                 = "PC";
    public static final String CLASS_NETWORK_DEVICE     = "NetworkDevice";
    public static final String CLASS_APPLICATION        = "ApplicationSolution";
    public static final String CLASS_MIDDLEWARE         = "Middleware";
    public static final String CLASS_SOFTWARE           = "Software";
    public static final String CLASS_TYPOLOGY           = "BusinessProcess";
    // Project & Cost Center (Extensions)
    public static final String CLASS_PROJECT            = "Project";
    public static final String CLASS_PROJECT_TASK       = "ProjectTask";
    public static final String CLASS_COST_CENTER        = "CostCenter";
    public static final String CLASS_BUDGET             = "Budget";
    public static final String CLASS_OLA                = "OLA";  // Extension

    // ─── فیلدهای خروجی استاندارد ──────────────────────────────
    public static final String OUTPUT_FIELDS_ALL      = "*";
    public static final String OUTPUT_FIELDS_ALL_PLUS = "*+";

    // ─── تنظیمات اتصال ────────────────────────────────────────
    private final String baseUrl;
    private final String authUser;
    private final String authPassword;
    private final String authToken;
    private final String apiVersion;
    private final CloseableHttpClient httpClient;
    private final ObjectMapper objectMapper;

    // ─── تنظیمات Connection Pool ──────────────────────────────
    private static final int MAX_CONNECTIONS     = 20;
    private static final int CONNECTION_TIMEOUT  = 30_000;
    private static final int SOCKET_TIMEOUT      = 60_000;

    // ================================================================
    //  سازنده‌ها (Constructors)
    // ================================================================

    /**
     * سازنده با نام‌کاربری و رمزعبور
     */
    public ITopRestClient(String baseUrl, String authUser, String authPassword) {
        this(baseUrl, authUser, authPassword, null, API_VERSION_1_3);
    }

    /**
     * سازنده با توکن احراز هویت (Application Token / Personal Token)
     * از iTop 3.0+ پشتیبانی می‌شود
     */
    public ITopRestClient(String baseUrl, String authToken) {
        this(baseUrl, null, null, authToken, API_VERSION_1_3);
    }

    /**
     * سازنده کامل
     */
    public ITopRestClient(String baseUrl, String authUser, String authPassword,
                          String authToken, String apiVersion) {
        this.baseUrl     = baseUrl.endsWith("/") ? baseUrl : baseUrl + "/";
        this.authUser    = authUser;
        this.authPassword = authPassword;
        this.authToken   = authToken;
        this.apiVersion  = apiVersion != null ? apiVersion : API_VERSION_1_3;
        this.objectMapper = new ObjectMapper();

        PoolingHttpClientConnectionManager connManager = new PoolingHttpClientConnectionManager();
        connManager.setMaxTotal(MAX_CONNECTIONS);
        connManager.setDefaultMaxPerRoute(MAX_CONNECTIONS);

        this.httpClient = HttpClients.custom()
                .setConnectionManager(connManager)
                .evictExpiredConnections()
                .evictIdleConnections(30L, TimeUnit.SECONDS)
                .build();

        log.info("ITopRestClient initialized for: {}", this.baseUrl);
    }

    // ================================================================
    //  ۱. عملیات‌های هسته‌ای (Core Operations)
    // ================================================================

    /**
     * دریافت لیست تمام عملیات‌های موجود در API
     * عملیات: list_operations
     */
    public List<ITopOperation> listOperations() throws ITopApiException {
        ObjectNode payload = objectMapper.createObjectNode();
        payload.put("operation", OP_LIST_OPERATIONS);

        JsonNode response = executeRequest(payload);
        List<ITopOperation> operations = new ArrayList<>();
        JsonNode opsNode = response.get("operations");
        if (opsNode != null && opsNode.isArray()) {
            for (JsonNode op : opsNode) {
                operations.add(new ITopOperation(
                        op.path("verb").asText(),
                        op.path("description").asText(),
                        op.path("extension").asText()
                ));
            }
        }
        return operations;
    }

    /**
     * تایید اعتبارنامه کاربر
     * عملیات: core/check_credentials
     */
    public boolean checkCredentials(String username, String password) throws ITopApiException {
        ObjectNode payload = objectMapper.createObjectNode();
        payload.put("operation", OP_CHECK_CREDENTIALS);
        payload.put("user", username);
        payload.put("password", password);

        try {
            JsonNode response = executeRequest(payload);
            int code = response.path("code").asInt(-1);
            return code == CODE_OK;
        } catch (ITopAuthException e) {
            return false;
        }
    }

    /**
     * جستجو و دریافت اشیاء با OQL یا معیارهای جستجو
     * عملیات: core/get
     *
     * @param className  نام کلاس iTop (مثال: "UserRequest")
     * @param key        کلید شناسایی: عدد ID، رشته OQL، یا Map از فیلدها
     * @param outputFields فیلدهای خروجی (مثال: "id,name,status" یا "*")
     */
    public List<ITopObject> getObjects(String className, Object key, String outputFields)
            throws ITopApiException {
        return getObjects(className, key, outputFields, 0, 1);
    }

    /**
     * جستجو با صفحه‌بندی (Pagination) - از iTop 2.6.1+ پشتیبانی می‌شود
     */
    public List<ITopObject> getObjects(String className, Object key, String outputFields,
                                       int limit, int page) throws ITopApiException {
        ObjectNode payload = objectMapper.createObjectNode();
        payload.put("operation", OP_CORE_GET);
        payload.put("class", className);
        setKeyOnPayload(payload, key);
        payload.put("output_fields", outputFields != null ? outputFields : OUTPUT_FIELDS_ALL);

        if (limit > 0) {
            payload.put("limit", limit);
            payload.put("page", Math.max(1, page));
        }

        JsonNode response = executeRequest(payload);
        return parseObjectsFromResponse(response);
    }

    /**
     * دریافت یک شیء منحرد با ID
     */
    public ITopObject getObjectById(String className, int id, String outputFields)
            throws ITopApiException {
        List<ITopObject> objects = getObjects(className, id, outputFields);
        if (objects.isEmpty()) {
            throw new ITopObjectNotFoundException(className, String.valueOf(id));
        }
        return objects.get(0);
    }

    /**
     * دریافت اشیاء با OQL
     */
    public List<ITopObject> getObjectsByOQL(String className, String oqlQuery, String outputFields)
            throws ITopApiException {
        return getObjects(className, oqlQuery, outputFields);
    }

    /**
     * ایجاد شیء جدید
     * عملیات: core/create
     *
     * @param className  نام کلاس
     * @param fields     Map از فیلدها و مقادیر
     * @param comment    توضیح عملیات (برای حسابرسی)
     * @param outputFields فیلدهای خروجی پس از ایجاد
     */
    public ITopObject createObject(String className, Map<String, Object> fields,
                                   String comment, String outputFields) throws ITopApiException {
        ObjectNode payload = objectMapper.createObjectNode();
        payload.put("operation", OP_CORE_CREATE);
        payload.put("class", className);
        payload.put("comment", comment != null ? comment : "Created via Java API");
        payload.put("output_fields", outputFields != null ? outputFields : "id,friendlyname");
        payload.set("fields", buildFieldsNode(fields));

        JsonNode response = executeRequest(payload);
        List<ITopObject> objects = parseObjectsFromResponse(response);
        if (objects.isEmpty()) {
            throw new ITopApiException("شیء ایجاد شد ولی نتیجه‌ای بازگشت داده نشد");
        }
        return objects.get(0);
    }

    /**
     * بروزرسانی شیء موجود
     * عملیات: core/update
     */
    public ITopObject updateObject(String className, Object key, Map<String, Object> fields,
                                   String comment, String outputFields) throws ITopApiException {
        ObjectNode payload = objectMapper.createObjectNode();
        payload.put("operation", OP_CORE_UPDATE);
        payload.put("class", className);
        setKeyOnPayload(payload, key);
        payload.put("comment", comment != null ? comment : "Updated via Java API");
        payload.put("output_fields", outputFields != null ? outputFields : "id,friendlyname");
        payload.set("fields", buildFieldsNode(fields));

        JsonNode response = executeRequest(payload);
        List<ITopObject> objects = parseObjectsFromResponse(response);
        if (objects.isEmpty()) {
            throw new ITopApiException("شیء بروزرسانی شد ولی نتیجه‌ای بازگشت داده نشد");
        }
        return objects.get(0);
    }

    /**
     * حذف شیء
     * عملیات: core/delete
     *
     * @param simulateOnly اگر true باشد، فقط شبیه‌سازی می‌شود (dry run)
     */
    public ITopDeleteResult deleteObject(String className, Object key,
                                         String comment, boolean simulateOnly) throws ITopApiException {
        ObjectNode payload = objectMapper.createObjectNode();
        payload.put("operation", OP_CORE_DELETE);
        payload.put("class", className);
        setKeyOnPayload(payload, key);
        payload.put("comment", comment != null ? comment : "Deleted via Java API");
        payload.put("simulate", simulateOnly);

        JsonNode response = executeRequest(payload);
        return new ITopDeleteResult(
                response.path("objects").size(),
                simulateOnly,
                response.path("message").asText()
        );
    }

    /**
     * اعمال محرک وضعیت (Stimulus) برای تغییر وضعیت شیء در گردش کار
     * عملیات: core/apply_stimulus
     *
     * مثال: تخصیص تیکت به کارشناس، بستن تیکت، بازگشایی حادثه
     *
     * @param className  نام کلاس
     * @param key        شناسه شیء
     * @param stimulus   نام محرک (مثال: "ev_assign", "ev_resolve")
     * @param fields     فیلدهای اضافی همراه محرک
     */
    public ITopObject applyStimulus(String className, Object key, String stimulus,
                                    Map<String, Object> fields, String comment,
                                    String outputFields) throws ITopApiException {
        ObjectNode payload = objectMapper.createObjectNode();
        payload.put("operation", OP_CORE_APPLY_STIMULUS);
        payload.put("class", className);
        setKeyOnPayload(payload, key);
        payload.put("stimulus", stimulus);
        payload.put("comment", comment != null ? comment : "Stimulus applied via Java API");
        payload.put("output_fields", outputFields != null ? outputFields : "id,friendlyname,status");

        if (fields != null && !fields.isEmpty()) {
            payload.set("fields", buildFieldsNode(fields));
        }

        JsonNode response = executeRequest(payload);
        List<ITopObject> objects = parseObjectsFromResponse(response);
        if (objects.isEmpty()) {
            throw new ITopApiException("محرک اعمال شد ولی نتیجه‌ای بازگشت داده نشد");
        }
        return objects.get(0);
    }

    /**
     * دریافت اشیاء مرتبط از طریق روابط تعریف شده
     * عملیات: core/get_related
     *
     * @param className     نام کلاس شیء مبدا
     * @param key           شناسه شیء مبدا
     * @param relation      نام رابطه (مثال: "impacts", "depends on")
     * @param relatedClass  کلاس مرتبط هدف
     * @param depth         عمق جستجو (پیش‌فرض: 1)
     */
    public List<ITopObject> getRelatedObjects(String className, Object key, String relation,
                                              String relatedClass, int depth,
                                              String outputFields) throws ITopApiException {
        ObjectNode payload = objectMapper.createObjectNode();
        payload.put("operation", OP_CORE_GET_RELATED);
        payload.put("class", className);
        setKeyOnPayload(payload, key);
        payload.put("relation", relation);
        payload.put("related_class", relatedClass);
        if (depth > 0) {
            payload.put("depth", depth);
        }
        payload.put("output_fields", outputFields != null ? outputFields : OUTPUT_FIELDS_ALL);

        JsonNode response = executeRequest(payload);
        return parseObjectsFromResponse(response);
    }

    // ================================================================
    //  ۲. ماژول درخواست کاربر (User Request Management)
    // ================================================================

    /**
     * ایجاد درخواست کاربر جدید
     *
     * @param orgId              شناسه سازمان (id یا OQL)
     * @param callerId           شناسه تماس‌گیرنده (id یا Map با name/first_name)
     * @param title              عنوان درخواست
     * @param description        توضیحات (HTML از iTop 2.3+)
     * @param serviceId          شناسه سرویس
     * @param serviceSubcategoryId شناسه زیر دسته سرویس
     * @param priority           اولویت: 1=Critical, 2=High, 3=Medium, 4=Low
     * @param teamId             شناسه تیم (اختیاری)
     * @param agentId            شناسه کارشناس (اختیاری)
     * @param origin             منشأ: "portal","mail","phone","monitoring","other"
     * @param publicLog          پیام‌های لاگ عمومی (اختیاری)
     * @param privateLog         پیام‌های لاگ خصوصی (اختیاری)
     */
    public ITopObject createUserRequest(Object orgId, Object callerId, String title,
                                        String description, Object serviceId,
                                        Object serviceSubcategoryId, String priority,
                                        Object teamId, Object agentId, String origin,
                                        String publicLog, String privateLog) throws ITopApiException {
        Map<String, Object> fields = new LinkedHashMap<>();
        fields.put("org_id", orgId);
        fields.put("caller_id", callerId);
        fields.put("title", title);
        fields.put("description", description);
        fields.put("service_id", serviceId);
        fields.put("servicesubcategory_id", serviceSubcategoryId);
        fields.put("priority", priority);
        if (teamId != null)  fields.put("team_id", teamId);
        if (agentId != null) fields.put("agent_id", agentId);
        if (origin != null)  fields.put("origin", origin);
        if (publicLog != null)  fields.put("public_log", publicLog);
        if (privateLog != null) fields.put("private_log", privateLog);

        return createObject(CLASS_USER_REQUEST, fields,
                "درخواست کاربر از طریق Java API ایجاد شد",
                "id,ref,friendlyname,status,tto_dt,ttr_dt");
    }

    /** تخصیص درخواست به تیم/کارشناس */
    public ITopObject assignUserRequest(int requestId, Object teamId, Object agentId,
                                        String publicLog) throws ITopApiException {
        Map<String, Object> fields = new LinkedHashMap<>();
        if (teamId != null)   fields.put("team_id", teamId);
        if (agentId != null)  fields.put("agent_id", agentId);
        if (publicLog != null) fields.put("public_log", publicLog);

        return applyStimulus(CLASS_USER_REQUEST, requestId, STIMULUS_UR_ASSIGN,
                fields, "تخصیص درخواست", "id,ref,status,agent_id,team_id");
    }

    /** ارجاع درخواست به سطح بالاتر (Escalate) */
    public ITopObject escalateUserRequest(int requestId, Object teamId,
                                          String reason) throws ITopApiException {
        Map<String, Object> fields = new LinkedHashMap<>();
        if (teamId != null) fields.put("team_id", teamId);
        if (reason != null) fields.put("public_log", reason);

        return applyStimulus(CLASS_USER_REQUEST, requestId, STIMULUS_UR_ESCALATE,
                fields, "ارجاع درخواست", "id,ref,status,team_id");
    }

    /** حل درخواست */
    public ITopObject resolveUserRequest(int requestId, String solution,
                                         String privateNote) throws ITopApiException {
        Map<String, Object> fields = new LinkedHashMap<>();
        if (solution != null)    fields.put("solution", solution);
        if (privateNote != null) fields.put("private_log", privateNote);

        return applyStimulus(CLASS_USER_REQUEST, requestId, STIMULUS_UR_RESOLVE,
                fields, "حل درخواست", "id,ref,status,resolution_dt");
    }

    /** بستن درخواست */
    public ITopObject closeUserRequest(int requestId, String closureComment) throws ITopApiException {
        Map<String, Object> fields = new LinkedHashMap<>();
        if (closureComment != null) fields.put("public_log", closureComment);

        return applyStimulus(CLASS_USER_REQUEST, requestId, STIMULUS_UR_CLOSE,
                fields, "بستن درخواست", "id,ref,status,close_dt");
    }

    /** بازگشایی درخواست بسته شده */
    public ITopObject reopenUserRequest(int requestId, String reason) throws ITopApiException {
        Map<String, Object> fields = new LinkedHashMap<>();
        if (reason != null) fields.put("public_log", reason);

        return applyStimulus(CLASS_USER_REQUEST, requestId, STIMULUS_UR_REOPEN,
                fields, "بازگشایی درخواست", "id,ref,status");
    }

    /** ارسال درخواست برای تایید */
    public ITopObject submitUserRequestForApproval(int requestId) throws ITopApiException {
        return applyStimulus(CLASS_USER_REQUEST, requestId, STIMULUS_UR_WAIT_REPL,
                null, "ارسال برای تایید", "id,ref,status");
    }

    /** تایید درخواست */
    public ITopObject approveUserRequest(int requestId, String comment) throws ITopApiException {
        Map<String, Object> fields = new LinkedHashMap<>();
        if (comment != null) fields.put("public_log", comment);

        return applyStimulus(CLASS_USER_REQUEST, requestId, STIMULUS_UR_APPROVE,
                fields, "تایید درخواست", "id,ref,status");
    }

    /** رد درخواست */
    public ITopObject rejectUserRequest(int requestId, String reason) throws ITopApiException {
        Map<String, Object> fields = new LinkedHashMap<>();
        if (reason != null) fields.put("public_log", reason);

        return applyStimulus(CLASS_USER_REQUEST, requestId, STIMULUS_UR_REJECT,
                fields, "رد درخواست", "id,ref,status");
    }

    /** دریافت درخواست‌های یک سازمان */
    public List<ITopObject> getUserRequestsByOrg(int orgId, String status) throws ITopApiException {
        String oql = String.format("SELECT UserRequest WHERE org_id = %d", orgId);
        if (status != null && !status.isEmpty()) {
            oql += String.format(" AND status = '%s'", status);
        }
        return getObjectsByOQL(CLASS_USER_REQUEST, oql,
                "id,ref,title,status,priority,agent_id,team_id,tto_dt,ttr_dt,caller_id");
    }

    /** جستجوی درخواست‌های در معرض نقض SLA */
    public List<ITopObject> getUserRequestsNearingSLABreach(int orgId) throws ITopApiException {
        String oql = String.format(
                "SELECT UserRequest WHERE org_id = %d " +
                "AND status NOT IN ('resolved','closed') " +
                "AND ttr_dt IS NOT NULL", orgId);
        return getObjectsByOQL(CLASS_USER_REQUEST, oql,
                "id,ref,title,status,priority,tto_dt,ttr_dt,tto_left_percent,ttr_left_percent");
    }

    /** افزودن یادداشت عمومی به درخواست */
    public ITopObject addPublicLogToUserRequest(int requestId, String message) throws ITopApiException {
        Map<String, Object> fields = new LinkedHashMap<>();
        fields.put("public_log", message);
        return updateObject(CLASS_USER_REQUEST, requestId, fields,
                "افزودن یادداشت عمومی", "id,ref,status");
    }

    /** افزودن یادداشت خصوصی به درخواست */
    public ITopObject addPrivateLogToUserRequest(int requestId, String message) throws ITopApiException {
        Map<String, Object> fields = new LinkedHashMap<>();
        fields.put("private_log", message);
        return updateObject(CLASS_USER_REQUEST, requestId, fields,
                "افزودن یادداشت خصوصی", "id,ref,status");
    }

    // ================================================================
    //  ۳. ماژول حوادث (Incident Management)
    // ================================================================

    /**
     * ایجاد حادثه جدید
     *
     * @param orgId         سازمان
     * @param callerId      تماس‌گیرنده
     * @param title         عنوان
     * @param description   توضیحات
     * @param serviceId     سرویس
     * @param impact        تاثیر: 1=Department, 2=Service, 3=Person
     * @param urgency       فوریت: 1=Critical, 2=High, 3=Medium, 4=Low
     * @param priority      اولویت (معمولا محاسبه‌ای)
     * @param ciList        لیست CI های تاثیرپذیر
     */
    public ITopObject createIncident(Object orgId, Object callerId, String title,
                                     String description, Object serviceId,
                                     String impact, String urgency, String priority,
                                     List<Map<String, Object>> ciList) throws ITopApiException {
        Map<String, Object> fields = new LinkedHashMap<>();
        fields.put("org_id", orgId);
        fields.put("caller_id", callerId);
        fields.put("title", title);
        fields.put("description", description);
        if (serviceId != null) fields.put("service_id", serviceId);
        fields.put("impact", impact);
        fields.put("urgency", urgency);
        fields.put("priority", priority);
        if (ciList != null && !ciList.isEmpty()) {
            fields.put("functionalcis_list", ciList);
        }

        return createObject(CLASS_INCIDENT, fields,
                "حادثه از طریق Java API ایجاد شد",
                "id,ref,friendlyname,status,tto_dt,ttr_dt");
    }

    /** تخصیص حادثه */
    public ITopObject assignIncident(int incidentId, Object teamId, Object agentId,
                                     String log) throws ITopApiException {
        Map<String, Object> fields = new LinkedHashMap<>();
        if (teamId != null)  fields.put("team_id", teamId);
        if (agentId != null) fields.put("agent_id", agentId);
        if (log != null)     fields.put("public_log", log);

        return applyStimulus(CLASS_INCIDENT, incidentId, STIMULUS_INC_ASSIGN,
                fields, "تخصیص حادثه", "id,ref,status,agent_id,team_id");
    }

    /** حل حادثه */
    public ITopObject resolveIncident(int incidentId, String solution) throws ITopApiException {
        Map<String, Object> fields = new LinkedHashMap<>();
        if (solution != null) fields.put("solution", solution);

        return applyStimulus(CLASS_INCIDENT, incidentId, STIMULUS_INC_RESOLVE,
                fields, "حل حادثه", "id,ref,status,resolution_dt");
    }

    /** اتصال حادثه به مشکل */
    public ITopObject linkIncidentToProblem(int incidentId, int problemId) throws ITopApiException {
        Map<String, Object> fields = new LinkedHashMap<>();
        fields.put("problem_id", problemId);
        return updateObject(CLASS_INCIDENT, incidentId, fields,
                "اتصال حادثه به مشکل", "id,ref,status,problem_id");
    }

    /** دریافت CIهای تاثیرپذیر از یک حادثه */
    public List<ITopObject> getImpactedCIsByIncident(int incidentId) throws ITopApiException {
        return getRelatedObjects(CLASS_INCIDENT, incidentId, "impacts",
                CLASS_SERVER, 3, "id,name,status,friendlyname");
    }

    // ================================================================
    //  ۴. ماژول مدیریت تغییرات (Change Management)
    // ================================================================

    /**
     * ایجاد تغییر عادی (Normal Change)
     *
     * @param orgId           سازمان
     * @param title           عنوان
     * @param description     توضیحات
     * @param reason          دلیل تغییر
     * @param impactedServices سرویس‌های تاثیرپذیر
     * @param plannedStart    تاریخ شروع برنامه‌ریزی شده (YYYY-MM-DD HH:mm:ss)
     * @param plannedEnd      تاریخ پایان برنامه‌ریزی شده
     * @param changeManagerId مدیر تغییر
     */
    public ITopObject createNormalChange(Object orgId, String title, String description,
                                         String reason, Object changeManagerId,
                                         String plannedStart, String plannedEnd,
                                         Object teamId) throws ITopApiException {
        Map<String, Object> fields = new LinkedHashMap<>();
        fields.put("org_id", orgId);
        fields.put("title", title);
        fields.put("description", description);
        fields.put("reason", reason);
        if (changeManagerId != null) fields.put("changemanager_id", changeManagerId);
        if (plannedStart != null)    fields.put("plannedstart", plannedStart);
        if (plannedEnd != null)      fields.put("plannedend", plannedEnd);
        if (teamId != null)          fields.put("team_id", teamId);

        return createObject(CLASS_NORMAL_CHANGE, fields,
                "تغییر عادی از طریق Java API ایجاد شد",
                "id,ref,friendlyname,status,plannedstart,plannedend");
    }

    /** ایجاد تغییر اضطراری (Emergency Change) */
    public ITopObject createEmergencyChange(Object orgId, String title, String description,
                                             String reason, Object teamId) throws ITopApiException {
        Map<String, Object> fields = new LinkedHashMap<>();
        fields.put("org_id", orgId);
        fields.put("title", title);
        fields.put("description", description);
        fields.put("reason", reason);
        if (teamId != null) fields.put("team_id", teamId);

        return createObject(CLASS_EMERGENCY_CHANGE, fields,
                "تغییر اضطراری از طریق Java API ایجاد شد",
                "id,ref,friendlyname,status");
    }

    /** ایجاد تغییر روتین (Routine Change) */
    public ITopObject createRoutineChange(Object orgId, String title, String description,
                                           Object teamId) throws ITopApiException {
        Map<String, Object> fields = new LinkedHashMap<>();
        fields.put("org_id", orgId);
        fields.put("title", title);
        fields.put("description", description);
        if (teamId != null) fields.put("team_id", teamId);

        return createObject(CLASS_ROUTINE_CHANGE, fields,
                "تغییر روتین از طریق Java API ایجاد شد",
                "id,ref,friendlyname,status");
    }

    /** ثبت تغییر برای بررسی */
    public ITopObject submitChange(String changeClass, int changeId) throws ITopApiException {
        return applyStimulus(changeClass, changeId, STIMULUS_CHG_SUBMIT,
                null, "ثبت تغییر برای بررسی", "id,ref,status");
    }

    /** تایید تغییر */
    public ITopObject approveChange(String changeClass, int changeId,
                                    String comment) throws ITopApiException {
        Map<String, Object> fields = new LinkedHashMap<>();
        if (comment != null) fields.put("public_log", comment);

        return applyStimulus(changeClass, changeId, STIMULUS_CHG_APPROVE,
                fields, "تایید تغییر", "id,ref,status");
    }

    /** رد تغییر */
    public ITopObject rejectChange(String changeClass, int changeId,
                                   String reason) throws ITopApiException {
        Map<String, Object> fields = new LinkedHashMap<>();
        if (reason != null) fields.put("public_log", reason);

        return applyStimulus(changeClass, changeId, STIMULUS_CHG_REJECT,
                fields, "رد تغییر", "id,ref,status");
    }

    /** برنامه‌ریزی تغییر */
    public ITopObject planChange(String changeClass, int changeId,
                                 String plannedStart, String plannedEnd,
                                 Object implementorId) throws ITopApiException {
        Map<String, Object> fields = new LinkedHashMap<>();
        if (plannedStart != null)   fields.put("plannedstart", plannedStart);
        if (plannedEnd != null)     fields.put("plannedend", plannedEnd);
        if (implementorId != null)  fields.put("implementor_id", implementorId);

        return applyStimulus(changeClass, changeId, STIMULUS_CHG_PLAN,
                fields, "برنامه‌ریزی تغییر", "id,ref,status,plannedstart,plannedend");
    }

    /** اجرای تغییر */
    public ITopObject implementChange(String changeClass, int changeId,
                                      String log) throws ITopApiException {
        Map<String, Object> fields = new LinkedHashMap<>();
        if (log != null) fields.put("public_log", log);

        return applyStimulus(changeClass, changeId, STIMULUS_CHG_IMPLEMENT,
                fields, "اجرای تغییر", "id,ref,status,start_date");
    }

    /** بستن تغییر */
    public ITopObject closeChange(String changeClass, int changeId,
                                  String closureNote) throws ITopApiException {
        Map<String, Object> fields = new LinkedHashMap<>();
        if (closureNote != null) fields.put("public_log", closureNote);

        return applyStimulus(changeClass, changeId, STIMULUS_CHG_CLOSE,
                fields, "بستن تغییر", "id,ref,status,end_date");
    }

    /** اتصال تغییر به درخواست‌های کاربری */
    public ITopObject linkChangeToUserRequest(int changeId, int requestId) throws ITopApiException {
        Map<String, Object> fields = new LinkedHashMap<>();
        List<Map<String, Object>> requestList = new ArrayList<>();
        Map<String, Object> requestEntry = new LinkedHashMap<>();
        requestEntry.put("userrequest_id", requestId);
        requestList.add(requestEntry);
        fields.put("related_request_list", requestList);

        return updateObject(CLASS_NORMAL_CHANGE, changeId, fields,
                "اتصال تغییر به درخواست", "id,ref,status");
    }

    // ================================================================
    //  ۵. ماژول مدیریت مشکلات (Problem Management)
    // ================================================================

    /** ایجاد مشکل جدید */
    public ITopObject createProblem(Object orgId, Object callerId, String title,
                                    String description, Object serviceId,
                                    String impact, String urgency, String priority,
                                    Object teamId) throws ITopApiException {
        Map<String, Object> fields = new LinkedHashMap<>();
        fields.put("org_id", orgId);
        if (callerId != null) fields.put("caller_id", callerId);
        fields.put("title", title);
        fields.put("description", description);
        if (serviceId != null) fields.put("service_id", serviceId);
        fields.put("impact", impact);
        fields.put("urgency", urgency);
        fields.put("priority", priority);
        if (teamId != null) fields.put("team_id", teamId);

        return createObject(CLASS_PROBLEM, fields,
                "مشکل از طریق Java API ایجاد شد",
                "id,ref,friendlyname,status");
    }

    /** تخصیص مشکل */
    public ITopObject assignProblem(int problemId, Object teamId, Object agentId) throws ITopApiException {
        Map<String, Object> fields = new LinkedHashMap<>();
        if (teamId != null)  fields.put("team_id", teamId);
        if (agentId != null) fields.put("agent_id", agentId);

        return applyStimulus(CLASS_PROBLEM, problemId, STIMULUS_PRB_ASSIGN,
                fields, "تخصیص مشکل", "id,ref,status,team_id,agent_id");
    }

    /** ثبت خطای شناخته‌شده (Known Error) */
    public ITopObject createKnownError(Object orgId, String name, String description,
                                       String workaround, int problemId) throws ITopApiException {
        Map<String, Object> fields = new LinkedHashMap<>();
        fields.put("org_id", orgId);
        fields.put("name", name);
        fields.put("description", description);
        if (workaround != null) fields.put("workaround", workaround);
        fields.put("problem_id", problemId);

        return createObject(CLASS_KNOWN_ERROR, fields,
                "خطای شناخته‌شده از طریق Java API ایجاد شد",
                "id,name,friendlyname,status");
    }

    /** دریافت حوادث مرتبط با یک مشکل */
    public List<ITopObject> getIncidentsByProblem(int problemId) throws ITopApiException {
        String oql = String.format("SELECT Incident WHERE problem_id = %d", problemId);
        return getObjectsByOQL(CLASS_INCIDENT, oql, "id,ref,title,status,priority");
    }

    // ================================================================
    //  ۶. ماژول SLA / OLA / SLT
    // ================================================================

    /** ایجاد SLA جدید */
    public ITopObject createSLA(String name, Object orgId, String description,
                                Object serviceId, Object deliveryModelId) throws ITopApiException {
        Map<String, Object> fields = new LinkedHashMap<>();
        fields.put("name", name);
        fields.put("org_id", orgId);
        if (description != null)    fields.put("description", description);
        if (serviceId != null)      fields.put("service_id", serviceId);
        if (deliveryModelId != null) fields.put("deliverymodel_id", deliveryModelId);

        return createObject(CLASS_SLA, fields, "ایجاد SLA", "id,name,friendlyname");
    }

    /** ایجاد SLT (Service Level Target) */
    public ITopObject createSLT(String name, String metric, String requestType,
                                String priority, int value, String unit) throws ITopApiException {
        Map<String, Object> fields = new LinkedHashMap<>();
        fields.put("name", name);
        fields.put("metric", metric);        // TTO یا TTR
        fields.put("request_type", requestType); // UserRequest یا Incident
        fields.put("priority", priority);    // critical, high, medium, low
        fields.put("value", value);
        fields.put("unit", unit);            // دقیقه، ساعت، روز

        return createObject(CLASS_SLT, fields, "ایجاد SLT", "id,name,friendlyname");
    }

    /** دریافت تمام SLA های یک سازمان */
    public List<ITopObject> getSLAsByOrg(int orgId) throws ITopApiException {
        String oql = String.format("SELECT SLA WHERE org_id = %d", orgId);
        return getObjectsByOQL(CLASS_SLA, oql, "id,name,description,service_id,deliverymodel_id");
    }

    /** دریافت SLTهای یک SLA */
    public List<ITopObject> getSLTsBySLA(int slaId) throws ITopApiException {
        String oql = String.format(
                "SELECT SLT AS slt JOIN lnkSLAToSLT AS l ON l.slt_id=slt.id WHERE l.sla_id = %d",
                slaId);
        return getObjectsByOQL(CLASS_SLT, oql, "id,name,metric,request_type,priority,value,unit");
    }

    /** دریافت گزارش نقض SLA (تیکت‌های نقض شده) */
    public List<ITopObject> getSLABreachedTickets(String ticketClass, int orgId) throws ITopApiException {
        String oql = String.format(
                "SELECT %s WHERE org_id = %d AND ttr_overrun > 0 AND status NOT IN ('closed')",
                ticketClass, orgId);
        return getObjectsByOQL(ticketClass, oql,
                "id,ref,title,status,priority,ttr_dt,ttr_overrun,agent_id");
    }

    /** دریافت OLA برای یک تیم (نیاز به نصب اکستنشن OLA دارد) */
    public List<ITopObject> getOLAsByTeam(int teamId) throws ITopApiException {
        String oql = String.format(
                "SELECT OLA AS ola JOIN lnkOLAToTeam AS l ON l.ola_id=ola.id WHERE l.team_id = %d",
                teamId);
        return getObjectsByOQL(CLASS_OLA, oql, "id,name,description");
    }

    // ================================================================
    //  ۷. ماژول مدیریت پروژه (Project Management + Gantt)
    // ================================================================

    /**
     * ایجاد پروژه جدید
     *
     * @param name           نام پروژه
     * @param orgId          سازمان
     * @param description    توضیحات
     * @param startDate      تاریخ شروع (YYYY-MM-DD)
     * @param endDate        تاریخ پایان
     * @param status         وضعیت: active, inactive, closed
     * @param budgetId       شناسه بودجه (اختیاری)
     */
    public ITopObject createProject(String name, Object orgId, String description,
                                    String startDate, String endDate, String status,
                                    Object budgetId) throws ITopApiException {
        Map<String, Object> fields = new LinkedHashMap<>();
        fields.put("name", name);
        fields.put("org_id", orgId);
        if (description != null) fields.put("description", description);
        if (startDate != null)   fields.put("start_date", startDate);
        if (endDate != null)     fields.put("end_date", endDate);
        if (status != null)      fields.put("status", status);
        if (budgetId != null)    fields.put("budget_id", budgetId);

        return createObject(CLASS_PROJECT, fields, "ایجاد پروژه", "id,name,friendlyname,status");
    }

    /**
     * ایجاد وظیفه پروژه (Project Task) - مبنای نمودار Gantt
     *
     * @param projectId      شناسه پروژه
     * @param name           نام وظیفه
     * @param description    توضیحات
     * @param contactId      مسئول اجرا
     * @param plannedStart   شروع برنامه‌ریزی شده
     * @param plannedEnd     پایان برنامه‌ریزی شده
     * @param percentDone    درصد پیشرفت (0-100)
     * @param status         وضعیت: new, ongoing, completed, rejected
     * @param parentTaskId   شناسه وظیفه پدر (برای سلسله‌مراتب Gantt)
     */
    public ITopObject createProjectTask(int projectId, String name, String description,
                                        Object contactId, String plannedStart, String plannedEnd,
                                        int percentDone, String status,
                                        Integer parentTaskId) throws ITopApiException {
        Map<String, Object> fields = new LinkedHashMap<>();
        fields.put("project_id", projectId);
        fields.put("name", name);
        if (description != null)  fields.put("description", description);
        if (contactId != null)    fields.put("contact_id", contactId);
        if (plannedStart != null) fields.put("planned_start", plannedStart);
        if (plannedEnd != null)   fields.put("planned_end", plannedEnd);
        fields.put("percent_done", percentDone);
        if (status != null)       fields.put("status", status);
        if (parentTaskId != null) fields.put("parent_id", parentTaskId);

        return createObject(CLASS_PROJECT_TASK, fields, "ایجاد وظیفه پروژه",
                "id,name,status,percent_done,planned_start,planned_end,parent_id");
    }

    /** بروزرسانی پیشرفت وظیفه (برای Gantt) */
    public ITopObject updateTaskProgress(int taskId, int percentDone,
                                         String status, String actualStart,
                                         String actualEnd) throws ITopApiException {
        Map<String, Object> fields = new LinkedHashMap<>();
        fields.put("percent_done", percentDone);
        if (status != null)      fields.put("status", status);
        if (actualStart != null) fields.put("start_date", actualStart);
        if (actualEnd != null)   fields.put("end_date", actualEnd);

        return updateObject(CLASS_PROJECT_TASK, taskId, fields,
                "بروزرسانی پیشرفت وظیفه",
                "id,name,status,percent_done,start_date,end_date");
    }

    /** دریافت تمام وظایف یک پروژه (برای رسم Gantt) */
    public List<ITopObject> getProjectTasks(int projectId) throws ITopApiException {
        String oql = String.format("SELECT ProjectTask WHERE project_id = %d", projectId);
        return getObjectsByOQL(CLASS_PROJECT_TASK, oql,
                "id,name,status,percent_done,planned_start,planned_end," +
                "start_date,end_date,parent_id,contact_id");
    }

    /** دریافت پروژه‌های فعال یک سازمان */
    public List<ITopObject> getActiveProjects(int orgId) throws ITopApiException {
        String oql = String.format(
                "SELECT Project WHERE org_id = %d AND status = 'active'", orgId);
        return getObjectsByOQL(CLASS_PROJECT, oql,
                "id,name,status,start_date,end_date,description,budget_id");
    }

    /** دریافت داده‌های کامل Gantt یک پروژه */
    public GanttData getProjectGanttData(int projectId) throws ITopApiException {
        ITopObject project = getObjectById(CLASS_PROJECT, projectId,
                "id,name,status,start_date,end_date,description");
        List<ITopObject> tasks = getProjectTasks(projectId);
        return new GanttData(project, tasks);
    }

    // ================================================================
    //  ۸. ماژول مرکز هزینه (Cost Center Management)
    // ================================================================

    /** ایجاد مرکز هزینه */
    public ITopObject createCostCenter(String name, Object orgId, String code,
                                        String description,
                                        Object managerId) throws ITopApiException {
        Map<String, Object> fields = new LinkedHashMap<>();
        fields.put("name", name);
        fields.put("org_id", orgId);
        if (code != null)        fields.put("code", code);
        if (description != null) fields.put("description", description);
        if (managerId != null)   fields.put("manager_id", managerId);

        return createObject(CLASS_COST_CENTER, fields,
                "ایجاد مرکز هزینه", "id,name,code,friendlyname");
    }

    /** دریافت تمام مراکز هزینه یک سازمان */
    public List<ITopObject> getCostCentersByOrg(int orgId) throws ITopApiException {
        String oql = String.format("SELECT CostCenter WHERE org_id = %d", orgId);
        return getObjectsByOQL(CLASS_COST_CENTER, oql, "id,name,code,description,manager_id");
    }

    /** ایجاد بودجه برای مرکز هزینه */
    public ITopObject createBudget(String name, int costCenterId, String year,
                                    double amount, String currency,
                                    String description) throws ITopApiException {
        Map<String, Object> fields = new LinkedHashMap<>();
        fields.put("name", name);
        fields.put("cost_center_id", costCenterId);
        fields.put("year", year);
        fields.put("amount", amount);
        if (currency != null)    fields.put("currency", currency);
        if (description != null) fields.put("description", description);

        return createObject(CLASS_BUDGET, fields, "ایجاد بودجه", "id,name,amount,year");
    }

    /** اتصال CI به مرکز هزینه */
    public ITopObject linkCIToCostCenter(String ciClass, int ciId, int costCenterId) throws ITopApiException {
        Map<String, Object> fields = new LinkedHashMap<>();
        fields.put("cost_center_id", costCenterId);
        return updateObject(ciClass, ciId, fields,
                "اتصال CI به مرکز هزینه", "id,name,cost_center_id");
    }

    // ================================================================
    //  ۹. ماژول CMDB
    // ================================================================

    /** ایجاد CI سرور */
    public ITopObject createServer(String name, Object orgId, String serialNumber,
                                   String manufacturer, String model,
                                   String ipAddress, String status,
                                   Object rackId, Object locationId) throws ITopApiException {
        Map<String, Object> fields = new LinkedHashMap<>();
        fields.put("name", name);
        fields.put("org_id", orgId);
        if (serialNumber != null)  fields.put("serialnumber", serialNumber);
        if (manufacturer != null)  fields.put("brand_id", manufacturer);
        if (model != null)         fields.put("model_id", model);
        if (ipAddress != null)     fields.put("managementip", ipAddress);
        if (status != null)        fields.put("status", status);
        if (rackId != null)        fields.put("rack_id", rackId);
        if (locationId != null)    fields.put("location_id", locationId);

        return createObject(CLASS_SERVER, fields, "ایجاد سرور در CMDB",
                "id,name,status,managementip,friendlyname");
    }

    /** دریافت CI های تاثیرگذار بر یک سرویس */
    public List<ITopObject> getCIsByService(int serviceId) throws ITopApiException {
        String oql = String.format(
                "SELECT FunctionalCI AS ci " +
                "JOIN lnkFunctionalCIToService AS l ON l.functionalci_id=ci.id " +
                "WHERE l.service_id = %d", serviceId);
        return getObjectsByOQL("FunctionalCI", oql,
                "id,name,finalclass,status,org_id");
    }

    /** دریافت تاثیر یک CI بر سرویس‌ها */
    public List<ITopObject> getServicesByCIImpact(String ciClass, int ciId) throws ITopApiException {
        return getRelatedObjects(ciClass, ciId, "impacts", CLASS_SERVICE, 5,
                "id,name,status,description");
    }

    /** جستجوی CI با وضعیت مشخص */
    public List<ITopObject> getCIsByStatus(String ciClass, String status,
                                            int orgId) throws ITopApiException {
        String oql = String.format("SELECT %s WHERE org_id = %d AND status = '%s'",
                ciClass, orgId, status);
        return getObjectsByOQL(ciClass, oql, "id,name,status,org_id,location_id,friendlyname");
    }

    // ================================================================
    //  ۱۰. مدیریت سازمان‌ها، کاربران و مخاطبین
    // ================================================================

    /** ایجاد سازمان */
    public ITopObject createOrganization(String name, Object parentId,
                                          String code, String status) throws ITopApiException {
        Map<String, Object> fields = new LinkedHashMap<>();
        fields.put("name", name);
        if (parentId != null) fields.put("parent_id", parentId);
        if (code != null)     fields.put("code", code);
        if (status != null)   fields.put("status", status);

        return createObject(CLASS_ORGANIZATION, fields, "ایجاد سازمان", "id,name,friendlyname");
    }

    /** ایجاد کاربر محلی */
    public ITopObject createLocalUser(String login, String password, Object personId,
                                       String language, List<Integer> profileIds) throws ITopApiException {
        Map<String, Object> fields = new LinkedHashMap<>();
        fields.put("login", login);
        fields.put("password", password);
        fields.put("contactid", personId);
        if (language != null) fields.put("language", language);

        if (profileIds != null && !profileIds.isEmpty()) {
            List<Map<String, Object>> profileList = new ArrayList<>();
            for (int profileId : profileIds) {
                Map<String, Object> entry = new LinkedHashMap<>();
                entry.put("profileid", profileId);
                profileList.add(entry);
            }
            fields.put("profile_list", profileList);
        }

        return createObject(CLASS_USER_LOCAL, fields, "ایجاد کاربر", "id,login,friendlyname");
    }

    /** ایجاد شخص (Person) */
    public ITopObject createPerson(String firstName, String lastName, Object orgId,
                                    String email, String phone,
                                    Object teamId, Object locationId) throws ITopApiException {
        Map<String, Object> fields = new LinkedHashMap<>();
        fields.put("first_name", firstName);
        fields.put("name", lastName);
        fields.put("org_id", orgId);
        if (email != null)      fields.put("email", email);
        if (phone != null)      fields.put("phone", phone);
        if (teamId != null)     fields.put("team_id", teamId);
        if (locationId != null) fields.put("location_id", locationId);

        return createObject(CLASS_PERSON, fields, "ایجاد شخص",
                "id,friendlyname,email,org_id");
    }

    // ================================================================
    //  ۱۱. مدیریت پیوست‌ها (Attachment Management)
    // ================================================================

    /**
     * آپلود پیوست به یک شیء iTop
     *
     * @param ticketClass  کلاس شیء (مثال: "UserRequest")
     * @param ticketId     شناسه شیء
     * @param fileName     نام فایل
     * @param mimeType     نوع MIME فایل
     * @param base64Data   محتوای فایل در قالب Base64
     */
    public ITopObject addAttachment(String ticketClass, int ticketId, String fileName,
                                    String mimeType, String base64Data) throws ITopApiException {
        Map<String, Object> fields = new LinkedHashMap<>();
        fields.put("item_class", ticketClass);
        fields.put("item_id", ticketId);

        Map<String, Object> fileData = new LinkedHashMap<>();
        fileData.put("data", base64Data);
        fileData.put("filename", fileName);
        fileData.put("mimetype", mimeType);
        fields.put("contents", fileData);

        return createObject(CLASS_ATTACHMENT, fields,
                "آپلود پیوست", "id,item_id,item_class,contents");
    }

    /** دریافت لیست پیوست‌های یک شیء */
    public List<ITopObject> getAttachments(String itemClass, int itemId) throws ITopApiException {
        String oql = String.format(
                "SELECT Attachment WHERE item_class = '%s' AND item_id = %d",
                itemClass, itemId);
        return getObjectsByOQL(CLASS_ATTACHMENT, oql, "id,item_id,item_class,contents");
    }

    /** حذف پیوست */
    public ITopDeleteResult deleteAttachment(int attachmentId) throws ITopApiException {
        return deleteObject(CLASS_ATTACHMENT, attachmentId, "حذف پیوست", false);
    }

    // ================================================================
    //  ۱۲. مدیریت سرویس‌ها و کاتالوگ
    // ================================================================

    /** ایجاد سرویس */
    public ITopObject createService(String name, Object orgId, Object serviceFamilyId,
                                    String description, String status) throws ITopApiException {
        Map<String, Object> fields = new LinkedHashMap<>();
        fields.put("name", name);
        fields.put("org_id", orgId);
        if (serviceFamilyId != null) fields.put("servicefamily_id", serviceFamilyId);
        if (description != null)     fields.put("description", description);
        if (status != null)          fields.put("status", status);

        return createObject(CLASS_SERVICE, fields, "ایجاد سرویس", "id,name,status,friendlyname");
    }

    /** ایجاد دسته‌بندی سرویس */
    public ITopObject createServiceFamily(String name, Object orgId,
                                           String description) throws ITopApiException {
        Map<String, Object> fields = new LinkedHashMap<>();
        fields.put("name", name);
        fields.put("org_id", orgId);
        if (description != null) fields.put("description", description);

        return createObject(CLASS_SERVICE_FAMILY, fields,
                "ایجاد دسته‌بندی سرویس", "id,name,friendlyname");
    }

    /** ایجاد زیر دسته سرویس */
    public ITopObject createServiceSubcategory(String name, Object serviceId,
                                                String description) throws ITopApiException {
        Map<String, Object> fields = new LinkedHashMap<>();
        fields.put("name", name);
        fields.put("service_id", serviceId);
        if (description != null) fields.put("description", description);

        return createObject(CLASS_SERVICE_SUBFAMILY, fields,
                "ایجاد زیر دسته سرویس", "id,name,service_id,friendlyname");
    }

    // ================================================================
    //  ۱۳. عملیات‌های پیشرفته OQL
    // ================================================================

    /**
     * اجرای OQL سفارشی روی هر کلاس
     * @param oqlQuery  کوئری OQL iTop
     *                  مثال: SELECT UserRequest WHERE status = 'new' AND priority = '1'
     */
    public List<ITopObject> executeOQL(String className, String oqlQuery,
                                        String outputFields) throws ITopApiException {
        return getObjectsByOQL(className, oqlQuery, outputFields);
    }

    /**
     * شمارش اشیاء با OQL (از طریق دریافت و شمارش)
     */
    public int countObjects(String className, String oqlQuery) throws ITopApiException {
        List<ITopObject> objects = getObjectsByOQL(className, oqlQuery, "id");
        return objects.size();
    }

    /**
     * بروزرسانی گروهی اشیاء با OQL
     * @param className   نام کلاس
     * @param oqlQuery    کوئری OQL برای شناسایی اشیاء هدف
     * @param fields      فیلدهای بروزرسانی
     */
    public List<ITopObject> bulkUpdate(String className, String oqlQuery,
                                        Map<String, Object> fields,
                                        String comment) throws ITopApiException {
        List<ITopObject> targets = getObjectsByOQL(className, oqlQuery, "id");
        List<ITopObject> updated = new ArrayList<>();
        for (ITopObject obj : targets) {
            updated.add(updateObject(className, obj.getId(), fields, comment, "id,friendlyname"));
        }
        return updated;
    }

    // ================================================================
    //  ۱۴. متدهای کمکی داخلی
    // ================================================================

    /** اجرای درخواست HTTP POST به REST API */
    private JsonNode executeRequest(ObjectNode payload) throws ITopApiException {
        String url = baseUrl + "webservices/rest.php?version=" + apiVersion;

        try {
            HttpPost httpPost = new HttpPost(url);
            MultipartEntityBuilder builder = MultipartEntityBuilder.create();

            // احراز هویت
            if (authToken != null && !authToken.isEmpty()) {
                builder.addTextBody("auth_token", authToken, ContentType.TEXT_PLAIN);
            } else {
                if (authUser != null)     builder.addTextBody("auth_user", authUser, ContentType.TEXT_PLAIN);
                if (authPassword != null) builder.addTextBody("auth_pwd", authPassword, ContentType.TEXT_PLAIN);
            }

            String jsonData = objectMapper.writeValueAsString(payload);
            builder.addTextBody("json_data", jsonData, ContentType.TEXT_PLAIN.withCharset(StandardCharsets.UTF_8));
            httpPost.setEntity(builder.build());

            log.debug("iTop API Request to {}: {}", url, jsonData);

            try (CloseableHttpResponse response = httpClient.execute(httpPost)) {
                String responseBody = new String(response.getEntity().getContent().readAllBytes(),
                        StandardCharsets.UTF_8);
                log.debug("iTop API Response: {}", responseBody);

                JsonNode result = objectMapper.readTree(responseBody);
                validateResponse(result);
                return result;
            }

        } catch (ITopApiException e) {
            throw e;
        } catch (IOException e) {
            throw new ITopApiException("خطا در اتصال به iTop: " + e.getMessage(), e);
        }
    }

    /** اعتبارسنجی پاسخ API */
    private void validateResponse(JsonNode response) throws ITopApiException {
        int code = response.path("code").asInt(-1);
        String message = response.path("message").asText("خطای نامشخص");

        switch (code) {
            case CODE_OK:
                return;
            case CODE_UNAUTHORIZED:
                throw new ITopAuthException("خطای احراز هویت: " + message);
            case CODE_MISSING_VERSION:
                throw new ITopApiException("نسخه API مشخص نشده: " + message);
            case CODE_MISSING_JSON:
                throw new ITopApiException("پارامتر json_data موجود نیست: " + message);
            case CODE_INVALID_JSON:
                throw new ITopApiException("ساختار JSON نامعتبر: " + message);
            case CODE_UNSUPPORTED_VER:
                throw new ITopApiException("نسخه API پشتیبانی نمی‌شود: " + message);
            case CODE_UNKNOWN_OPERATION:
                throw new ITopApiException("عملیات ناشناخته: " + message);
            case CODE_UNSAFE:
                throw new ITopApiException("عملیات ناامن (ممکن است داده‌ها از دست بروند): " + message);
            case CODE_INTERNAL_ERROR:
                throw new ITopApiException("خطای داخلی iTop: " + message);
            default:
                throw new ITopApiException(String.format("خطای API (کد %d): %s", code, message));
        }
    }

    /** تنظیم کلید روی payload */
    @SuppressWarnings("unchecked")
    private void setKeyOnPayload(ObjectNode payload, Object key) {
        if (key instanceof Integer || key instanceof Long) {
            payload.put("key", ((Number) key).longValue());
        } else if (key instanceof String) {
            payload.put("key", (String) key);
        } else if (key instanceof Map) {
            Map<String, Object> keyMap = (Map<String, Object>) key;
            ObjectNode keyNode = objectMapper.createObjectNode();
            for (Map.Entry<String, Object> entry : keyMap.entrySet()) {
                keyNode.put(entry.getKey(), String.valueOf(entry.getValue()));
            }
            payload.set("key", keyNode);
        }
    }

    /** ساخت ObjectNode از Map فیلدها */
    @SuppressWarnings("unchecked")
    private ObjectNode buildFieldsNode(Map<String, Object> fields) {
        ObjectNode fieldsNode = objectMapper.createObjectNode();
        for (Map.Entry<String, Object> entry : fields.entrySet()) {
            String fieldName = entry.getKey();
            Object value = entry.getValue();

            if (value == null) {
                fieldsNode.putNull(fieldName);
            } else if (value instanceof String) {
                fieldsNode.put(fieldName, (String) value);
            } else if (value instanceof Integer) {
                fieldsNode.put(fieldName, (Integer) value);
            } else if (value instanceof Long) {
                fieldsNode.put(fieldName, (Long) value);
            } else if (value instanceof Double) {
                fieldsNode.put(fieldName, (Double) value);
            } else if (value instanceof Boolean) {
                fieldsNode.put(fieldName, (Boolean) value);
            } else if (value instanceof Map) {
                // برای external key ها (foreign key)
                Map<String, Object> subMap = (Map<String, Object>) value;
                ObjectNode subNode = objectMapper.createObjectNode();
                for (Map.Entry<String, Object> subEntry : subMap.entrySet()) {
                    subNode.put(subEntry.getKey(), String.valueOf(subEntry.getValue()));
                }
                fieldsNode.set(fieldName, subNode);
            } else if (value instanceof List) {
                // برای link sets
                List<Map<String, Object>> listValue = (List<Map<String, Object>>) value;
                ArrayNode arrayNode = objectMapper.createArrayNode();
                for (Map<String, Object> item : listValue) {
                    ObjectNode itemNode = objectMapper.createObjectNode();
                    for (Map.Entry<String, Object> itemEntry : item.entrySet()) {
                        if (itemEntry.getValue() instanceof Integer) {
                            itemNode.put(itemEntry.getKey(), (Integer) itemEntry.getValue());
                        } else if (itemEntry.getValue() instanceof Map) {
                            itemNode.set(itemEntry.getKey(),
                                    buildFieldsNode((Map<String, Object>) itemEntry.getValue()));
                        } else {
                            itemNode.put(itemEntry.getKey(),
                                    String.valueOf(itemEntry.getValue()));
                        }
                    }
                    arrayNode.add(itemNode);
                }
                fieldsNode.set(fieldName, arrayNode);
            }
        }
        return fieldsNode;
    }

    /** تبدیل پاسخ JSON به لیست ITopObject */
    private List<ITopObject> parseObjectsFromResponse(JsonNode response) {
        List<ITopObject> result = new ArrayList<>();
        JsonNode objectsNode = response.get("objects");
        if (objectsNode == null || objectsNode.isNull()) {
            return result;
        }
        objectsNode.fields().forEachRemaining(entry -> {
            JsonNode obj = entry.getValue();
            Map<String, Object> fields = new LinkedHashMap<>();
            JsonNode fieldsNode = obj.get("fields");
            if (fieldsNode != null) {
                fieldsNode.fields().forEachRemaining(f -> {
                    if (f.getValue().isTextual()) {
                        fields.put(f.getKey(), f.getValue().asText());
                    } else if (f.getValue().isNumber()) {
                        fields.put(f.getKey(), f.getValue().asLong());
                    } else if (f.getValue().isBoolean()) {
                        fields.put(f.getKey(), f.getValue().asBoolean());
                    } else {
                        fields.put(f.getKey(), f.getValue().toString());
                    }
                });
            }
            result.add(new ITopObject(
                    obj.path("key").asInt(),
                    obj.path("class").asText(),
                    obj.path("message").asText(),
                    fields
            ));
        });
        return result;
    }

    @Override
    public void close() throws Exception {
        if (httpClient != null) {
            httpClient.close();
            log.info("ITopRestClient connection closed.");
        }
    }
}
