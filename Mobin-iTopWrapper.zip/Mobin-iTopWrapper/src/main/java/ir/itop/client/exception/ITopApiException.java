package ir.itop.client.exception;

/** خطای عمومی ارتباط با API iTop */
public class ITopApiException extends Exception {
    public ITopApiException(String message) { super(message); }
    public ITopApiException(String message, Throwable cause) { super(message, cause); }
}
