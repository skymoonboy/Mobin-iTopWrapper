package ir.itop.client.model;

/** نتیجه عملیات core/delete */
public class ITopDeleteResult {
    private final int affectedCount;
    private final boolean simulated;
    private final String message;

    public ITopDeleteResult(int affectedCount, boolean simulated, String message) {
        this.affectedCount = affectedCount;
        this.simulated = simulated;
        this.message = message;
    }

    public int getAffectedCount() { return affectedCount; }
    public boolean isSimulated() { return simulated; }
    public String getMessage() { return message; }
}
