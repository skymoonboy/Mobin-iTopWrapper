package ir.itop.client.model;

import java.util.Map;

/** نمایش یک شیء بازگشتی از iTop (core/get, core/create, core/update, ...) */
public class ITopObject {
    private final int key;
    private final String className;
    private final String friendlyName;
    private final Map<String, Object> fields;

    public ITopObject(int key, String className, String friendlyName, Map<String, Object> fields) {
        this.key = key;
        this.className = className;
        this.friendlyName = friendlyName;
        this.fields = fields;
    }

    public int getId() { return key; }
    public int getKey() { return key; }
    public String getClassName() { return className; }
    public String getFriendlyName() { return friendlyName; }
    public Map<String, Object> getFields() { return fields; }

    public Object get(String field) { return fields.get(field); }
    public String getString(String field) {
        Object v = fields.get(field);
        return v != null ? String.valueOf(v) : null;
    }
    public Long getLong(String field) {
        Object v = fields.get(field);
        if (v instanceof Number) return ((Number) v).longValue();
        if (v instanceof String) try { return Long.parseLong((String) v); } catch (Exception ignored) {}
        return null;
    }
    public Integer getInt(String field) {
        Long l = getLong(field);
        return l != null ? l.intValue() : null;
    }
    public Boolean getBoolean(String field) {
        Object v = fields.get(field);
        return v instanceof Boolean ? (Boolean) v : null;
    }

    @Override
    public String toString() {
        return "ITopObject{class=" + className + ", id=" + key + ", friendlyName=" + friendlyName + "}";
    }
}
