package ir.itop.client.model;

/** یک عملیات موجود در REST API iTop (نتیجه list_operations) */
public class ITopOperation {
    private final String verb;
    private final String description;
    private final String extension;

    public ITopOperation(String verb, String description, String extension) {
        this.verb = verb;
        this.description = description;
        this.extension = extension;
    }

    public String getVerb() { return verb; }
    public String getDescription() { return description; }
    public String getExtension() { return extension; }
}
