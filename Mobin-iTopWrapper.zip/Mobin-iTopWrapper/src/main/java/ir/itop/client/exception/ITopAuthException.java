package ir.itop.client.exception;

/** خطای احراز هویت (code=1 از iTop) */
public class ITopAuthException extends ITopApiException {
    public ITopAuthException(String message) { super(message); }
}
