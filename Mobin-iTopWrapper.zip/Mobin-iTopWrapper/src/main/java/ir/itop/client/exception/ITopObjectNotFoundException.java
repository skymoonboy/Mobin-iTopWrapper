package ir.itop.client.exception;

/** زمانی‌که شیء درخواست‌شده در iTop یافت نشود */
public class ITopObjectNotFoundException extends ITopApiException {
    public ITopObjectNotFoundException(String className, String key) {
        super("شیء یافت نشد — کلاس: " + className + " | کلید: " + key);
    }
}
