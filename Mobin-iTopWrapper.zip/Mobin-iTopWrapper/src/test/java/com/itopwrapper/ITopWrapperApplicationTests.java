package com.itopwrapper;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.TestPropertySource;

/**
 * تست راه‌اندازی سامانه
 */
@SpringBootTest
@ActiveProfiles("test")
@TestPropertySource(properties = {
    "spring.datasource.url=jdbc:h2:mem:testdb;DB_CLOSE_DELAY=-1",
    "spring.datasource.driver-class-name=org.h2.Driver",
    "spring.datasource.username=sa",
    "spring.datasource.password=",
    "spring.jpa.hibernate.ddl-auto=create-drop",
    "spring.jpa.database-platform=org.hibernate.dialect.H2Dialect",
    "spring.liquibase.enabled=false",
    "itop.api.url=http://localhost:8081",
    "jwt.secret=testSecretKeyForJWTTokenGenerationInTests12345",
    "jwt.expiration=86400000"
})
class ITopWrapperApplicationTests {

    @Test
    void contextLoads() {
        // تضمین می‌کند که Context اپلیکیشن بدون خطا بارگذاری شود
    }
}
