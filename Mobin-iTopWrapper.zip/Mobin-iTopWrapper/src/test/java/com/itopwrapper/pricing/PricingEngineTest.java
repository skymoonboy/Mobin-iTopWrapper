package com.itopwrapper.pricing;

import com.itopwrapper.model.entity.ServiceItem;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.CsvSource;

import java.math.BigDecimal;
import java.util.Map;

import static org.assertj.core.api.Assertions.*;

/**
 * تست‌های واحد موتور قیمت‌گذاری
 */
@DisplayName("موتور قیمت‌گذاری")
class PricingEngineTest {

    private PricingEngine pricingEngine;

    @BeforeEach
    void setUp() {
        pricingEngine = new PricingEngine();
    }

    // ===== قیمت ثابت =====

    @Test
    @DisplayName("قیمت ثابت — بدون تخفیف")
    void fixedPrice_bronze_noDiscount() {
        ServiceItem svc = buildService(ServiceItem.PricingModel.FIXED, new BigDecimal("1000000"));
        PricingResult result = pricingEngine.calculatePrice(svc, Map.of(), PricingEngine.CustomerTier.BRONZE);

        assertThat(result.getFinalPrice()).isEqualByComparingTo(new BigDecimal("1000000"));
        assertThat(result.getDiscountAmount()).isEqualByComparingTo(BigDecimal.ZERO);
        assertThat(result.getDiscountPercent()).isEqualByComparingTo(BigDecimal.ZERO);
        assertThat(result.getCurrency()).isEqualTo("IRR");
    }

    @Test
    @DisplayName("قیمت ثابت — تخفیف طلایی ۱۰٪")
    void fixedPrice_gold_tenPercentDiscount() {
        ServiceItem svc = buildService(ServiceItem.PricingModel.FIXED, new BigDecimal("1000000"));
        PricingResult result = pricingEngine.calculatePrice(svc, Map.of(), PricingEngine.CustomerTier.GOLD);

        assertThat(result.getFinalPrice()).isEqualByComparingTo(new BigDecimal("900000"));
        assertThat(result.getDiscountPercent()).isEqualByComparingTo(new BigDecimal("10"));
    }

    @Test
    @DisplayName("قیمت ثابت — تخفیف پلاتین ۱۵٪")
    void fixedPrice_platinum_fifteenPercentDiscount() {
        ServiceItem svc = buildService(ServiceItem.PricingModel.FIXED, new BigDecimal("2000000"));
        PricingResult result = pricingEngine.calculatePrice(svc, Map.of(), PricingEngine.CustomerTier.PLATINUM);

        assertThat(result.getFinalPrice()).isEqualByComparingTo(new BigDecimal("1700000"));
        assertThat(result.getDiscountPercent()).isEqualByComparingTo(new BigDecimal("15"));
    }

    // ===== قیمت ساعتی =====

    @Test
    @DisplayName("قیمت ساعتی — ۵ ساعت")
    void hourlyPrice_fiveHours() {
        ServiceItem svc = buildService(ServiceItem.PricingModel.HOURLY, new BigDecimal("500000"));
        PricingResult result = pricingEngine.calculatePrice(svc, Map.of("hours", 5), PricingEngine.CustomerTier.BRONZE);

        assertThat(result.getCalculatedPrice()).isEqualByComparingTo(new BigDecimal("2500000"));
        assertThat(result.getFinalPrice()).isEqualByComparingTo(new BigDecimal("2500000"));
    }

    @Test
    @DisplayName("قیمت ساعتی — با تخفیف نقره‌ای ۵٪")
    void hourlyPrice_withSilverDiscount() {
        ServiceItem svc = buildService(ServiceItem.PricingModel.HOURLY, new BigDecimal("200000"));
        PricingResult result = pricingEngine.calculatePrice(svc, Map.of("hours", 10), PricingEngine.CustomerTier.SILVER);

        BigDecimal expected = new BigDecimal("2000000").multiply(new BigDecimal("0.95")).setScale(0, java.math.RoundingMode.HALF_UP);
        assertThat(result.getFinalPrice()).isEqualByComparingTo(expected);
    }

    // ===== قیمت ماهانه =====

    @Test
    @DisplayName("قیمت ماهانه — ۱۲ ماه")
    void monthlyPrice_twelveMonths() {
        ServiceItem svc = buildService(ServiceItem.PricingModel.MONTHLY, new BigDecimal("300000"));
        PricingResult result = pricingEngine.calculatePrice(svc, Map.of("months", 12), PricingEngine.CustomerTier.BRONZE);

        assertThat(result.getCalculatedPrice()).isEqualByComparingTo(new BigDecimal("3600000"));
    }

    // ===== قیمت به ازای کاربر =====

    @Test
    @DisplayName("قیمت به ازای کاربر — ۲۵ کاربر")
    void perUserPrice_twentyFiveUsers() {
        ServiceItem svc = buildService(ServiceItem.PricingModel.PER_USER, new BigDecimal("150000"));
        PricingResult result = pricingEngine.calculatePrice(svc, Map.of("users", 25), PricingEngine.CustomerTier.BRONZE);

        assertThat(result.getCalculatedPrice()).isEqualByComparingTo(new BigDecimal("3750000"));
    }

    // ===== قیمت پله‌ای =====

    @ParameterizedTest(name = "تعداد={0} — تخفیف={1}٪")
    @CsvSource({
        "5,   100",
        "10,   95",
        "25,   90",
        "60,   80",
        "150,  70"
    })
    @DisplayName("قیمت پله‌ای — آستانه‌های مختلف")
    void tieredPrice_variousQuantities(int quantity, int discountFactor) {
        ServiceItem svc = buildService(ServiceItem.PricingModel.TIERED, new BigDecimal("100000"));
        PricingResult result = pricingEngine.calculatePrice(
            svc, Map.of("quantity", quantity), PricingEngine.CustomerTier.BRONZE);

        BigDecimal expected = new BigDecimal("100000")
            .multiply(BigDecimal.valueOf(quantity))
            .multiply(BigDecimal.valueOf(discountFactor))
            .divide(BigDecimal.valueOf(100), 0, java.math.RoundingMode.HALF_UP);
        assertThat(result.getCalculatedPrice()).isEqualByComparingTo(expected);
    }

    // ===== سطح مشتری =====

    @Test
    @DisplayName("null tier — بدون تخفیف")
    void nullTier_noDiscount() {
        ServiceItem svc = buildService(ServiceItem.PricingModel.FIXED, new BigDecimal("500000"));
        PricingResult result = pricingEngine.calculatePrice(svc, Map.of(), null);

        assertThat(result.getFinalPrice()).isEqualByComparingTo(new BigDecimal("500000"));
    }

    @ParameterizedTest(name = "سطح={0} — تخفیف={1}٪")
    @CsvSource({
        "BRONZE,    0",
        "SILVER,    5",
        "GOLD,     10",
        "PLATINUM, 15"
    })
    @DisplayName("تخفیف سطح مشتری")
    void customerTierDiscount(PricingEngine.CustomerTier tier, int expectedPct) {
        ServiceItem svc = buildService(ServiceItem.PricingModel.FIXED, new BigDecimal("1000000"));
        PricingResult result = pricingEngine.calculatePrice(svc, Map.of(), tier);

        assertThat(result.getDiscountPercent())
            .isEqualByComparingTo(BigDecimal.valueOf(expectedPct));
    }

    // ===== اعتبارسنجی خروجی =====

    @Test
    @DisplayName("نتیجه — همه فیلدها مقداردهی شده‌اند")
    void result_allFieldsPopulated() {
        ServiceItem svc = buildService(ServiceItem.PricingModel.FIXED, new BigDecimal("750000"));
        PricingResult result = pricingEngine.calculatePrice(svc, Map.of(), PricingEngine.CustomerTier.GOLD);

        assertThat(result.getBasePrice()).isNotNull();
        assertThat(result.getCalculatedPrice()).isNotNull();
        assertThat(result.getDiscountPercent()).isNotNull();
        assertThat(result.getDiscountAmount()).isNotNull();
        assertThat(result.getFinalPrice()).isNotNull();
        assertThat(result.getCurrency()).isEqualTo("IRR");
        assertThat(result.getBreakdown()).isNotBlank();
        assertThat(result.getCustomerTier()).isEqualTo(PricingEngine.CustomerTier.GOLD);
    }

    @Test
    @DisplayName("قیمت پایه صفر — خروجی صفر")
    void zeroPriceService_returnsZero() {
        ServiceItem svc = buildService(ServiceItem.PricingModel.FIXED, BigDecimal.ZERO);
        PricingResult result = pricingEngine.calculatePrice(svc, Map.of(), PricingEngine.CustomerTier.PLATINUM);

        assertThat(result.getFinalPrice()).isEqualByComparingTo(BigDecimal.ZERO);
    }

    @Test
    @DisplayName("قیمت نهایی هرگز منفی نیست")
    void finalPrice_neverNegative() {
        ServiceItem svc = buildService(ServiceItem.PricingModel.FIXED, BigDecimal.ONE);
        PricingResult result = pricingEngine.calculatePrice(svc, Map.of(), PricingEngine.CustomerTier.PLATINUM);

        assertThat(result.getFinalPrice()).isGreaterThanOrEqualTo(BigDecimal.ZERO);
    }

    // ===== Helpers =====

    private ServiceItem buildService(ServiceItem.PricingModel model, BigDecimal basePrice) {
        return ServiceItem.builder()
            .id(1L)
            .name("خدمت آزمایشی")
            .pricingModel(model)
            .basePrice(basePrice)
            .currency("IRR")
            .isActive(true)
            .build();
    }
}
