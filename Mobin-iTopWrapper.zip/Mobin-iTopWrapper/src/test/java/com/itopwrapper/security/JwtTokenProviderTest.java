package com.itopwrapper.security;

import com.itopwrapper.security.jwt.JwtTokenProvider;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.test.util.ReflectionTestUtils;

import java.util.List;

import static org.assertj.core.api.Assertions.*;

/**
 * تست JWT Token Provider
 */
@DisplayName("JWT Token Provider")
class JwtTokenProviderTest {

    private JwtTokenProvider jwtTokenProvider;

    private static final String SECRET =
        "testSecretKeyForJWTTokenGenerationInTestsMustBeLongerThan32Chars";
    private static final long EXPIRATION = 3_600_000L; // 1 hour

    @BeforeEach
    void setUp() {
        jwtTokenProvider = new JwtTokenProvider();
        ReflectionTestUtils.setField(jwtTokenProvider, "jwtSecret",    SECRET);
        ReflectionTestUtils.setField(jwtTokenProvider, "jwtExpiration", EXPIRATION);
        ReflectionTestUtils.setField(jwtTokenProvider, "refreshExpiration", 604_800_000L);
    }

    @Test
    @DisplayName("تولید توکن از Authentication")
    void generateToken_fromAuthentication() {
        Authentication auth = buildAuth("testuser", "ROLE_CUSTOMER");
        String token = jwtTokenProvider.generateToken(auth);

        assertThat(token).isNotBlank();
        assertThat(token.split("\\.")).hasSize(3); // header.payload.signature
    }

    @Test
    @DisplayName("دریافت username از توکن")
    void getUsernameFromToken_returnsCorrectUsername() {
        String token = jwtTokenProvider.generateTokenFromUsername("john_doe", "ROLE_ADMIN");
        String username = jwtTokenProvider.getUsernameFromToken(token);

        assertThat(username).isEqualTo("john_doe");
    }

    @Test
    @DisplayName("اعتبارسنجی توکن معتبر")
    void validateToken_validToken_returnsTrue() {
        String token = jwtTokenProvider.generateTokenFromUsername("admin", "ROLE_SUPER_ADMIN");
        assertThat(jwtTokenProvider.validateToken(token)).isTrue();
    }

    @Test
    @DisplayName("اعتبارسنجی توکن دستکاری‌شده — رد می‌شود")
    void validateToken_tamperedToken_returnsFalse() {
        String token = jwtTokenProvider.generateTokenFromUsername("admin", "ROLE_ADMIN");
        String tampered = token.substring(0, token.length() - 10) + "tampered123";
        assertThat(jwtTokenProvider.validateToken(tampered)).isFalse();
    }

    @Test
    @DisplayName("اعتبارسنجی رشته تهی — رد می‌شود")
    void validateToken_emptyToken_returnsFalse() {
        assertThat(jwtTokenProvider.validateToken("")).isFalse();
    }

    @Test
    @DisplayName("اعتبارسنجی رشته غیرمعتبر — رد می‌شود")
    void validateToken_randomString_returnsFalse() {
        assertThat(jwtTokenProvider.validateToken("not.a.jwt")).isFalse();
    }

    @Test
    @DisplayName("تولید Refresh Token")
    void generateRefreshToken_isValidToken() {
        String refreshToken = jwtTokenProvider.generateRefreshToken("testuser");
        assertThat(refreshToken).isNotBlank();
        assertThat(jwtTokenProvider.validateToken(refreshToken)).isTrue();
        assertThat(jwtTokenProvider.getUsernameFromToken(refreshToken)).isEqualTo("testuser");
    }

    @Test
    @DisplayName("توکن‌های مختلف برای کاربران مختلف")
    void generateToken_differentUsersGetDifferentTokens() {
        String token1 = jwtTokenProvider.generateTokenFromUsername("user1", "ROLE_CUSTOMER");
        String token2 = jwtTokenProvider.generateTokenFromUsername("user2", "ROLE_CUSTOMER");

        assertThat(token1).isNotEqualTo(token2);
        assertThat(jwtTokenProvider.getUsernameFromToken(token1)).isEqualTo("user1");
        assertThat(jwtTokenProvider.getUsernameFromToken(token2)).isEqualTo("user2");
    }

    @Test
    @DisplayName("getExpiration — مقدار صحیح")
    void getExpiration_returnsConfiguredValue() {
        assertThat(jwtTokenProvider.getExpiration()).isEqualTo(EXPIRATION);
    }

    @Test
    @DisplayName("توکن منقضی — تولید مجدد کار می‌کند")
    void generateToken_multipleTimesForSameUser() {
        // تولید چندین توکن برای همان کاربر باید کار کند
        for (int i = 0; i < 5; i++) {
            String token = jwtTokenProvider.generateTokenFromUsername("admin", "ROLE_ADMIN");
            assertThat(jwtTokenProvider.validateToken(token)).isTrue();
        }
    }

    // ===== Helpers =====

    private Authentication buildAuth(String username, String role) {
        UserDetails userDetails = User.builder()
            .username(username)
            .password("{noop}password")
            .authorities(new SimpleGrantedAuthority(role))
            .build();
        return new UsernamePasswordAuthenticationToken(userDetails, null, userDetails.getAuthorities());
    }
}
