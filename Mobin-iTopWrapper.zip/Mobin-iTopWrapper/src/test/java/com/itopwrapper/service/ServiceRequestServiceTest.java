package com.itopwrapper.service;

import com.itopwrapper.audit.AuditService;
import com.itopwrapper.itop.ITopApiClient;
import com.itopwrapper.model.entity.*;
import com.itopwrapper.repository.*;
import com.itopwrapper.service.impl.ServiceRequestService;
import com.itopwrapper.service.impl.SlaService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.*;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.data.domain.*;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.*;

import static org.assertj.core.api.Assertions.*;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.*;

/**
 * تست سرویس مدیریت درخواست‌های خدمت
 */
@ExtendWith(MockitoExtension.class)
@DisplayName("ServiceRequestService")
class ServiceRequestServiceTest {

    @Mock private ServiceRequestRepository requestRepository;
    @Mock private UserRepository            userRepository;
    @Mock private ServiceItemRepository     serviceItemRepository;
    @Mock private SlaRepository             slaRepository;
    @Mock private ITopApiClient             iTopApiClient;
    @Mock private AuditService              auditService;
    @Mock private SlaService                slaService;

    @InjectMocks
    private ServiceRequestService service;

    @Captor
    private ArgumentCaptor<ServiceRequest> requestCaptor;

    private User testUser;
    private ServiceItem testServiceItem;

    @BeforeEach
    void setUp() {
        testUser = User.builder()
            .id(1L).username("testuser")
            .email("test@example.com")
            .firstName("علی").lastName("محمدی")
            .isActive(true).build();

        testServiceItem = ServiceItem.builder()
            .id(10L).name("نصب نرم‌افزار")
            .pricingModel(ServiceItem.PricingModel.FIXED)
            .basePrice(new BigDecimal("500000"))
            .slaHours(8).isActive(true).build();
    }

    // ===== ایجاد درخواست =====

    @Test
    @DisplayName("ایجاد درخواست ساده — موفق")
    void createRequest_simple_success() {
        when(userRepository.findById(1L)).thenReturn(Optional.of(testUser));
        when(serviceItemRepository.findById(10L)).thenReturn(Optional.of(testServiceItem));
        when(slaRepository.findBySlaTypeAndIsActiveTrue(SlaDefinition.SlaType.SLA)).thenReturn(List.of());
        when(requestRepository.count()).thenReturn(5L);
        when(requestRepository.save(any())).thenAnswer(inv -> {
            ServiceRequest r = inv.getArgument(0);
            r.setId(100L);
            return r;
        });
        doNothing().when(auditService).log(any(), any(), any(), any(), any(), any(), anyBoolean());

        ServiceRequest result = service.createRequest(
            1L, 10L, "نصب Word", "لطفاً نصب کنید", ServiceRequest.Priority.MEDIUM);

        assertThat(result).isNotNull();
        assertThat(result.getTitle()).isEqualTo("نصب Word");
        assertThat(result.getRequester()).isEqualTo(testUser);
        assertThat(result.getServiceItem()).isEqualTo(testServiceItem);
        assertThat(result.getStatus()).isEqualTo(ServiceRequest.RequestStatus.NEW);
        assertThat(result.getPriority()).isEqualTo(ServiceRequest.Priority.MEDIUM);
        assertThat(result.getTicketNumber()).startsWith("REQ-");
        verify(requestRepository).save(any(ServiceRequest.class));
    }

    @Test
    @DisplayName("ایجاد درخواست — کاربر یافت نشد → خطا")
    void createRequest_userNotFound_throwsException() {
        when(userRepository.findById(999L)).thenReturn(Optional.empty());

        assertThatThrownBy(() ->
            service.createRequest(999L, 10L, "title", "desc", ServiceRequest.Priority.LOW))
            .isInstanceOf(RuntimeException.class)
            .hasMessageContaining("کاربر یافت نشد");
    }

    @Test
    @DisplayName("ایجاد درخواست — بدون آیتم خدمت")
    void createRequest_withoutServiceItem_success() {
        when(userRepository.findById(1L)).thenReturn(Optional.of(testUser));
        when(requestRepository.count()).thenReturn(0L);
        when(requestRepository.save(any())).thenAnswer(inv -> {
            ServiceRequest r = inv.getArgument(0);
            r.setId(1L);
            return r;
        });
        doNothing().when(auditService).log(any(), any(), any(), any(), any(), any(), anyBoolean());

        ServiceRequest result = service.createRequest(
            1L, null, "سؤال عمومی", "توضیح", ServiceRequest.Priority.LOW);

        assertThat(result.getServiceItem()).isNull();
        assertThat(result.getStatus()).isEqualTo(ServiceRequest.RequestStatus.NEW);
    }

    // ===== تغییر وضعیت =====

    @Test
    @DisplayName("تغییر وضعیت به RESOLVED — زمان تعیین می‌شود")
    void updateStatus_toResolved_setsResolvedAt() {
        ServiceRequest req = buildRequest(ServiceRequest.RequestStatus.IN_PROGRESS);
        when(requestRepository.findById(1L)).thenReturn(Optional.of(req));
        when(requestRepository.save(any())).thenAnswer(inv -> inv.getArgument(0));
        doNothing().when(auditService).log(any(), any(), any(), any(), any(), any(), anyBoolean());

        ServiceRequest result = service.updateStatus(1L, ServiceRequest.RequestStatus.RESOLVED, "رفع شد", "operator");

        assertThat(result.getStatus()).isEqualTo(ServiceRequest.RequestStatus.RESOLVED);
        assertThat(result.getResolvedAt()).isNotNull();
        assertThat(result.getResolvedAt()).isBeforeOrEqualTo(LocalDateTime.now());
    }

    @Test
    @DisplayName("تغییر وضعیت به CLOSED — closedAt تعیین می‌شود")
    void updateStatus_toClosed_setsClosedAt() {
        ServiceRequest req = buildRequest(ServiceRequest.RequestStatus.RESOLVED);
        when(requestRepository.findById(1L)).thenReturn(Optional.of(req));
        when(requestRepository.save(any())).thenAnswer(inv -> inv.getArgument(0));
        doNothing().when(auditService).log(any(), any(), any(), any(), any(), any(), anyBoolean());

        ServiceRequest result = service.updateStatus(1L, ServiceRequest.RequestStatus.CLOSED, null, "admin");

        assertThat(result.getStatus()).isEqualTo(ServiceRequest.RequestStatus.CLOSED);
        assertThat(result.getClosedAt()).isNotNull();
    }

    @Test
    @DisplayName("تغییر وضعیت — درخواست یافت نشد → خطا")
    void updateStatus_requestNotFound_throwsException() {
        when(requestRepository.findById(999L)).thenReturn(Optional.empty());

        assertThatThrownBy(() ->
            service.updateStatus(999L, ServiceRequest.RequestStatus.RESOLVED, null, "admin"))
            .isInstanceOf(RuntimeException.class);
    }

    // ===== تخصیص درخواست =====

    @Test
    @DisplayName("تخصیص درخواست — وضعیت به ASSIGNED تغییر می‌کند")
    void assignRequest_changesStatusToAssigned() {
        ServiceRequest req = buildRequest(ServiceRequest.RequestStatus.NEW);
        User assignee = User.builder().id(2L).username("operator1").build();

        when(requestRepository.findById(1L)).thenReturn(Optional.of(req));
        when(userRepository.findById(2L)).thenReturn(Optional.of(assignee));
        when(requestRepository.save(any())).thenAnswer(inv -> inv.getArgument(0));
        doNothing().when(auditService).log(any(), any(), any(), any(), any(), any(), anyBoolean());

        ServiceRequest result = service.assignRequest(1L, 2L, "admin");

        assertThat(result.getStatus()).isEqualTo(ServiceRequest.RequestStatus.ASSIGNED);
        assertThat(result.getAssignee()).isEqualTo(assignee);
    }

    // ===== افزودن نظر =====

    @Test
    @DisplayName("افزودن نظر عمومی")
    void addComment_publicComment_success() {
        ServiceRequest req = buildRequest(ServiceRequest.RequestStatus.IN_PROGRESS);
        when(requestRepository.findById(1L)).thenReturn(Optional.of(req));
        when(userRepository.findById(1L)).thenReturn(Optional.of(testUser));
        when(requestRepository.save(any())).thenReturn(req);
        doNothing().when(auditService).log(any(), any(), any(), any(), any(), any(), anyBoolean());

        RequestComment comment = service.addComment(1L, 1L, "پیگیری شد", RequestComment.CommentType.PUBLIC);

        assertThat(comment).isNotNull();
        assertThat(comment.getContent()).isEqualTo("پیگیری شد");
        assertThat(comment.getCommentType()).isEqualTo(RequestComment.CommentType.PUBLIC);
        assertThat(comment.getAuthor()).isEqualTo(testUser);
    }

    // ===== آمار =====

    @Test
    @DisplayName("آمار درخواست‌ها — همه وضعیت‌ها موجودند")
    void getRequestStats_containsAllStatuses() {
        for (ServiceRequest.RequestStatus s : ServiceRequest.RequestStatus.values()) {
            when(requestRepository.countByStatus(s)).thenReturn(0L);
        }
        when(requestRepository.findBreachedSla(any())).thenReturn(List.of());

        Map<String, Long> stats = service.getRequestStats();

        for (ServiceRequest.RequestStatus s : ServiceRequest.RequestStatus.values()) {
            assertThat(stats).containsKey(s.name());
        }
        assertThat(stats).containsKey("BREACHED_SLA");
    }

    // ===== Helpers =====

    private ServiceRequest buildRequest(ServiceRequest.RequestStatus status) {
        return ServiceRequest.builder()
            .id(1L)
            .ticketNumber("REQ-20240101-00001")
            .title("درخواست تست")
            .requester(testUser)
            .status(status)
            .priority(ServiceRequest.Priority.MEDIUM)
            .build();
    }
}
