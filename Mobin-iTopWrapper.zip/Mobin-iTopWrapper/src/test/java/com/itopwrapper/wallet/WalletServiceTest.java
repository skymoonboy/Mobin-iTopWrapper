package com.itopwrapper.wallet;

import com.itopwrapper.audit.AuditService;
import com.itopwrapper.model.entity.ServiceRequest;
import com.itopwrapper.model.entity.User;
import com.itopwrapper.model.entity.Wallet;
import com.itopwrapper.model.entity.WalletTransaction;
import com.itopwrapper.repository.UserRepository;
import com.itopwrapper.repository.WalletRepository;
import com.itopwrapper.repository.WalletTransactionRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.math.BigDecimal;
import java.util.Optional;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyBoolean;
import static org.mockito.Mockito.*;

/**
 * تست‌های واحد سرویس کیف‌پول — پوشش کسر فوری، Hold/Capture/Release،
 * سقف اعتباری، و خطای کمبود موجودی.
 */
@ExtendWith(MockitoExtension.class)
@DisplayName("WalletService")
class WalletServiceTest {

    @Mock private WalletRepository walletRepository;
    @Mock private WalletTransactionRepository transactionRepository;
    @Mock private UserRepository userRepository;
    @Mock private AuditService auditService;

    @InjectMocks
    private WalletService walletService;

    private User testUser;
    private Wallet testWallet;

    @BeforeEach
    void setUp() {
        testUser = User.builder().id(1L).username("customer1").build();
        testWallet = Wallet.builder()
            .id(10L).user(testUser)
            .balance(new BigDecimal("1000000"))
            .heldAmount(BigDecimal.ZERO)
            .creditLimit(BigDecimal.ZERO)
            .currency("IRR").isActive(true)
            .build();

        doNothing().when(auditService).log(any(), any(), any(), any(), any(), any(), anyBoolean());
        lenientStubs();
    }

    private void lenientStubs() {
        when(transactionRepository.save(any())).thenAnswer(inv -> {
            WalletTransaction tx = inv.getArgument(0);
            tx.setId(System.nanoTime());
            return tx;
        });
    }

    // ===== شارژ (Top-up) =====

    @Test
    @DisplayName("شارژ کیف‌پول — افزایش موجودی")
    void topUp_increasesBalance() {
        when(walletRepository.findByUserId(1L)).thenReturn(Optional.of(testWallet));
        when(walletRepository.findByUserIdForUpdate(1L)).thenReturn(Optional.of(testWallet));
        when(walletRepository.save(any())).thenAnswer(inv -> inv.getArgument(0));

        WalletTransaction tx = walletService.topUp(1L, new BigDecimal("500000"), "شارژ تست", "admin", "127.0.0.1");

        assertThat(testWallet.getBalance()).isEqualByComparingTo("1500000");
        assertThat(tx.getType()).isEqualTo(WalletTransaction.TransactionType.TOP_UP);
        assertThat(tx.getBalanceBefore()).isEqualByComparingTo("1000000");
        assertThat(tx.getBalanceAfter()).isEqualByComparingTo("1500000");
    }

    @Test
    @DisplayName("شارژ با مبلغ منفی — خطا")
    void topUp_negativeAmount_throwsException() {
        assertThatThrownBy(() ->
            walletService.topUp(1L, new BigDecimal("-100"), "desc", "admin", "ip"))
            .isInstanceOf(WalletException.class)
            .hasMessageContaining("مثبت");
    }

    // ===== خرید فوری (Purchase) =====

    @Test
    @DisplayName("خرید با موجودی کافی — کسر موفق")
    void purchase_sufficientBalance_succeeds() {
        when(walletRepository.findByUserId(1L)).thenReturn(Optional.of(testWallet));
        when(walletRepository.findByUserIdForUpdate(1L)).thenReturn(Optional.of(testWallet));
        when(walletRepository.save(any())).thenAnswer(inv -> inv.getArgument(0));

        ServiceRequest req = ServiceRequest.builder().id(100L).ticketNumber("REQ-001").build();
        WalletTransaction tx = walletService.purchase(1L, new BigDecimal("300000"), req,
            "خرید خدمت تست", "customer1", "127.0.0.1");

        assertThat(testWallet.getBalance()).isEqualByComparingTo("700000");
        assertThat(tx.getType()).isEqualTo(WalletTransaction.TransactionType.PURCHASE);
    }

    @Test
    @DisplayName("خرید با موجودی ناکافی و بدون سقف اعتباری — InsufficientBalanceException")
    void purchase_insufficientBalance_throwsException() {
        when(walletRepository.findByUserId(1L)).thenReturn(Optional.of(testWallet));
        when(walletRepository.findByUserIdForUpdate(1L)).thenReturn(Optional.of(testWallet));

        ServiceRequest req = ServiceRequest.builder().id(100L).ticketNumber("REQ-002").build();

        assertThatThrownBy(() ->
            walletService.purchase(1L, new BigDecimal("2000000"), req, "desc", "customer1", "ip"))
            .isInstanceOf(InsufficientBalanceException.class);

        // موجودی نباید تغییر کرده باشد
        assertThat(testWallet.getBalance()).isEqualByComparingTo("1000000");
    }

    @Test
    @DisplayName("خرید با سقف اعتباری — موجودی می‌تواند منفی شود")
    void purchase_withCreditLimit_allowsNegativeBalance() {
        testWallet.setCreditLimit(new BigDecimal("500000"));
        when(walletRepository.findByUserId(1L)).thenReturn(Optional.of(testWallet));
        when(walletRepository.findByUserIdForUpdate(1L)).thenReturn(Optional.of(testWallet));
        when(walletRepository.save(any())).thenAnswer(inv -> inv.getArgument(0));

        ServiceRequest req = ServiceRequest.builder().id(101L).ticketNumber("REQ-003").build();
        // موجودی ۱,۰۰۰,۰۰۰ + سقف ۵۰۰,۰۰۰ = حداکثر قابل خرید ۱,۵۰۰,۰۰۰
        walletService.purchase(1L, new BigDecimal("1300000"), req, "desc", "customer1", "ip");

        assertThat(testWallet.getBalance()).isEqualByComparingTo("-300000");
    }

    @Test
    @DisplayName("خرید با مبلغ صفر — تراکنشی ثبت نمی‌شود (خدمت رایگان)")
    void purchase_zeroAmount_returnsNull() {
        ServiceRequest req = ServiceRequest.builder().id(102L).build();
        WalletTransaction tx = walletService.purchase(1L, BigDecimal.ZERO, req, "desc", "customer1", "ip");
        assertThat(tx).isNull();
        verifyNoInteractions(walletRepository);
    }

    // ===== Hold / Capture / Release =====

    @Test
    @DisplayName("Hold — موجودی کل تغییر نمی‌کند ولی heldAmount افزایش می‌یابد")
    void hold_increasesHeldAmountNotBalance() {
        when(walletRepository.findByUserId(1L)).thenReturn(Optional.of(testWallet));
        when(walletRepository.findByUserIdForUpdate(1L)).thenReturn(Optional.of(testWallet));
        when(walletRepository.save(any())).thenAnswer(inv -> inv.getArgument(0));

        ServiceRequest req = ServiceRequest.builder().id(200L).ticketNumber("REQ-010").build();
        WalletTransaction tx = walletService.hold(1L, new BigDecimal("400000"), req, "desc", "customer1", "ip");

        assertThat(testWallet.getBalance()).isEqualByComparingTo("1000000"); // بدون تغییر
        assertThat(testWallet.getHeldAmount()).isEqualByComparingTo("400000");
        assertThat(testWallet.getAvailableBalance()).isEqualByComparingTo("600000");
        assertThat(tx.getType()).isEqualTo(WalletTransaction.TransactionType.HOLD);
    }

    @Test
    @DisplayName("Capture — مبلغ Hold شده به‌صورت قطعی از balance کسر می‌شود")
    void capture_deductsFromBalanceAndClearsHold() {
        testWallet.setHeldAmount(new BigDecimal("400000"));

        WalletTransaction holdTx = WalletTransaction.builder()
            .id(5000L).wallet(testWallet).type(WalletTransaction.TransactionType.HOLD)
            .amount(new BigDecimal("400000")).balanceBefore(testWallet.getBalance())
            .balanceAfter(testWallet.getBalance()).performedBy("customer1").build();

        ServiceRequest req = ServiceRequest.builder()
            .id(200L).ticketNumber("REQ-010").walletTransactionId(5000L).build();

        when(transactionRepository.findById(5000L)).thenReturn(Optional.of(holdTx));
        when(walletRepository.findByUserId(1L)).thenReturn(Optional.of(testWallet));
        when(walletRepository.findByUserIdForUpdate(1L)).thenReturn(Optional.of(testWallet));
        when(walletRepository.save(any())).thenAnswer(inv -> inv.getArgument(0));

        WalletTransaction captureTx = walletService.capture(req, "operator1", "ip");

        assertThat(testWallet.getHeldAmount()).isEqualByComparingTo(BigDecimal.ZERO);
        assertThat(testWallet.getBalance()).isEqualByComparingTo("600000"); // 1,000,000 - 400,000
        assertThat(captureTx.getType()).isEqualTo(WalletTransaction.TransactionType.CAPTURE);
    }

    @Test
    @DisplayName("Release — مبلغ Hold شده آزاد می‌شود بدون تغییر در balance")
    void release_clearsHoldWithoutAffectingBalance() {
        testWallet.setHeldAmount(new BigDecimal("400000"));

        WalletTransaction holdTx = WalletTransaction.builder()
            .id(5001L).wallet(testWallet).type(WalletTransaction.TransactionType.HOLD)
            .amount(new BigDecimal("400000")).balanceBefore(testWallet.getBalance())
            .balanceAfter(testWallet.getBalance()).performedBy("customer1").build();

        ServiceRequest req = ServiceRequest.builder()
            .id(201L).ticketNumber("REQ-011").walletTransactionId(5001L).build();

        when(transactionRepository.findById(5001L)).thenReturn(Optional.of(holdTx));
        when(walletRepository.findByUserId(1L)).thenReturn(Optional.of(testWallet));
        when(walletRepository.findByUserIdForUpdate(1L)).thenReturn(Optional.of(testWallet));
        when(walletRepository.save(any())).thenAnswer(inv -> inv.getArgument(0));

        WalletTransaction releaseTx = walletService.release(req, "operator1", "ip");

        assertThat(testWallet.getHeldAmount()).isEqualByComparingTo(BigDecimal.ZERO);
        assertThat(testWallet.getBalance()).isEqualByComparingTo("1000000"); // بدون تغییر
        assertThat(releaseTx.getType()).isEqualTo(WalletTransaction.TransactionType.RELEASE);
    }

    @Test
    @DisplayName("Capture بدون Hold باز — null برمی‌گرداند")
    void capture_noOpenHold_returnsNull() {
        ServiceRequest req = ServiceRequest.builder().id(300L).ticketNumber("REQ-099").walletTransactionId(null).build();
        WalletTransaction result = walletService.capture(req, "operator1", "ip");
        assertThat(result).isNull();
    }

    // ===== سقف اعتباری =====

    @Test
    @DisplayName("تنظیم سقف اعتباری منفی — خطا")
    void setCreditLimit_negative_throwsException() {
        assertThatThrownBy(() ->
            walletService.setCreditLimit(1L, new BigDecimal("-100"), "admin", "ip"))
            .isInstanceOf(WalletException.class)
            .hasMessageContaining("منفی");
    }

    @Test
    @DisplayName("تنظیم سقف اعتباری معتبر — موفق")
    void setCreditLimit_valid_succeeds() {
        when(walletRepository.findByUserId(1L)).thenReturn(Optional.of(testWallet));
        when(walletRepository.findByUserIdForUpdate(1L)).thenReturn(Optional.of(testWallet));
        when(walletRepository.save(any())).thenAnswer(inv -> inv.getArgument(0));

        Wallet result = walletService.setCreditLimit(1L, new BigDecimal("1000000"), "admin", "ip");
        assertThat(result.getCreditLimit()).isEqualByComparingTo("1000000");
    }

    // ===== کسر دستی ادمین =====

    @Test
    @DisplayName("کسر دستی توسط ادمین — کاهش موجودی")
    void adminDeduct_reducesBalance() {
        when(walletRepository.findByUserId(1L)).thenReturn(Optional.of(testWallet));
        when(walletRepository.findByUserIdForUpdate(1L)).thenReturn(Optional.of(testWallet));
        when(walletRepository.save(any())).thenAnswer(inv -> inv.getArgument(0));

        walletService.adminDeduct(1L, new BigDecimal("200000"), "اصلاح خطا", "admin", "ip");

        assertThat(testWallet.getBalance()).isEqualByComparingTo("800000");
    }

    @Test
    @DisplayName("کسر دستی بیش از موجودی و بدون سقف — خطا")
    void adminDeduct_exceedsBalance_throwsException() {
        when(walletRepository.findByUserId(1L)).thenReturn(Optional.of(testWallet));
        when(walletRepository.findByUserIdForUpdate(1L)).thenReturn(Optional.of(testWallet));

        assertThatThrownBy(() ->
            walletService.adminDeduct(1L, new BigDecimal("5000000"), "desc", "admin", "ip"))
            .isInstanceOf(WalletException.class);
    }

    // ===== ایجاد خودکار کیف‌پول =====

    @Test
    @DisplayName("getOrCreateWallet — کیف‌پول جدید برای کاربر بدون کیف‌پول")
    void getOrCreateWallet_createsNewWalletIfNotExists() {
        when(walletRepository.findByUserId(2L)).thenReturn(Optional.empty());
        when(userRepository.findById(2L)).thenReturn(Optional.of(
            User.builder().id(2L).username("newuser").build()));
        when(walletRepository.save(any())).thenAnswer(inv -> {
            Wallet w = inv.getArgument(0);
            w.setId(99L);
            return w;
        });

        Wallet wallet = walletService.getOrCreateWallet(2L);

        assertThat(wallet.getBalance()).isEqualByComparingTo(BigDecimal.ZERO);
        assertThat(wallet.getIsActive()).isTrue();
        assertThat(wallet.getCurrency()).isEqualTo("IRR");
    }

    // ===== متدهای کمکی موجودیت Wallet =====

    @Test
    @DisplayName("Wallet.canAfford — با سقف اعتباری صفر")
    void wallet_canAfford_withoutCreditLimit() {
        Wallet w = Wallet.builder().balance(new BigDecimal("500000")).heldAmount(BigDecimal.ZERO)
            .creditLimit(BigDecimal.ZERO).build();
        assertThat(w.canAfford(new BigDecimal("400000"))).isTrue();
        assertThat(w.canAfford(new BigDecimal("600000"))).isFalse();
    }

    @Test
    @DisplayName("Wallet.canAfford — با سقف اعتباری مثبت")
    void wallet_canAfford_withCreditLimit() {
        Wallet w = Wallet.builder().balance(new BigDecimal("100000")).heldAmount(BigDecimal.ZERO)
            .creditLimit(new BigDecimal("300000")).build();
        assertThat(w.canAfford(new BigDecimal("350000"))).isTrue();  // 100k + 300k = 400k >= 350k
        assertThat(w.canAfford(new BigDecimal("450000"))).isFalse();
    }

    @Test
    @DisplayName("Wallet.getAvailableBalance — کسر مبلغ Hold شده")
    void wallet_availableBalance_subtractsHeld() {
        Wallet w = Wallet.builder().balance(new BigDecimal("1000000"))
            .heldAmount(new BigDecimal("300000")).build();
        assertThat(w.getAvailableBalance()).isEqualByComparingTo("700000");
    }
}
