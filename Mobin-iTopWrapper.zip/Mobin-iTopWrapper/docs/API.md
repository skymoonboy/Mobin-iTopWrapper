# 📡 مستندات API — سامانه مدیریت خدمات فناوری اطلاعات

پایه آدرس: `http://localhost:8080`
احراز هویت: `Bearer Token` (JWT) در هدر `Authorization` یا کوکی `JWT_TOKEN`

---

## 🔐 احراز هویت — `/api/auth`

### ورود
```http
POST /api/auth/login
Content-Type: application/json

{
  "username": "admin",
  "password": "Admin@123",
  "authType": "LOCAL"
}
```
**پاسخ ۲۰۰:**
```json
{
  "token": "eyJhbGciOiJIUzI1NiJ9...",
  "refreshToken": "eyJhbGciOiJIUzI1NiJ9...",
  "username": "admin",
  "roles": ["ROLE_SUPER_ADMIN"],
  "expiresIn": 86400000,
  "message": "ورود موفقیت‌آمیز"
}
```

### ورود LDAP
```http
POST /api/auth/login
Content-Type: application/json

{ "username": "john", "password": "pass", "authType": "LDAP" }
```

### تجدید توکن
```http
POST /api/auth/refresh?refreshToken=eyJ...
```

### خروج
```http
POST /api/auth/logout
```

---

## 👥 مدیریت کاربران — `/api/admin/users`
*نیازمند نقش: ADMIN یا SUPER_ADMIN*

| متد | مسیر | توضیح |
|---|---|---|
| GET | `/api/admin/users` | لیست همه کاربران |
| GET | `/api/admin/users/{id}` | جزئیات کاربر |
| POST | `/api/admin/users` | ایجاد کاربر جدید |
| PUT | `/api/admin/users/{id}` | ویرایش کاربر |
| POST | `/api/admin/users/{id}/toggle-active` | فعال/غیرفعال‌سازی |
| POST | `/api/admin/users/{id}/reset-password` | بازنشانی رمز |
| DELETE | `/api/admin/users/{id}` | حذف (فقط SUPER_ADMIN) |

**نمونه ایجاد کاربر:**
```json
POST /api/admin/users
{
  "username": "operator1",
  "email": "op1@company.com",
  "passwordHash": "SecurePass123",
  "firstName": "رضا",
  "lastName": "احمدی",
  "authType": "LOCAL",
  "isActive": true,
  "roles": [{"name": "ROLE_OPERATOR"}]
}
```

---

## 🗂️ کاتالوگ خدمات — `/api/admin/service-categories`

| متد | مسیر | توضیح |
|---|---|---|
| GET | `/api/admin/service-categories` | همه دسته‌ها |
| POST | `/api/admin/service-categories` | ایجاد دسته |
| PUT | `/api/admin/service-categories/{id}` | ویرایش دسته |
| DELETE | `/api/admin/service-categories/{id}` | حذف دسته |
| GET | `/api/admin/service-categories/{id}/services` | خدمات یک دسته |
| POST | `/api/admin/service-categories/{id}/services` | افزودن خدمت |
| PUT | `/api/admin/service-categories/services/{id}` | ویرایش خدمت |
| DELETE | `/api/admin/service-categories/services/{id}` | حذف خدمت |

---

## 💰 موتور قیمت‌گذاری — `/portal/service/{id}/calculate-price`

```http
POST /portal/service/10/calculate-price
Content-Type: application/x-www-form-urlencoded

tier=GOLD&months=12&hours=1&users=1&quantity=1
```
**پاسخ:**
```json
{
  "basePrice": 500000,
  "calculatedPrice": 6000000,
  "discountPercent": 10,
  "discountAmount": 600000,
  "finalPrice": 5400000,
  "currency": "IRR",
  "breakdown": "ماهانه: 500,000 ریال × 12 ماه",
  "customerTier": "GOLD"
}
```

---

## 👛 کیف‌پول مشتری

### پرتال مشتری (فقط مشاهده) — `/api/portal/wallet`

| متد | مسیر | توضیح |
|---|---|---|
| GET | `/api/portal/wallet` | موجودی و خلاصه کیف‌پول کاربر جاری |
| GET | `/api/portal/wallet/transactions?page=0&size=20` | گردش‌حساب کاربر جاری |

**پاسخ نمونه `GET /api/portal/wallet`:**
```json
{
  "walletId": 3, "userId": 12, "username": "customer1",
  "balance": 8500000, "heldAmount": 1200000,
  "availableBalance": 7300000, "creditLimit": 0,
  "maxWithdrawable": 7300000, "currency": "IRR",
  "isActive": true, "isLowBalance": false
}
```

### پنل مدیریتی (شارژ/کسر/سقف اعتباری) — `/api/admin/wallets`
*نیازمند نقش: ADMIN یا SUPER_ADMIN*

| متد | مسیر | توضیح |
|---|---|---|
| GET | `/api/admin/wallets` | لیست همه کیف‌پول‌ها |
| GET | `/api/admin/wallets/user/{userId}` | جزئیات کیف‌پول یک کاربر |
| POST | `/api/admin/wallets/top-up` | شارژ اعتبار |
| POST | `/api/admin/wallets/deduct` | کسر دستی اعتبار |
| POST | `/api/admin/wallets/credit-limit` | تعیین سقف اعتباری |
| POST | `/api/admin/wallets/user/{userId}/toggle-active?active=false` | فعال/غیرفعال‌سازی |
| GET | `/api/admin/wallets/user/{userId}/transactions` | گردش‌حساب یک کاربر |
| GET | `/api/admin/wallets/transactions` | گردش‌حساب کل سامانه (حسابرسی) |
| GET | `/api/admin/wallets/low-balance` | کیف‌پول‌های با موجودی کم |

**شارژ کیف‌پول:**
```json
POST /api/admin/wallets/top-up
{ "userId": 12, "amount": 5000000, "description": "شارژ اولیه قرارداد" }
```

**تعیین سقف اعتباری:**
```json
POST /api/admin/wallets/credit-limit
{ "userId": 12, "creditLimit": 2000000 }
```

> در صورت کمبود موجودی هنگام ثبت درخواست، پاسخ با کد **HTTP 402** و ساختار زیر برمی‌گردد:
> ```json
> { "error": "INSUFFICIENT_BALANCE", "message": "...", "available": 100000, "requested": 500000, "shortfall": 400000 }
> ```

---

## 🎫 درخواست‌های خدمت

### پرتال مشتری — `/api/portal/requests`

| متد | مسیر | توضیح |
|---|---|---|
| GET | `/api/portal/requests?page=0&size=10` | درخواست‌های من |
| POST | `/api/portal/requests` | ثبت درخواست جدید (با کسر/Hold خودکار کیف‌پول) |
| POST | `/api/portal/requests/{id}/comments` | افزودن نظر |
| POST | `/api/portal/requests/{id}/satisfaction` | امتیازدهی رضایت |

**ثبت درخواست** (پارامترهای قیمت‌گذاری اختیاری‌اند و فقط برای خدمات با مدل قیمت متغیر استفاده می‌شوند):
```http
POST /api/portal/requests
Content-Type: application/x-www-form-urlencoded

title=نصب نرم‌افزار&description=لطفا Office نصب شود&serviceItemId=10&priority=MEDIUM
&months=1&hours=1&users=1&quantity=1&customerTier=BRONZE
```
در صورت کافی‌نبودن موجودی کیف‌پول، پاسخ با کد ۴۰۲ و جزئیات کمبود موجودی بازمی‌گردد (به بخش کیف‌پول مراجعه کنید).

### پنل مدیریتی — `/api/admin/requests`

| متد | مسیر | توضیح |
|---|---|---|
| GET | `/api/admin/requests?page=0&size=20&status=NEW` | لیست همه (فیلتر اختیاری) |
| GET | `/api/admin/requests/{id}` | جزئیات |
| PATCH | `/api/admin/requests/{id}/status?status=RESOLVED` | تغییر وضعیت (Capture/Release خودکار کیف‌پول) |
| PATCH | `/api/admin/requests/{id}/assign?assigneeId=5` | تخصیص به اپراتور |
| POST | `/api/admin/requests/{id}/comments` | افزودن نظر داخلی |
| GET | `/api/admin/requests/stats` | آمار کلی |
| GET | `/api/admin/requests/breached-sla` | درخواست‌های نقض SLA |

> برای خدماتی با تنظیم `walletDeductTiming=ON_APPROVAL`، تغییر وضعیت به `RESOLVED` باعث Capture (کسر قطعی) و تغییر به `CANCELLED` باعث Release (آزادسازی) مبلغ Hold شده می‌شود.

---

## ⏱️ SLA / OLA — `/api/admin/sla`

| متد | مسیر | توضیح |
|---|---|---|
| GET | `/api/admin/sla` | لیست SLA |
| GET | `/api/admin/sla/ola` | لیست OLA |
| POST | `/api/admin/sla` | ایجاد |
| PUT | `/api/admin/sla/{id}` | ویرایش |
| DELETE | `/api/admin/sla/{id}` | حذف |
| POST | `/api/admin/sla/sync-itop` | همگام‌سازی با iTop |

```json
POST /api/admin/sla
{
  "name": "SLA طلایی",
  "slaType": "SLA",
  "responseTimeMinutes": 60,
  "resolutionTimeMinutes": 480,
  "coverageType": "H24_7",
  "isActive": true
}
```

---

## 📁 پروژه‌ها و گانت — `/api/admin/projects`

| متد | مسیر | توضیح |
|---|---|---|
| GET | `/api/admin/projects` | لیست |
| POST | `/api/admin/projects` | ایجاد |
| PUT | `/api/admin/projects/{id}` | ویرایش |
| DELETE | `/api/admin/projects/{id}` | حذف |
| GET | `/api/admin/projects/{id}/gantt` | داده گانت چارت |
| POST | `/api/admin/projects/{id}/tasks` | افزودن وظیفه |
| PATCH | `/api/admin/projects/{pid}/tasks/{tid}/progress?percent=50` | بروزرسانی پیشرفت |
| GET | `/api/admin/projects/stats` | آمار |

---

## 💵 مراکز هزینه — `/api/admin/cost-centers`

| متد | مسیر | توضیح |
|---|---|---|
| GET | `/api/admin/cost-centers` | همه (فعال) |
| GET | `/api/admin/cost-centers/roots` | فقط ریشه‌ها |
| GET | `/api/admin/cost-centers/summary` | خلاصه بودجه |
| POST | `/api/admin/cost-centers` | ایجاد |
| PUT | `/api/admin/cost-centers/{id}` | ویرایش |
| POST | `/api/admin/cost-centers/{id}/expense?amount=500000&description=...` | ثبت هزینه |
| DELETE | `/api/admin/cost-centers/{id}` | حذف (غیرفعال‌سازی) |

---

## 🧩 ماژول‌ها — `/api/admin/modules`
*نیازمند نقش: SUPER_ADMIN*

| متد | مسیر | توضیح |
|---|---|---|
| GET | `/api/admin/modules` | لیست ماژول‌های نصب‌شده |
| POST | `/api/admin/modules/install` | آپلود JAR (multipart/form-data) |
| POST | `/api/admin/modules/{id}/activate` | فعال‌سازی |
| POST | `/api/admin/modules/{id}/deactivate` | غیرفعال‌سازی |
| DELETE | `/api/admin/modules/{id}` | حذف |

---

## 🔗 LDAP — `/api/admin/ldap`
*نیازمند نقش: SUPER_ADMIN*

| متد | مسیر | توضیح |
|---|---|---|
| GET | `/api/admin/ldap` | لیست سرورها |
| POST | `/api/admin/ldap` | افزودن سرور |
| PUT | `/api/admin/ldap/{id}` | ویرایش |
| POST | `/api/admin/ldap/{id}/test` | آزمایش اتصال |
| POST | `/api/admin/ldap/{id}/disable` | غیرفعال‌سازی |
| DELETE | `/api/admin/ldap/{id}` | حذف |

---

## 📝 لاگ‌ها — `/api/admin/logs`

```http
GET /api/admin/logs?page=0&size=50
```
خروجی `Page<AuditLog>` با فیلدهای: `username, action, module, description, level, success, ipAddress, createdAt`

---

## ⚙️ وضعیت سامانه — `/api/system`

| متد | مسیر | احراز هویت | توضیح |
|---|---|---|---|
| GET | `/api/system/health` | عمومی | بررسی سلامت ساده |
| GET | `/api/system/status` | ADMIN+ | وضعیت کامل (iTop، DB، JVM) |

---

## 👤 پروفایل کاربری — `/api/portal/profile`

| متد | مسیر | توضیح |
|---|---|---|
| GET | `/api/portal/profile` | اطلاعات پروفایل |
| PUT | `/api/portal/profile` | ویرایش پروفایل |
| POST | `/api/portal/profile/change-password` | تغییر رمز عبور |

---

## ⚠️ کدهای خطا

| کد | معنی |
|---|---|
| 200 | موفق |
| 400 | درخواست نامعتبر / خطای اعتبارسنجی |
| 401 | احراز هویت نشده |
| 403 | دسترسی غیرمجاز |
| 404 | یافت نشد |
| 413 | حجم فایل بیش از حد |
| 500 | خطای داخلی سرور |

نمونه پاسخ خطا:
```json
{
  "status": 403,
  "error": "دسترسی غیرمجاز",
  "message": "شما مجوز دسترسی به این بخش را ندارید",
  "path": "/admin/users"
}
```
