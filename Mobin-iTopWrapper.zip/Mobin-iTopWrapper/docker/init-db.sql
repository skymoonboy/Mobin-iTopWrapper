-- ===== راه‌اندازی اولیه پایگاه داده سامانه iTop Wrapper =====
-- این اسکریپت هنگام اولین راه‌اندازی Docker اجرا می‌شود

-- بررسی encoding
SET client_encoding = 'UTF8';

-- ===== ایجاد Extension‌ها =====
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";
CREATE EXTENSION IF NOT EXISTS "pg_trgm";  -- برای جستجوی متنی بهتر

-- ===== دنباله‌ها (Sequences) =====
CREATE SEQUENCE IF NOT EXISTS seq_users          START 1 INCREMENT 1;
CREATE SEQUENCE IF NOT EXISTS seq_roles          START 1 INCREMENT 1;
CREATE SEQUENCE IF NOT EXISTS seq_permissions    START 1 INCREMENT 1;
CREATE SEQUENCE IF NOT EXISTS seq_service_categories START 1 INCREMENT 1;
CREATE SEQUENCE IF NOT EXISTS seq_service_items  START 1 INCREMENT 1;
CREATE SEQUENCE IF NOT EXISTS seq_audit_logs     START 1 INCREMENT 50;
CREATE SEQUENCE IF NOT EXISTS seq_modules        START 1 INCREMENT 1;

-- ===== جدول نقش‌ها =====
CREATE TABLE IF NOT EXISTS roles (
    id              BIGINT PRIMARY KEY DEFAULT nextval('seq_roles'),
    name            VARCHAR(100) NOT NULL UNIQUE,
    description     VARCHAR(500),
    is_system_role  BOOLEAN DEFAULT FALSE,
    itop_profile_id BIGINT
);

-- ===== جدول مجوزها =====
CREATE TABLE IF NOT EXISTS permissions (
    id          BIGINT PRIMARY KEY DEFAULT nextval('seq_permissions'),
    name        VARCHAR(100) NOT NULL UNIQUE,
    description VARCHAR(200),
    module      VARCHAR(50),
    action      VARCHAR(50)
);

-- ===== جدول کاربران =====
CREATE TABLE IF NOT EXISTS users (
    id                      BIGINT PRIMARY KEY DEFAULT nextval('seq_users'),
    username                VARCHAR(100) NOT NULL UNIQUE,
    email                   VARCHAR(200) NOT NULL UNIQUE,
    password_hash           VARCHAR(255),
    first_name              VARCHAR(100),
    last_name               VARCHAR(100),
    display_name            VARCHAR(200),
    phone                   VARCHAR(20),
    organization            VARCHAR(200),
    auth_type               VARCHAR(20)  NOT NULL DEFAULT 'LOCAL',
    ldap_dn                 VARCHAR(500),
    ldap_provider_id        VARCHAR(50),
    itop_user_id            BIGINT,
    is_active               BOOLEAN DEFAULT TRUE,
    is_locked               BOOLEAN DEFAULT FALSE,
    failed_login_attempts   INTEGER DEFAULT 0,
    last_login              TIMESTAMP,
    password_changed_at     TIMESTAMP,
    created_at              TIMESTAMP DEFAULT NOW(),
    updated_at              TIMESTAMP DEFAULT NOW(),
    created_by              VARCHAR(100)
);
CREATE INDEX IF NOT EXISTS idx_user_username ON users(username);
CREATE INDEX IF NOT EXISTS idx_user_email    ON users(email);
CREATE INDEX IF NOT EXISTS idx_user_active   ON users(is_active);

-- ===== جدول ارتباط کاربر-نقش =====
CREATE TABLE IF NOT EXISTS user_roles (
    user_id BIGINT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    role_id BIGINT NOT NULL REFERENCES roles(id) ON DELETE CASCADE,
    PRIMARY KEY (user_id, role_id)
);

-- ===== جدول ارتباط نقش-مجوز =====
CREATE TABLE IF NOT EXISTS role_permissions (
    role_id       BIGINT NOT NULL REFERENCES roles(id) ON DELETE CASCADE,
    permission_id BIGINT NOT NULL REFERENCES permissions(id) ON DELETE CASCADE,
    PRIMARY KEY (role_id, permission_id)
);

-- ===== جدول دسته‌بندی خدمات =====
CREATE TABLE IF NOT EXISTS service_categories (
    id              BIGINT PRIMARY KEY DEFAULT nextval('seq_service_categories'),
    name            VARCHAR(200) NOT NULL,
    description     VARCHAR(1000),
    icon_class      VARCHAR(100),
    display_order   INTEGER DEFAULT 0,
    is_active       BOOLEAN DEFAULT TRUE,
    parent_id       BIGINT REFERENCES service_categories(id),
    itop_service_id BIGINT,
    created_at      TIMESTAMP DEFAULT NOW(),
    updated_at      TIMESTAMP DEFAULT NOW()
);
CREATE INDEX IF NOT EXISTS idx_sc_parent   ON service_categories(parent_id);
CREATE INDEX IF NOT EXISTS idx_sc_active   ON service_categories(is_active);

-- ===== جدول آیتم‌های خدمت =====
CREATE TABLE IF NOT EXISTS service_items (
    id                          BIGINT PRIMARY KEY DEFAULT nextval('seq_service_items'),
    name                        VARCHAR(200) NOT NULL,
    description                 TEXT,
    short_description           VARCHAR(500),
    category_id                 BIGINT NOT NULL REFERENCES service_categories(id),
    service_type                VARCHAR(50) DEFAULT 'STANDARD',
    pricing_model               VARCHAR(50) DEFAULT 'FIXED',
    base_price                  NUMERIC(15,2) DEFAULT 0,
    currency                    VARCHAR(10) DEFAULT 'IRR',
    sla_hours                   INTEGER,
    ola_hours                   INTEGER,
    delivery_time_days          INTEGER,
    is_active                   BOOLEAN DEFAULT TRUE,
    is_featured                 BOOLEAN DEFAULT FALSE,
    icon_class                  VARCHAR(100),
    itop_service_subcategory_id BIGINT,
    itop_service_id             BIGINT,
    pricing_formula             VARCHAR(500),
    display_order               INTEGER DEFAULT 0,
    created_at                  TIMESTAMP DEFAULT NOW(),
    updated_at                  TIMESTAMP DEFAULT NOW()
);
CREATE INDEX IF NOT EXISTS idx_si_category ON service_items(category_id);
CREATE INDEX IF NOT EXISTS idx_si_active   ON service_items(is_active);
CREATE INDEX IF NOT EXISTS idx_si_featured ON service_items(is_featured);

-- ===== جدول لاگ‌های حسابرسی =====
CREATE TABLE IF NOT EXISTS audit_logs (
    id            BIGINT PRIMARY KEY DEFAULT nextval('seq_audit_logs'),
    username      VARCHAR(100),
    user_id       BIGINT,
    action        VARCHAR(100) NOT NULL,
    module        VARCHAR(100),
    resource_type VARCHAR(100),
    resource_id   BIGINT,
    description   VARCHAR(1000),
    ip_address    VARCHAR(50),
    user_agent    VARCHAR(500),
    level         VARCHAR(20) DEFAULT 'INFO',
    old_value     TEXT,
    new_value     TEXT,
    success       BOOLEAN DEFAULT TRUE,
    error_message VARCHAR(1000),
    duration_ms   BIGINT,
    created_at    TIMESTAMP DEFAULT NOW()
);
CREATE INDEX IF NOT EXISTS idx_audit_user    ON audit_logs(username);
CREATE INDEX IF NOT EXISTS idx_audit_action  ON audit_logs(action);
CREATE INDEX IF NOT EXISTS idx_audit_created ON audit_logs(created_at DESC);
CREATE INDEX IF NOT EXISTS idx_audit_module  ON audit_logs(module);
CREATE INDEX IF NOT EXISTS idx_audit_level   ON audit_logs(level);

-- ===== جدول ماژول‌ها =====
CREATE TABLE IF NOT EXISTS modules (
    id                BIGINT PRIMARY KEY DEFAULT nextval('seq_modules'),
    module_id         VARCHAR(100) NOT NULL UNIQUE,
    name              VARCHAR(200) NOT NULL,
    description       VARCHAR(1000),
    version           VARCHAR(50),
    author            VARCHAR(200),
    jar_path          VARCHAR(500),
    config_schema     TEXT,
    config_values     TEXT,
    status            VARCHAR(20) DEFAULT 'INSTALLED',
    entry_point_class VARCHAR(300),
    requires_restart  BOOLEAN DEFAULT FALSE,
    installed_by      VARCHAR(100),
    created_at        TIMESTAMP DEFAULT NOW(),
    updated_at        TIMESTAMP DEFAULT NOW()
);

-- ===== داده‌های اولیه: نقش‌ها =====
INSERT INTO roles (name, description, is_system_role) VALUES
    ('ROLE_SUPER_ADMIN', 'سوپر ادمین — دسترسی کامل به تمام بخش‌ها', TRUE),
    ('ROLE_ADMIN',       'مدیر سامانه — مدیریت کاربران و خدمات',   TRUE),
    ('ROLE_MANAGER',     'مدیر عملیات — مدیریت SLA و پروژه‌ها',    TRUE),
    ('ROLE_OPERATOR',    'اپراتور — پردازش درخواست‌ها',              TRUE),
    ('ROLE_CUSTOMER',    'مشتری — دسترسی به پرتال خدمات',           TRUE)
ON CONFLICT (name) DO NOTHING;

-- ===== داده‌های اولیه: مجوزها =====
INSERT INTO permissions (name, description, module, action) VALUES
    ('SERVICE_READ',   'مشاهده خدمات',          'SERVICE_CATALOG', 'READ'),
    ('SERVICE_WRITE',  'ایجاد و ویرایش خدمات',  'SERVICE_CATALOG', 'WRITE'),
    ('SERVICE_DELETE', 'حذف خدمات',              'SERVICE_CATALOG', 'DELETE'),
    ('SERVICE_PRICE',  'مدیریت قیمت‌گذاری',     'SERVICE_CATALOG', 'PRICE'),
    ('USER_READ',      'مشاهده کاربران',          'USER_MANAGEMENT', 'READ'),
    ('USER_WRITE',     'ایجاد و ویرایش کاربران', 'USER_MANAGEMENT', 'WRITE'),
    ('USER_DELETE',    'حذف کاربران',             'USER_MANAGEMENT', 'DELETE'),
    ('SLA_READ',       'مشاهده SLA/OLA',          'SLA_MANAGEMENT',  'READ'),
    ('SLA_WRITE',      'مدیریت SLA/OLA',          'SLA_MANAGEMENT',  'WRITE'),
    ('PROJECT_READ',   'مشاهده پروژه‌ها',        'PROJECT_MGMT',    'READ'),
    ('PROJECT_WRITE',  'مدیریت پروژه‌ها',        'PROJECT_MGMT',    'WRITE'),
    ('COST_READ',      'مشاهده مراکز هزینه',      'COST_CENTER',     'READ'),
    ('COST_WRITE',     'مدیریت مراکز هزینه',      'COST_CENTER',     'WRITE'),
    ('MODULE_UPLOAD',  'آپلود ماژول',             'MODULE_MGMT',     'UPLOAD'),
    ('MODULE_MANAGE',  'مدیریت ماژول‌ها',        'MODULE_MGMT',     'MANAGE'),
    ('LOG_READ',       'مشاهده لاگ‌ها',           'AUDIT',           'READ')
ON CONFLICT (name) DO NOTHING;

-- ===== کاربر ادمین پیش‌فرض =====
-- رمز عبور: Admin@123 (هنگام اجرا تغییر دهید)
INSERT INTO users (username, email, password_hash, first_name, last_name, auth_type, is_active, created_by)
VALUES ('admin', 'admin@itop.local',
        '$2a$12$LQv3c1yqBWVHxkd0LHAkCOYz6TtxMQJqhN8/LewY6H5Q3FPJuCmy2',
        'مدیر', 'سامانه', 'LOCAL', TRUE, 'system')
ON CONFLICT (username) DO NOTHING;

-- اتصال کاربر ادمین به نقش SUPER_ADMIN
INSERT INTO user_roles (user_id, role_id)
SELECT u.id, r.id FROM users u, roles r
WHERE u.username = 'admin' AND r.name = 'ROLE_SUPER_ADMIN'
ON CONFLICT DO NOTHING;

-- ===== دسته‌بندی‌های خدمات نمونه =====
INSERT INTO service_categories (name, description, icon_class, display_order, is_active) VALUES
    ('زیرساخت و سخت‌افزار', 'خدمات مرتبط با تجهیزات و زیرساخت فناوری اطلاعات', 'bi bi-server',       1, TRUE),
    ('نرم‌افزار و لایسنس',  'نصب، پیکربندی و مدیریت نرم‌افزارها',               'bi bi-window',       2, TRUE),
    ('امنیت اطلاعات',       'خدمات حفاظت و امنیت سیستم‌های اطلاعاتی',            'bi bi-shield-lock',  3, TRUE),
    ('شبکه و ارتباطات',     'راه‌اندازی و پشتیبانی شبکه‌های ارتباطی',            'bi bi-wifi',         4, TRUE),
    ('پشتیبانی کاربران',   'میز خدمات و پشتیبانی فنی کاربران',                  'bi bi-headset',      5, TRUE),
    ('ابر و مجازی‌سازی',   'خدمات زیرساخت ابری و مجازی‌سازی',                  'bi bi-cloud',        6, TRUE)
ON CONFLICT DO NOTHING;

-- ===== لاگ راه‌اندازی =====
INSERT INTO audit_logs (username, action, module, description, level, success)
VALUES ('system', 'DB_INIT', 'SYSTEM', 'راه‌اندازی اولیه پایگاه داده با موفقیت انجام شد', 'INFO', TRUE);
